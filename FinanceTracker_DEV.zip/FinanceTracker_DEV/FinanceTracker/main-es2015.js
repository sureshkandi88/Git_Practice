(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
/*!**************************************************!*\
  !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "./node_modules/moment/locale/af.js",
	"./af.js": "./node_modules/moment/locale/af.js",
	"./ar": "./node_modules/moment/locale/ar.js",
	"./ar-dz": "./node_modules/moment/locale/ar-dz.js",
	"./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
	"./ar-kw": "./node_modules/moment/locale/ar-kw.js",
	"./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
	"./ar-ly": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ma": "./node_modules/moment/locale/ar-ma.js",
	"./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
	"./ar-sa": "./node_modules/moment/locale/ar-sa.js",
	"./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
	"./ar-tn": "./node_modules/moment/locale/ar-tn.js",
	"./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
	"./ar.js": "./node_modules/moment/locale/ar.js",
	"./az": "./node_modules/moment/locale/az.js",
	"./az.js": "./node_modules/moment/locale/az.js",
	"./be": "./node_modules/moment/locale/be.js",
	"./be.js": "./node_modules/moment/locale/be.js",
	"./bg": "./node_modules/moment/locale/bg.js",
	"./bg.js": "./node_modules/moment/locale/bg.js",
	"./bm": "./node_modules/moment/locale/bm.js",
	"./bm.js": "./node_modules/moment/locale/bm.js",
	"./bn": "./node_modules/moment/locale/bn.js",
	"./bn.js": "./node_modules/moment/locale/bn.js",
	"./bo": "./node_modules/moment/locale/bo.js",
	"./bo.js": "./node_modules/moment/locale/bo.js",
	"./br": "./node_modules/moment/locale/br.js",
	"./br.js": "./node_modules/moment/locale/br.js",
	"./bs": "./node_modules/moment/locale/bs.js",
	"./bs.js": "./node_modules/moment/locale/bs.js",
	"./ca": "./node_modules/moment/locale/ca.js",
	"./ca.js": "./node_modules/moment/locale/ca.js",
	"./cs": "./node_modules/moment/locale/cs.js",
	"./cs.js": "./node_modules/moment/locale/cs.js",
	"./cv": "./node_modules/moment/locale/cv.js",
	"./cv.js": "./node_modules/moment/locale/cv.js",
	"./cy": "./node_modules/moment/locale/cy.js",
	"./cy.js": "./node_modules/moment/locale/cy.js",
	"./da": "./node_modules/moment/locale/da.js",
	"./da.js": "./node_modules/moment/locale/da.js",
	"./de": "./node_modules/moment/locale/de.js",
	"./de-at": "./node_modules/moment/locale/de-at.js",
	"./de-at.js": "./node_modules/moment/locale/de-at.js",
	"./de-ch": "./node_modules/moment/locale/de-ch.js",
	"./de-ch.js": "./node_modules/moment/locale/de-ch.js",
	"./de.js": "./node_modules/moment/locale/de.js",
	"./dv": "./node_modules/moment/locale/dv.js",
	"./dv.js": "./node_modules/moment/locale/dv.js",
	"./el": "./node_modules/moment/locale/el.js",
	"./el.js": "./node_modules/moment/locale/el.js",
	"./en-SG": "./node_modules/moment/locale/en-SG.js",
	"./en-SG.js": "./node_modules/moment/locale/en-SG.js",
	"./en-au": "./node_modules/moment/locale/en-au.js",
	"./en-au.js": "./node_modules/moment/locale/en-au.js",
	"./en-ca": "./node_modules/moment/locale/en-ca.js",
	"./en-ca.js": "./node_modules/moment/locale/en-ca.js",
	"./en-gb": "./node_modules/moment/locale/en-gb.js",
	"./en-gb.js": "./node_modules/moment/locale/en-gb.js",
	"./en-ie": "./node_modules/moment/locale/en-ie.js",
	"./en-ie.js": "./node_modules/moment/locale/en-ie.js",
	"./en-il": "./node_modules/moment/locale/en-il.js",
	"./en-il.js": "./node_modules/moment/locale/en-il.js",
	"./en-nz": "./node_modules/moment/locale/en-nz.js",
	"./en-nz.js": "./node_modules/moment/locale/en-nz.js",
	"./eo": "./node_modules/moment/locale/eo.js",
	"./eo.js": "./node_modules/moment/locale/eo.js",
	"./es": "./node_modules/moment/locale/es.js",
	"./es-do": "./node_modules/moment/locale/es-do.js",
	"./es-do.js": "./node_modules/moment/locale/es-do.js",
	"./es-us": "./node_modules/moment/locale/es-us.js",
	"./es-us.js": "./node_modules/moment/locale/es-us.js",
	"./es.js": "./node_modules/moment/locale/es.js",
	"./et": "./node_modules/moment/locale/et.js",
	"./et.js": "./node_modules/moment/locale/et.js",
	"./eu": "./node_modules/moment/locale/eu.js",
	"./eu.js": "./node_modules/moment/locale/eu.js",
	"./fa": "./node_modules/moment/locale/fa.js",
	"./fa.js": "./node_modules/moment/locale/fa.js",
	"./fi": "./node_modules/moment/locale/fi.js",
	"./fi.js": "./node_modules/moment/locale/fi.js",
	"./fo": "./node_modules/moment/locale/fo.js",
	"./fo.js": "./node_modules/moment/locale/fo.js",
	"./fr": "./node_modules/moment/locale/fr.js",
	"./fr-ca": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ch": "./node_modules/moment/locale/fr-ch.js",
	"./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
	"./fr.js": "./node_modules/moment/locale/fr.js",
	"./fy": "./node_modules/moment/locale/fy.js",
	"./fy.js": "./node_modules/moment/locale/fy.js",
	"./ga": "./node_modules/moment/locale/ga.js",
	"./ga.js": "./node_modules/moment/locale/ga.js",
	"./gd": "./node_modules/moment/locale/gd.js",
	"./gd.js": "./node_modules/moment/locale/gd.js",
	"./gl": "./node_modules/moment/locale/gl.js",
	"./gl.js": "./node_modules/moment/locale/gl.js",
	"./gom-latn": "./node_modules/moment/locale/gom-latn.js",
	"./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
	"./gu": "./node_modules/moment/locale/gu.js",
	"./gu.js": "./node_modules/moment/locale/gu.js",
	"./he": "./node_modules/moment/locale/he.js",
	"./he.js": "./node_modules/moment/locale/he.js",
	"./hi": "./node_modules/moment/locale/hi.js",
	"./hi.js": "./node_modules/moment/locale/hi.js",
	"./hr": "./node_modules/moment/locale/hr.js",
	"./hr.js": "./node_modules/moment/locale/hr.js",
	"./hu": "./node_modules/moment/locale/hu.js",
	"./hu.js": "./node_modules/moment/locale/hu.js",
	"./hy-am": "./node_modules/moment/locale/hy-am.js",
	"./hy-am.js": "./node_modules/moment/locale/hy-am.js",
	"./id": "./node_modules/moment/locale/id.js",
	"./id.js": "./node_modules/moment/locale/id.js",
	"./is": "./node_modules/moment/locale/is.js",
	"./is.js": "./node_modules/moment/locale/is.js",
	"./it": "./node_modules/moment/locale/it.js",
	"./it-ch": "./node_modules/moment/locale/it-ch.js",
	"./it-ch.js": "./node_modules/moment/locale/it-ch.js",
	"./it.js": "./node_modules/moment/locale/it.js",
	"./ja": "./node_modules/moment/locale/ja.js",
	"./ja.js": "./node_modules/moment/locale/ja.js",
	"./jv": "./node_modules/moment/locale/jv.js",
	"./jv.js": "./node_modules/moment/locale/jv.js",
	"./ka": "./node_modules/moment/locale/ka.js",
	"./ka.js": "./node_modules/moment/locale/ka.js",
	"./kk": "./node_modules/moment/locale/kk.js",
	"./kk.js": "./node_modules/moment/locale/kk.js",
	"./km": "./node_modules/moment/locale/km.js",
	"./km.js": "./node_modules/moment/locale/km.js",
	"./kn": "./node_modules/moment/locale/kn.js",
	"./kn.js": "./node_modules/moment/locale/kn.js",
	"./ko": "./node_modules/moment/locale/ko.js",
	"./ko.js": "./node_modules/moment/locale/ko.js",
	"./ku": "./node_modules/moment/locale/ku.js",
	"./ku.js": "./node_modules/moment/locale/ku.js",
	"./ky": "./node_modules/moment/locale/ky.js",
	"./ky.js": "./node_modules/moment/locale/ky.js",
	"./lb": "./node_modules/moment/locale/lb.js",
	"./lb.js": "./node_modules/moment/locale/lb.js",
	"./lo": "./node_modules/moment/locale/lo.js",
	"./lo.js": "./node_modules/moment/locale/lo.js",
	"./lt": "./node_modules/moment/locale/lt.js",
	"./lt.js": "./node_modules/moment/locale/lt.js",
	"./lv": "./node_modules/moment/locale/lv.js",
	"./lv.js": "./node_modules/moment/locale/lv.js",
	"./me": "./node_modules/moment/locale/me.js",
	"./me.js": "./node_modules/moment/locale/me.js",
	"./mi": "./node_modules/moment/locale/mi.js",
	"./mi.js": "./node_modules/moment/locale/mi.js",
	"./mk": "./node_modules/moment/locale/mk.js",
	"./mk.js": "./node_modules/moment/locale/mk.js",
	"./ml": "./node_modules/moment/locale/ml.js",
	"./ml.js": "./node_modules/moment/locale/ml.js",
	"./mn": "./node_modules/moment/locale/mn.js",
	"./mn.js": "./node_modules/moment/locale/mn.js",
	"./mr": "./node_modules/moment/locale/mr.js",
	"./mr.js": "./node_modules/moment/locale/mr.js",
	"./ms": "./node_modules/moment/locale/ms.js",
	"./ms-my": "./node_modules/moment/locale/ms-my.js",
	"./ms-my.js": "./node_modules/moment/locale/ms-my.js",
	"./ms.js": "./node_modules/moment/locale/ms.js",
	"./mt": "./node_modules/moment/locale/mt.js",
	"./mt.js": "./node_modules/moment/locale/mt.js",
	"./my": "./node_modules/moment/locale/my.js",
	"./my.js": "./node_modules/moment/locale/my.js",
	"./nb": "./node_modules/moment/locale/nb.js",
	"./nb.js": "./node_modules/moment/locale/nb.js",
	"./ne": "./node_modules/moment/locale/ne.js",
	"./ne.js": "./node_modules/moment/locale/ne.js",
	"./nl": "./node_modules/moment/locale/nl.js",
	"./nl-be": "./node_modules/moment/locale/nl-be.js",
	"./nl-be.js": "./node_modules/moment/locale/nl-be.js",
	"./nl.js": "./node_modules/moment/locale/nl.js",
	"./nn": "./node_modules/moment/locale/nn.js",
	"./nn.js": "./node_modules/moment/locale/nn.js",
	"./pa-in": "./node_modules/moment/locale/pa-in.js",
	"./pa-in.js": "./node_modules/moment/locale/pa-in.js",
	"./pl": "./node_modules/moment/locale/pl.js",
	"./pl.js": "./node_modules/moment/locale/pl.js",
	"./pt": "./node_modules/moment/locale/pt.js",
	"./pt-br": "./node_modules/moment/locale/pt-br.js",
	"./pt-br.js": "./node_modules/moment/locale/pt-br.js",
	"./pt.js": "./node_modules/moment/locale/pt.js",
	"./ro": "./node_modules/moment/locale/ro.js",
	"./ro.js": "./node_modules/moment/locale/ro.js",
	"./ru": "./node_modules/moment/locale/ru.js",
	"./ru.js": "./node_modules/moment/locale/ru.js",
	"./sd": "./node_modules/moment/locale/sd.js",
	"./sd.js": "./node_modules/moment/locale/sd.js",
	"./se": "./node_modules/moment/locale/se.js",
	"./se.js": "./node_modules/moment/locale/se.js",
	"./si": "./node_modules/moment/locale/si.js",
	"./si.js": "./node_modules/moment/locale/si.js",
	"./sk": "./node_modules/moment/locale/sk.js",
	"./sk.js": "./node_modules/moment/locale/sk.js",
	"./sl": "./node_modules/moment/locale/sl.js",
	"./sl.js": "./node_modules/moment/locale/sl.js",
	"./sq": "./node_modules/moment/locale/sq.js",
	"./sq.js": "./node_modules/moment/locale/sq.js",
	"./sr": "./node_modules/moment/locale/sr.js",
	"./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr.js": "./node_modules/moment/locale/sr.js",
	"./ss": "./node_modules/moment/locale/ss.js",
	"./ss.js": "./node_modules/moment/locale/ss.js",
	"./sv": "./node_modules/moment/locale/sv.js",
	"./sv.js": "./node_modules/moment/locale/sv.js",
	"./sw": "./node_modules/moment/locale/sw.js",
	"./sw.js": "./node_modules/moment/locale/sw.js",
	"./ta": "./node_modules/moment/locale/ta.js",
	"./ta.js": "./node_modules/moment/locale/ta.js",
	"./te": "./node_modules/moment/locale/te.js",
	"./te.js": "./node_modules/moment/locale/te.js",
	"./tet": "./node_modules/moment/locale/tet.js",
	"./tet.js": "./node_modules/moment/locale/tet.js",
	"./tg": "./node_modules/moment/locale/tg.js",
	"./tg.js": "./node_modules/moment/locale/tg.js",
	"./th": "./node_modules/moment/locale/th.js",
	"./th.js": "./node_modules/moment/locale/th.js",
	"./tl-ph": "./node_modules/moment/locale/tl-ph.js",
	"./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
	"./tlh": "./node_modules/moment/locale/tlh.js",
	"./tlh.js": "./node_modules/moment/locale/tlh.js",
	"./tr": "./node_modules/moment/locale/tr.js",
	"./tr.js": "./node_modules/moment/locale/tr.js",
	"./tzl": "./node_modules/moment/locale/tzl.js",
	"./tzl.js": "./node_modules/moment/locale/tzl.js",
	"./tzm": "./node_modules/moment/locale/tzm.js",
	"./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm.js": "./node_modules/moment/locale/tzm.js",
	"./ug-cn": "./node_modules/moment/locale/ug-cn.js",
	"./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
	"./uk": "./node_modules/moment/locale/uk.js",
	"./uk.js": "./node_modules/moment/locale/uk.js",
	"./ur": "./node_modules/moment/locale/ur.js",
	"./ur.js": "./node_modules/moment/locale/ur.js",
	"./uz": "./node_modules/moment/locale/uz.js",
	"./uz-latn": "./node_modules/moment/locale/uz-latn.js",
	"./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
	"./uz.js": "./node_modules/moment/locale/uz.js",
	"./vi": "./node_modules/moment/locale/vi.js",
	"./vi.js": "./node_modules/moment/locale/vi.js",
	"./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
	"./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
	"./yo": "./node_modules/moment/locale/yo.js",
	"./yo.js": "./node_modules/moment/locale/yo.js",
	"./zh-cn": "./node_modules/moment/locale/zh-cn.js",
	"./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
	"./zh-hk": "./node_modules/moment/locale/zh-hk.js",
	"./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
	"./zh-tw": "./node_modules/moment/locale/zh-tw.js",
	"./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./src/app/Models/CashEntry/cash-entry-item.model.ts":
/*!***********************************************************!*\
  !*** ./src/app/Models/CashEntry/cash-entry-item.model.ts ***!
  \***********************************************************/
/*! exports provided: CashEntryItem */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CashEntryItem", function() { return CashEntryItem; });
class CashEntryItem {
    constructor(sNo = null, compOperaratorId = null, description = "", serviceTypeId = null, clientId = null, amount = null, debitAmount = null, paidAmount = null, remarks = "", createdDate = null, updatedDate = null) {
        this.sNo = sNo;
        this.compOperaratorId = compOperaratorId;
        this.description = description;
        this.serviceTypeId = serviceTypeId;
        this.clientId = clientId;
        this.amount = amount;
        this.debitAmount = debitAmount;
        this.paidAmount = paidAmount;
        this.remarks = remarks;
        this.createdDate = createdDate;
        this.updatedDate = updatedDate;
    }
    ;
}


/***/ }),

/***/ "./src/app/Models/CashEntry/cash-entry-update-bo.ts":
/*!**********************************************************!*\
  !*** ./src/app/Models/CashEntry/cash-entry-update-bo.ts ***!
  \**********************************************************/
/*! exports provided: CashEntryUpdateBO */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CashEntryUpdateBO", function() { return CashEntryUpdateBO; });
class CashEntryUpdateBO {
    constructor(oldObject = null, newObject = null, action = "") {
        this.oldObject = oldObject;
        this.newObject = newObject;
        this.action = action;
    }
}


/***/ }),

/***/ "./src/app/Models/Client/client.model.ts":
/*!***********************************************!*\
  !*** ./src/app/Models/Client/client.model.ts ***!
  \***********************************************/
/*! exports provided: Client */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Client", function() { return Client; });
class Client {
    constructor(id, clientName, phone, village, photo, balance) {
        this.id = id;
        this.clientName = clientName;
        this.phone = phone;
        this.village = village;
        this.photo = photo;
        this.balance = balance;
    }
}


/***/ }),

/***/ "./src/app/Models/Report/report-input.model.ts":
/*!*****************************************************!*\
  !*** ./src/app/Models/Report/report-input.model.ts ***!
  \*****************************************************/
/*! exports provided: ReportInput */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReportInput", function() { return ReportInput; });
class ReportInput {
    constructor(clientId, compOperatorId, serviceTypeId, fromDate, toDate) {
        this.clientId = clientId;
        this.compOperatorId = compOperatorId;
        this.serviceTypeId = serviceTypeId;
        this.fromDate = fromDate;
        this.toDate = toDate;
    }
}


/***/ }),

/***/ "./src/app/Models/ServiceType/service-type.model.ts":
/*!**********************************************************!*\
  !*** ./src/app/Models/ServiceType/service-type.model.ts ***!
  \**********************************************************/
/*! exports provided: ServiceType */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServiceType", function() { return ServiceType; });
class ServiceType {
    constructor(sid, sType, sTypeDesc) {
        this.sid = sid;
        this.sType = sType;
        this.sTypeDesc = sTypeDesc;
    }
}


/***/ }),

/***/ "./src/app/Models/TransactionType/transaction-type.model.ts":
/*!******************************************************************!*\
  !*** ./src/app/Models/TransactionType/transaction-type.model.ts ***!
  \******************************************************************/
/*! exports provided: TransactionType */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TransactionType", function() { return TransactionType; });
class TransactionType {
    constructor(tTypeId, tType) {
        this.tTypeId = tTypeId;
        this.tType = tType;
    }
}


/***/ }),

/***/ "./src/app/Models/User/user.model.ts":
/*!*******************************************!*\
  !*** ./src/app/Models/User/user.model.ts ***!
  \*******************************************/
/*! exports provided: User */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "User", function() { return User; });
class User {
    constructor(userId, username, password, firstName, lastName, photo) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
        this.photo = photo;
    }
}


/***/ }),

/***/ "./src/app/Models/index.ts":
/*!*********************************!*\
  !*** ./src/app/Models/index.ts ***!
  \*********************************/
/*! exports provided: Client, ServiceType, User, CashEntryItem */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Client_client_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Client/client.model */ "./src/app/Models/Client/client.model.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Client", function() { return _Client_client_model__WEBPACK_IMPORTED_MODULE_0__["Client"]; });

/* harmony import */ var _ServiceType_service_type_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ServiceType/service-type.model */ "./src/app/Models/ServiceType/service-type.model.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ServiceType", function() { return _ServiceType_service_type_model__WEBPACK_IMPORTED_MODULE_1__["ServiceType"]; });

/* harmony import */ var _User_user_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./User/user.model */ "./src/app/Models/User/user.model.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "User", function() { return _User_user_model__WEBPACK_IMPORTED_MODULE_2__["User"]; });

/* harmony import */ var _CashEntry_cash_entry_item_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./CashEntry/cash-entry-item.model */ "./src/app/Models/CashEntry/cash-entry-item.model.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CashEntryItem", function() { return _CashEntry_cash_entry_item_model__WEBPACK_IMPORTED_MODULE_3__["CashEntryItem"]; });







/***/ }),

/***/ "./src/app/Pages/Admin/Create/create-client/create-client.component.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/Pages/Admin/Create/create-client/create-client.component.ts ***!
  \*****************************************************************************/
/*! exports provided: CreateClientComponent, ClientUpdateBO */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateClientComponent", function() { return CreateClientComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientUpdateBO", function() { return ClientUpdateBO; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/dialog.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/form-field.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/input.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");









function CreateClientComponent_h1_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "h1", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r101 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Update CUSTOMER : ", ctx_r101.title, "");
} }
function CreateClientComponent_div_2_Template(rf, ctx) { if (rf & 1) {
    const _r106 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "mat-form-field", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "CUSTOMER NAME");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "input", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function CreateClientComponent_div_2_Template_input_ngModelChange_7_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r106); const ctx_r105 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r105.client.clientName = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "mat-form-field", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "PHONE NUMBER");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "input", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function CreateClientComponent_div_2_Template_input_ngModelChange_12_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r106); const ctx_r107 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r107.client.phone = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "mat-form-field", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "VILLAGE");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "input", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function CreateClientComponent_div_2_Template_input_ngModelChange_17_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r106); const ctx_r108 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r108.client.village = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "mat-form-field", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](21, "Photo");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "input", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function CreateClientComponent_div_2_Template_input_ngModelChange_22_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r106); const ctx_r109 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r109.client.photo = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CreateClientComponent_div_2_Template_button_click_25_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r106); const ctx_r110 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r110.updateClient(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "Update");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CreateClientComponent_div_2_Template_button_click_28_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r106); const ctx_r111 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r111.closeDialog(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29, "Cancel");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r102 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r102.client.clientName);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r102.client.phone);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r102.client.village);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r102.client.photo);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", "warn");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", "primary");
} }
function CreateClientComponent_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    const _r113 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Sure to delete ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "?");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CreateClientComponent_ng_template_3_Template_button_click_9_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r113); const ctx_r112 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r112.confirmDelete(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "Yes");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CreateClientComponent_ng_template_3_Template_button_click_12_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r113); const ctx_r114 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r114.closeDialog(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "No Thanks");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r104 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r104.title);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", "warn");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", "primary");
} }
class CreateClientComponent {
    constructor(dialogRef, BO) {
        this.dialogRef = dialogRef;
        this.BO = BO;
        this.formSubmit = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
    ngOnInit() {
        this.client = this.BO.client;
        this.title = this.client.clientName;
        this.action = this.BO.action;
    }
    updateClient() {
        this.dialogRef.close({ event: this.action, data: this.client });
    }
    confirmDelete() {
        this.dialogRef.close({ event: this.action, data: this.client });
    }
    closeDialog() {
        this.dialogRef.close({ event: 'Cancel' });
    }
}
CreateClientComponent.ɵfac = function CreateClientComponent_Factory(t) { return new (t || CreateClientComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"], 8)); };
CreateClientComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: CreateClientComponent, selectors: [["app-create-client"]], outputs: { formSubmit: "formSubmit" }, decls: 5, vars: 3, consts: [["mat-dialog-title", "", 4, "ngIf"], ["mat-dialog-content", ""], [4, "ngIf", "ngIfElse"], ["deleteTemplate", ""], ["mat-dialog-title", ""], [1, "container", 2, "height", "150px"], [1, "row"], [1, "col"], ["appearance", "outline"], ["required", "", "type", "text", "name", "clientName", "id", "clientName", "matInput", "", "placeholder", "CUSTOMER NAME", 3, "ngModel", "ngModelChange"], ["required", "", "type", "text", "name", "phone", "id", "phone", "matInput", "", "placeholder", "Phone Number", 3, "ngModel", "ngModelChange"], ["required", "", "type", "text", "name", "village", "id", "village", "matInput", "", "placeholder", "VILLAGE", 3, "ngModel", "ngModelChange"], [1, "col", 2, "display", "none"], ["type", "text", "name", "Photo", "id", "Photo", "matInput", "", "placeholder", "Photo", 3, "ngModel", "ngModelChange"], [1, "row", "center-align-field", "justify-content-center"], [1, "mr-3"], ["mat-raised-button", "", "cdkFocusInitial", "", 3, "color", "click"], ["mat-stroked-button", "", 3, "color", "click"], [1, "container"]], template: function CreateClientComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, CreateClientComponent_h1_0_Template, 3, 1, "h1", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, CreateClientComponent_div_2_Template, 30, 6, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, CreateClientComponent_ng_template_3_Template, 14, 3, "ng-template", null, 3, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        const _r103 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.action != "Delete");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.action != "Delete")("ngIfElse", _r103);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogContent"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogTitle"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_3__["MatFormField"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_3__["MatLabel"], _angular_material_input__WEBPACK_IMPORTED_MODULE_4__["MatInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["RequiredValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgModel"], _angular_material_button__WEBPACK_IMPORTED_MODULE_6__["MatButton"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL1BhZ2VzL0FkbWluL0NyZWF0ZS9jcmVhdGUtY2xpZW50L2NyZWF0ZS1jbGllbnQuY29tcG9uZW50LnNjc3MifQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CreateClientComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-create-client',
                templateUrl: './create-client.component.html',
                styleUrls: ['./create-client.component.scss']
            }]
    }], function () { return [{ type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"] }, { type: ClientUpdateBO, decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
            }, {
                type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
                args: [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"]]
            }] }]; }, { formSubmit: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }] }); })();
class ClientUpdateBO {
    constructor(client = null, action = "") {
        this.client = client;
        this.action = action;
    }
}


/***/ }),

/***/ "./src/app/Pages/Admin/Create/create-computer-operator/create-computer-operator.component.ts":
/*!***************************************************************************************************!*\
  !*** ./src/app/Pages/Admin/Create/create-computer-operator/create-computer-operator.component.ts ***!
  \***************************************************************************************************/
/*! exports provided: CreateComputerOperatorComponent, UserUpdateBO */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateComputerOperatorComponent", function() { return CreateComputerOperatorComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserUpdateBO", function() { return UserUpdateBO; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/dialog.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/form-field.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/input.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");









function CreateComputerOperatorComponent_h1_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "h1", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r65 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Update User : ", ctx_r65.title, "");
} }
function CreateComputerOperatorComponent_div_2_Template(rf, ctx) { if (rf & 1) {
    const _r70 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "mat-form-field", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "Username");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "input", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function CreateComputerOperatorComponent_div_2_Template_input_ngModelChange_7_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r70); const ctx_r69 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r69.user.username = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "mat-form-field", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "First Name");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "input", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function CreateComputerOperatorComponent_div_2_Template_input_ngModelChange_12_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r70); const ctx_r71 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r71.user.firstName = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "mat-form-field", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "Last Name");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "input", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function CreateComputerOperatorComponent_div_2_Template_input_ngModelChange_17_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r70); const ctx_r72 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r72.user.lastName = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "mat-form-field", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](21, "Photo");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "input", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function CreateComputerOperatorComponent_div_2_Template_input_ngModelChange_22_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r70); const ctx_r73 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r73.user.photo = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CreateComputerOperatorComponent_div_2_Template_button_click_25_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r70); const ctx_r74 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r74.updateUser(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "Update");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CreateComputerOperatorComponent_div_2_Template_button_click_28_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r70); const ctx_r75 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r75.closeDialog(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29, "Cancel");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r66 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r66.user.username);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r66.user.firstName);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r66.user.lastName);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r66.user.photo);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", "warn");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", "primary");
} }
function CreateComputerOperatorComponent_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    const _r77 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Sure to delete ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "?");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CreateComputerOperatorComponent_ng_template_3_Template_button_click_9_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r77); const ctx_r76 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r76.confirmDelete(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "Yes");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CreateComputerOperatorComponent_ng_template_3_Template_button_click_12_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r77); const ctx_r78 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r78.closeDialog(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "No Thanks");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r68 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r68.title);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", "warn");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", "primary");
} }
class CreateComputerOperatorComponent {
    constructor(dialogRef, BO) {
        this.dialogRef = dialogRef;
        this.BO = BO;
        this.formSubmit = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
    ngOnInit() {
        this.user = this.BO.user;
        this.title = this.user.firstName + ' ' + this.user.lastName;
        this.action = this.BO.action;
    }
    updateUser() {
        this.dialogRef.close({ event: this.action, data: this.user });
    }
    confirmDelete() {
        this.dialogRef.close({ event: this.action, data: this.user });
    }
    closeDialog() {
        this.dialogRef.close({ event: 'Cancel' });
    }
}
CreateComputerOperatorComponent.ɵfac = function CreateComputerOperatorComponent_Factory(t) { return new (t || CreateComputerOperatorComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"], 8)); };
CreateComputerOperatorComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: CreateComputerOperatorComponent, selectors: [["app-create-computer-operator"]], outputs: { formSubmit: "formSubmit" }, decls: 5, vars: 3, consts: [["mat-dialog-title", "", 4, "ngIf"], ["mat-dialog-content", ""], [4, "ngIf", "ngIfElse"], ["deleteTemplate", ""], ["mat-dialog-title", ""], [1, "container", 2, "height", "150px"], [1, "row"], [1, "col"], ["appearance", "outline"], ["required", "", "type", "text", "name", "username", "id", "username", "matInput", "", "placeholder", "UserName", 3, "ngModel", "ngModelChange"], ["required", "", "type", "text", "name", "firstName", "id", "firstName", "matInput", "", "placeholder", "First Name", 3, "ngModel", "ngModelChange"], ["required", "", "type", "text", "name", "lastName", "id", "lastName", "matInput", "", "placeholder", "Last Name", 3, "ngModel", "ngModelChange"], [1, "col", 2, "display", "none"], ["type", "text", "name", "Photo", "id", "Photo", "matInput", "", "placeholder", "Photo", 3, "ngModel", "ngModelChange"], [1, "row", "center-align-field", "justify-content-center"], [1, "mr-3"], ["mat-raised-button", "", "cdkFocusInitial", "", 3, "color", "click"], ["mat-stroked-button", "", 3, "color", "click"], [1, "container"]], template: function CreateComputerOperatorComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, CreateComputerOperatorComponent_h1_0_Template, 3, 1, "h1", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, CreateComputerOperatorComponent_div_2_Template, 30, 6, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, CreateComputerOperatorComponent_ng_template_3_Template, 14, 3, "ng-template", null, 3, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        const _r67 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.action != "Delete");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.action != "Delete")("ngIfElse", _r67);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogContent"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogTitle"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_3__["MatFormField"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_3__["MatLabel"], _angular_material_input__WEBPACK_IMPORTED_MODULE_4__["MatInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["RequiredValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgModel"], _angular_material_button__WEBPACK_IMPORTED_MODULE_6__["MatButton"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL1BhZ2VzL0FkbWluL0NyZWF0ZS9jcmVhdGUtY29tcHV0ZXItb3BlcmF0b3IvY3JlYXRlLWNvbXB1dGVyLW9wZXJhdG9yLmNvbXBvbmVudC5zY3NzIn0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CreateComputerOperatorComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-create-computer-operator',
                templateUrl: './create-computer-operator.component.html',
                styleUrls: ['./create-computer-operator.component.scss']
            }]
    }], function () { return [{ type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"] }, { type: UserUpdateBO, decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
            }, {
                type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
                args: [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"]]
            }] }]; }, { formSubmit: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }] }); })();
class UserUpdateBO {
    constructor(user = null, action = "") {
        this.user = user;
        this.action = action;
    }
}


/***/ }),

/***/ "./src/app/Pages/Admin/Create/create-service-type/create-service-type.component.ts":
/*!*****************************************************************************************!*\
  !*** ./src/app/Pages/Admin/Create/create-service-type/create-service-type.component.ts ***!
  \*****************************************************************************************/
/*! exports provided: CreateServiceTypeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateServiceTypeComponent", function() { return CreateServiceTypeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


class CreateServiceTypeComponent {
    constructor() {
    }
    ngOnInit() {
    }
}
CreateServiceTypeComponent.ɵfac = function CreateServiceTypeComponent_Factory(t) { return new (t || CreateServiceTypeComponent)(); };
CreateServiceTypeComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: CreateServiceTypeComponent, selectors: [["app-create-service-type"]], decls: 2, vars: 0, template: function CreateServiceTypeComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "create-service-type works!");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL1BhZ2VzL0FkbWluL0NyZWF0ZS9jcmVhdGUtc2VydmljZS10eXBlL2NyZWF0ZS1zZXJ2aWNlLXR5cGUuY29tcG9uZW50LnNjc3MifQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CreateServiceTypeComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-create-service-type',
                templateUrl: './create-service-type.component.html',
                styleUrls: ['./create-service-type.component.scss']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/Pages/Admin/Create/create-transaction-type/create-transaction-type.component.ts":
/*!*************************************************************************************************!*\
  !*** ./src/app/Pages/Admin/Create/create-transaction-type/create-transaction-type.component.ts ***!
  \*************************************************************************************************/
/*! exports provided: CreateTransactionTypeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateTransactionTypeComponent", function() { return CreateTransactionTypeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


class CreateTransactionTypeComponent {
    constructor() {
    }
    ngOnInit() {
    }
}
CreateTransactionTypeComponent.ɵfac = function CreateTransactionTypeComponent_Factory(t) { return new (t || CreateTransactionTypeComponent)(); };
CreateTransactionTypeComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: CreateTransactionTypeComponent, selectors: [["app-create-transaction-type"]], decls: 2, vars: 0, template: function CreateTransactionTypeComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "create-transaction-type works!");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL1BhZ2VzL0FkbWluL0NyZWF0ZS9jcmVhdGUtdHJhbnNhY3Rpb24tdHlwZS9jcmVhdGUtdHJhbnNhY3Rpb24tdHlwZS5jb21wb25lbnQuc2NzcyJ9 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CreateTransactionTypeComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-create-transaction-type',
                templateUrl: './create-transaction-type.component.html',
                styleUrls: ['./create-transaction-type.component.scss']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/Pages/Admin/edit-client/edit-client.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/Pages/Admin/edit-client/edit-client.component.ts ***!
  \******************************************************************/
/*! exports provided: EditClientComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditClientComponent", function() { return EditClientComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_Models__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/Models */ "./src/app/Models/index.ts");
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/table */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/table.js");
/* harmony import */ var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/paginator */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/paginator.js");
/* harmony import */ var _Create_create_client_create_client_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Create/create-client/create-client.component */ "./src/app/Pages/Admin/Create/create-client/create-client.component.ts");
/* harmony import */ var _Common_PopUps_add_new_client_add_new_client_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../Common/PopUps/add-new-client/add-new-client.component */ "./src/app/Pages/Common/PopUps/add-new-client/add-new-client.component.ts");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/dialog.js");
/* harmony import */ var src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/Services/Alert/alert.service */ "./src/app/Services/Alert/alert.service.ts");
/* harmony import */ var src_app_Services_common_client_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/Services/common/client.service */ "./src/app/Services/common/client.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");














function EditClientComponent_div_3_th_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " Action ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function EditClientComponent_div_3_td_5_Template(rf, ctx) { if (rf & 1) {
    const _r159 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "button", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function EditClientComponent_div_3_td_5_Template_button_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r159); const element_r157 = ctx.$implicit; const ctx_r158 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r158.openDialog("Update", element_r157); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "i", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "button", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function EditClientComponent_div_3_td_5_Template_button_click_3_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r159); const element_r157 = ctx.$implicit; const ctx_r160 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r160.openDialog("Delete", element_r157); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "i", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function EditClientComponent_div_3_th_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " CUSTOMER ID ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function EditClientComponent_div_3_td_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r161 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", element_r161.id, " ");
} }
function EditClientComponent_div_3_th_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " CUSTOMER NAME ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function EditClientComponent_div_3_td_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r162 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", element_r162.clientName, " ");
} }
function EditClientComponent_div_3_th_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " PHONE NUMBER ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function EditClientComponent_div_3_td_14_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r163 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", element_r163.phone, " ");
} }
function EditClientComponent_div_3_th_16_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " VILLAGE ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function EditClientComponent_div_3_td_17_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r164 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", element_r164.village, " ");
} }
function EditClientComponent_div_3_tr_18_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "tr", 25);
} }
function EditClientComponent_div_3_tr_19_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "tr", 26);
} }
const _c0 = function () { return [5, 10, 20, 50]; };
function EditClientComponent_div_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "table", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](3, 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, EditClientComponent_div_3_th_4_Template, 2, 0, "th", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, EditClientComponent_div_3_td_5_Template, 5, 0, "td", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](6, 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, EditClientComponent_div_3_th_7_Template, 2, 0, "th", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, EditClientComponent_div_3_td_8_Template, 2, 1, "td", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](9, 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](10, EditClientComponent_div_3_th_10_Template, 2, 0, "th", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](11, EditClientComponent_div_3_td_11_Template, 2, 1, "td", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](12, 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](13, EditClientComponent_div_3_th_13_Template, 2, 0, "th", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](14, EditClientComponent_div_3_td_14_Template, 2, 1, "td", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](15, 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](16, EditClientComponent_div_3_th_16_Template, 2, 0, "th", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](17, EditClientComponent_div_3_td_17_Template, 2, 1, "td", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](18, EditClientComponent_div_3_tr_18_Template, 1, 0, "tr", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](19, EditClientComponent_div_3_tr_19_Template, 1, 0, "tr", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](20, "mat-paginator", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r144 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("dataSource", ctx_r144.dataSource);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matHeaderRowDef", ctx_r144.displayedColumns)("matHeaderRowDefSticky", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matRowDefColumns", ctx_r144.displayedColumns);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("pageSizeOptions", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](5, _c0));
} }
class EditClientComponent {
    constructor(dialog, alertService, clientService) {
        this.dialog = dialog;
        this.alertService = alertService;
        this.clientService = clientService;
        this.displayedColumns = [
            "actionsColumn",
            "id",
            "clientName",
            "phone",
            "village",
        ];
    }
    ngOnInit() {
        this.GetClients();
    }
    refreshData() {
        this.dataSource = new _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatTableDataSource"](this.clients);
        setTimeout(() => (this.dataSource.paginator = this.paginator));
    }
    GetClients() {
        this.clientService.getClients().subscribe((data) => {
            this.clients = data.clientsFromRepo.map((item) => {
                return new src_app_Models__WEBPACK_IMPORTED_MODULE_1__["Client"](item.id, item.clientName, item.phone, item.village, item.photo, 0);
            });
            this.refreshData();
        });
    }
    openDialog(action, obj) {
        this.BO = new _Create_create_client_create_client_component__WEBPACK_IMPORTED_MODULE_4__["ClientUpdateBO"]();
        this.BO.action = action;
        this.BO.client = new src_app_Models__WEBPACK_IMPORTED_MODULE_1__["Client"](obj.id, obj.clientName, obj.phone, obj.village, obj.photo, obj.balance);
        if (action == "Delete")
            this.dialogWidth = "250px";
        else if (action == "Update")
            this.dialogWidth = "100%";
        const dialogRef = this.dialog.open(_Common_PopUps_add_new_client_add_new_client_component__WEBPACK_IMPORTED_MODULE_5__["AddNewClientComponent"], {
            width: this.dialogWidth,
            data: this.BO,
            disableClose: true,
        });
        dialogRef.afterClosed().subscribe((result) => {
            if (result.event == "Update") {
                this.updateRowData(result.data);
            }
            else if (result.event == "Delete") {
                this.deleteRowData(result.data);
            }
            else if (result.event == "Cancel") {
                this.alertService.info("Update has been cancelled");
            }
        });
    }
    updateRowData(data) {
        this.clients = data.map((item) => {
            return new src_app_Models__WEBPACK_IMPORTED_MODULE_1__["Client"](item.id, item.clientName, item.phone, item.village, item.photo, 0);
        });
        this.refreshData();
        this.alertService.success("Client has been update successfully");
    }
    deleteRowData(returnClient) {
        this.clientService.deleteClient(returnClient).subscribe((data) => {
            this.clients = data.map((item) => {
                return new src_app_Models__WEBPACK_IMPORTED_MODULE_1__["Client"](item.id, item.clientName, item.phone, item.village, item.photo, 0);
            });
            this.refreshData();
            this.alertService.success("User has been deleted successfully");
        }, (error) => {
            this.alertService.success(error.error);
        });
    }
}
EditClientComponent.ɵfac = function EditClientComponent_Factory(t) { return new (t || EditClientComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__["MatDialog"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_7__["AlertService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_common_client_service__WEBPACK_IMPORTED_MODULE_8__["ClientService"])); };
EditClientComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: EditClientComponent, selectors: [["app-edit-client"]], viewQuery: function EditClientComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_angular_material_paginator__WEBPACK_IMPORTED_MODULE_3__["MatPaginator"], true);
    } if (rf & 2) {
        var _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.paginator = _t.first);
    } }, inputs: { clients: "clients" }, decls: 4, vars: 1, consts: [[1, "text-center"], [1, "d-flex", "justify-content-center"], ["class", "budget-items", 4, "ngIf"], [1, "budget-items"], [1, "mat-elevation-z8"], ["mat-table", "", 3, "dataSource"], ["matColumnDef", "actionsColumn"], ["mat-header-cell", "", "class", "w-10", 4, "matHeaderCellDef"], ["mat-cell", "", 4, "matCellDef"], ["matColumnDef", "id"], ["mat-header-cell", "", "class", "w-4", 4, "matHeaderCellDef"], ["matColumnDef", "clientName"], ["matColumnDef", "phone"], ["mat-header-cell", "", "class", "w-15", 4, "matHeaderCellDef"], ["matColumnDef", "village"], ["mat-header-row", "", 4, "matHeaderRowDef", "matHeaderRowDefSticky"], ["mat-row", "", 4, "matRowDef", "matRowDefColumns"], ["showFirstLastButtons", "", 3, "pageSizeOptions"], ["mat-header-cell", "", 1, "w-10"], ["mat-cell", ""], ["mat-icon-button", "", "color", "primary", "focusable", "false", 3, "click"], [1, "fa", "fa-pencil", "mat-icon"], [1, "fa", "fa-trash", "mat-icon"], ["mat-header-cell", "", 1, "w-4"], ["mat-header-cell", "", 1, "w-15"], ["mat-header-row", ""], ["mat-row", ""]], template: function EditClientComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "h2", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Edit Customer");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, EditClientComponent_div_3_Template, 21, 6, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.clients && ctx.clients.length > 0);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_9__["NgIf"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatTable"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatColumnDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatHeaderCellDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatCellDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatHeaderRowDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatRowDef"], _angular_material_paginator__WEBPACK_IMPORTED_MODULE_3__["MatPaginator"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatHeaderCell"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatCell"], _angular_material_button__WEBPACK_IMPORTED_MODULE_10__["MatButton"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatHeaderRow"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatRow"]], styles: ["table[_ngcontent-%COMP%] {\n  width: 100%;\n}\n\n.budget-items[_ngcontent-%COMP%] {\n  width: 90%;\n}\n\n.w-0[_ngcontent-%COMP%] {\n  width: 0%;\n}\n\n.w-1[_ngcontent-%COMP%] {\n  width: 1%;\n}\n\n.w-2[_ngcontent-%COMP%] {\n  width: 2%;\n}\n\n.w-3[_ngcontent-%COMP%] {\n  width: 3%;\n}\n\n.w-4[_ngcontent-%COMP%] {\n  width: 4%;\n}\n\n.w-5[_ngcontent-%COMP%] {\n  width: 5%;\n}\n\n.w-6[_ngcontent-%COMP%] {\n  width: 6%;\n}\n\n.w-7[_ngcontent-%COMP%] {\n  width: 7%;\n}\n\n.w-8[_ngcontent-%COMP%] {\n  width: 8%;\n}\n\n.w-9[_ngcontent-%COMP%] {\n  width: 9%;\n}\n\n.w-10[_ngcontent-%COMP%] {\n  width: 10%;\n}\n\n.w-11[_ngcontent-%COMP%] {\n  width: 11%;\n}\n\n.w-12[_ngcontent-%COMP%] {\n  width: 12%;\n}\n\n.w-13[_ngcontent-%COMP%] {\n  width: 13%;\n}\n\n.w-14[_ngcontent-%COMP%] {\n  width: 14%;\n}\n\n.w-15[_ngcontent-%COMP%] {\n  width: 15%;\n}\n\n.w-16[_ngcontent-%COMP%] {\n  width: 16%;\n}\n\n.w-17[_ngcontent-%COMP%] {\n  width: 17%;\n}\n\n.w-18[_ngcontent-%COMP%] {\n  width: 18%;\n}\n\n.w-19[_ngcontent-%COMP%] {\n  width: 19%;\n}\n\n.w-20[_ngcontent-%COMP%] {\n  width: 20%;\n}\n\n.w-21[_ngcontent-%COMP%] {\n  width: 21%;\n}\n\n.w-22[_ngcontent-%COMP%] {\n  width: 22%;\n}\n\n.w-23[_ngcontent-%COMP%] {\n  width: 23%;\n}\n\n.w-24[_ngcontent-%COMP%] {\n  width: 24%;\n}\n\n.w-25[_ngcontent-%COMP%] {\n  width: 25%;\n}\n\n.w-26[_ngcontent-%COMP%] {\n  width: 26%;\n}\n\n.w-27[_ngcontent-%COMP%] {\n  width: 27%;\n}\n\n.w-28[_ngcontent-%COMP%] {\n  width: 28%;\n}\n\n.w-29[_ngcontent-%COMP%] {\n  width: 29%;\n}\n\n.w-30[_ngcontent-%COMP%] {\n  width: 30%;\n}\n\n.w-31[_ngcontent-%COMP%] {\n  width: 31%;\n}\n\n.w-32[_ngcontent-%COMP%] {\n  width: 32%;\n}\n\n.w-33[_ngcontent-%COMP%] {\n  width: 33%;\n}\n\n.w-34[_ngcontent-%COMP%] {\n  width: 34%;\n}\n\n.w-35[_ngcontent-%COMP%] {\n  width: 35%;\n}\n\n.w-36[_ngcontent-%COMP%] {\n  width: 36%;\n}\n\n.w-37[_ngcontent-%COMP%] {\n  width: 37%;\n}\n\n.w-38[_ngcontent-%COMP%] {\n  width: 38%;\n}\n\n.w-39[_ngcontent-%COMP%] {\n  width: 39%;\n}\n\n.w-40[_ngcontent-%COMP%] {\n  width: 40%;\n}\n\n.w-41[_ngcontent-%COMP%] {\n  width: 41%;\n}\n\n.w-42[_ngcontent-%COMP%] {\n  width: 42%;\n}\n\n.w-43[_ngcontent-%COMP%] {\n  width: 43%;\n}\n\n.w-44[_ngcontent-%COMP%] {\n  width: 44%;\n}\n\n.w-45[_ngcontent-%COMP%] {\n  width: 45%;\n}\n\n.w-46[_ngcontent-%COMP%] {\n  width: 46%;\n}\n\n.w-47[_ngcontent-%COMP%] {\n  width: 47%;\n}\n\n.w-48[_ngcontent-%COMP%] {\n  width: 48%;\n}\n\n.w-49[_ngcontent-%COMP%] {\n  width: 49%;\n}\n\n.w-50[_ngcontent-%COMP%] {\n  width: 50%;\n}\n\n.w-51[_ngcontent-%COMP%] {\n  width: 51%;\n}\n\n.w-52[_ngcontent-%COMP%] {\n  width: 52%;\n}\n\n.w-53[_ngcontent-%COMP%] {\n  width: 53%;\n}\n\n.w-54[_ngcontent-%COMP%] {\n  width: 54%;\n}\n\n.w-55[_ngcontent-%COMP%] {\n  width: 55%;\n}\n\n.w-56[_ngcontent-%COMP%] {\n  width: 56%;\n}\n\n.w-57[_ngcontent-%COMP%] {\n  width: 57%;\n}\n\n.w-58[_ngcontent-%COMP%] {\n  width: 58%;\n}\n\n.w-59[_ngcontent-%COMP%] {\n  width: 59%;\n}\n\n.w-60[_ngcontent-%COMP%] {\n  width: 60%;\n}\n\n.w-61[_ngcontent-%COMP%] {\n  width: 61%;\n}\n\n.w-62[_ngcontent-%COMP%] {\n  width: 62%;\n}\n\n.w-63[_ngcontent-%COMP%] {\n  width: 63%;\n}\n\n.w-64[_ngcontent-%COMP%] {\n  width: 64%;\n}\n\n.w-65[_ngcontent-%COMP%] {\n  width: 65%;\n}\n\n.w-66[_ngcontent-%COMP%] {\n  width: 66%;\n}\n\n.w-67[_ngcontent-%COMP%] {\n  width: 67%;\n}\n\n.w-68[_ngcontent-%COMP%] {\n  width: 68%;\n}\n\n.w-69[_ngcontent-%COMP%] {\n  width: 69%;\n}\n\n.w-70[_ngcontent-%COMP%] {\n  width: 70%;\n}\n\n.w-71[_ngcontent-%COMP%] {\n  width: 71%;\n}\n\n.w-72[_ngcontent-%COMP%] {\n  width: 72%;\n}\n\n.w-73[_ngcontent-%COMP%] {\n  width: 73%;\n}\n\n.w-74[_ngcontent-%COMP%] {\n  width: 74%;\n}\n\n.w-75[_ngcontent-%COMP%] {\n  width: 75%;\n}\n\n.w-76[_ngcontent-%COMP%] {\n  width: 76%;\n}\n\n.w-77[_ngcontent-%COMP%] {\n  width: 77%;\n}\n\n.w-78[_ngcontent-%COMP%] {\n  width: 78%;\n}\n\n.w-79[_ngcontent-%COMP%] {\n  width: 79%;\n}\n\n.w-80[_ngcontent-%COMP%] {\n  width: 80%;\n}\n\n.w-81[_ngcontent-%COMP%] {\n  width: 81%;\n}\n\n.w-82[_ngcontent-%COMP%] {\n  width: 82%;\n}\n\n.w-83[_ngcontent-%COMP%] {\n  width: 83%;\n}\n\n.w-84[_ngcontent-%COMP%] {\n  width: 84%;\n}\n\n.w-85[_ngcontent-%COMP%] {\n  width: 85%;\n}\n\n.w-86[_ngcontent-%COMP%] {\n  width: 86%;\n}\n\n.w-87[_ngcontent-%COMP%] {\n  width: 87%;\n}\n\n.w-88[_ngcontent-%COMP%] {\n  width: 88%;\n}\n\n.w-89[_ngcontent-%COMP%] {\n  width: 89%;\n}\n\n.w-90[_ngcontent-%COMP%] {\n  width: 90%;\n}\n\n.w-91[_ngcontent-%COMP%] {\n  width: 91%;\n}\n\n.w-92[_ngcontent-%COMP%] {\n  width: 92%;\n}\n\n.w-93[_ngcontent-%COMP%] {\n  width: 93%;\n}\n\n.w-94[_ngcontent-%COMP%] {\n  width: 94%;\n}\n\n.w-95[_ngcontent-%COMP%] {\n  width: 95%;\n}\n\n.w-96[_ngcontent-%COMP%] {\n  width: 96%;\n}\n\n.w-97[_ngcontent-%COMP%] {\n  width: 97%;\n}\n\n.w-98[_ngcontent-%COMP%] {\n  width: 98%;\n}\n\n.w-99[_ngcontent-%COMP%] {\n  width: 99%;\n}\n\n.w-100[_ngcontent-%COMP%] {\n  width: 100%;\n}\n\n.red[_ngcontent-%COMP%] {\n  color: red;\n}\n\n.green[_ngcontent-%COMP%] {\n  color: green;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUGFnZXMvQWRtaW4vZWRpdC1jbGllbnQvQzpcXERldmVsb3BtZW50XFxTYXR0aVxcRmluYW5jZVRyYWNrZXIvc3JjXFxhcHBcXFBhZ2VzXFxBZG1pblxcZWRpdC1jbGllbnRcXGVkaXQtY2xpZW50LmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9QYWdlcy9BZG1pbi9lZGl0LWNsaWVudC9lZGl0LWNsaWVudC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7QUNDSjs7QURFQTtFQUNJLFVBQUE7QUNDSjs7QURTSTtFQUNJLFNBQUE7QUNOUjs7QURLSTtFQUNJLFNBQUE7QUNGUjs7QURDSTtFQUNJLFNBQUE7QUNFUjs7QURISTtFQUNJLFNBQUE7QUNNUjs7QURQSTtFQUNJLFNBQUE7QUNVUjs7QURYSTtFQUNJLFNBQUE7QUNjUjs7QURmSTtFQUNJLFNBQUE7QUNrQlI7O0FEbkJJO0VBQ0ksU0FBQTtBQ3NCUjs7QUR2Qkk7RUFDSSxTQUFBO0FDMEJSOztBRDNCSTtFQUNJLFNBQUE7QUM4QlI7O0FEL0JJO0VBQ0ksVUFBQTtBQ2tDUjs7QURuQ0k7RUFDSSxVQUFBO0FDc0NSOztBRHZDSTtFQUNJLFVBQUE7QUMwQ1I7O0FEM0NJO0VBQ0ksVUFBQTtBQzhDUjs7QUQvQ0k7RUFDSSxVQUFBO0FDa0RSOztBRG5ESTtFQUNJLFVBQUE7QUNzRFI7O0FEdkRJO0VBQ0ksVUFBQTtBQzBEUjs7QUQzREk7RUFDSSxVQUFBO0FDOERSOztBRC9ESTtFQUNJLFVBQUE7QUNrRVI7O0FEbkVJO0VBQ0ksVUFBQTtBQ3NFUjs7QUR2RUk7RUFDSSxVQUFBO0FDMEVSOztBRDNFSTtFQUNJLFVBQUE7QUM4RVI7O0FEL0VJO0VBQ0ksVUFBQTtBQ2tGUjs7QURuRkk7RUFDSSxVQUFBO0FDc0ZSOztBRHZGSTtFQUNJLFVBQUE7QUMwRlI7O0FEM0ZJO0VBQ0ksVUFBQTtBQzhGUjs7QUQvRkk7RUFDSSxVQUFBO0FDa0dSOztBRG5HSTtFQUNJLFVBQUE7QUNzR1I7O0FEdkdJO0VBQ0ksVUFBQTtBQzBHUjs7QUQzR0k7RUFDSSxVQUFBO0FDOEdSOztBRC9HSTtFQUNJLFVBQUE7QUNrSFI7O0FEbkhJO0VBQ0ksVUFBQTtBQ3NIUjs7QUR2SEk7RUFDSSxVQUFBO0FDMEhSOztBRDNISTtFQUNJLFVBQUE7QUM4SFI7O0FEL0hJO0VBQ0ksVUFBQTtBQ2tJUjs7QURuSUk7RUFDSSxVQUFBO0FDc0lSOztBRHZJSTtFQUNJLFVBQUE7QUMwSVI7O0FEM0lJO0VBQ0ksVUFBQTtBQzhJUjs7QUQvSUk7RUFDSSxVQUFBO0FDa0pSOztBRG5KSTtFQUNJLFVBQUE7QUNzSlI7O0FEdkpJO0VBQ0ksVUFBQTtBQzBKUjs7QUQzSkk7RUFDSSxVQUFBO0FDOEpSOztBRC9KSTtFQUNJLFVBQUE7QUNrS1I7O0FEbktJO0VBQ0ksVUFBQTtBQ3NLUjs7QUR2S0k7RUFDSSxVQUFBO0FDMEtSOztBRDNLSTtFQUNJLFVBQUE7QUM4S1I7O0FEL0tJO0VBQ0ksVUFBQTtBQ2tMUjs7QURuTEk7RUFDSSxVQUFBO0FDc0xSOztBRHZMSTtFQUNJLFVBQUE7QUMwTFI7O0FEM0xJO0VBQ0ksVUFBQTtBQzhMUjs7QUQvTEk7RUFDSSxVQUFBO0FDa01SOztBRG5NSTtFQUNJLFVBQUE7QUNzTVI7O0FEdk1JO0VBQ0ksVUFBQTtBQzBNUjs7QUQzTUk7RUFDSSxVQUFBO0FDOE1SOztBRC9NSTtFQUNJLFVBQUE7QUNrTlI7O0FEbk5JO0VBQ0ksVUFBQTtBQ3NOUjs7QUR2Tkk7RUFDSSxVQUFBO0FDME5SOztBRDNOSTtFQUNJLFVBQUE7QUM4TlI7O0FEL05JO0VBQ0ksVUFBQTtBQ2tPUjs7QURuT0k7RUFDSSxVQUFBO0FDc09SOztBRHZPSTtFQUNJLFVBQUE7QUMwT1I7O0FEM09JO0VBQ0ksVUFBQTtBQzhPUjs7QUQvT0k7RUFDSSxVQUFBO0FDa1BSOztBRG5QSTtFQUNJLFVBQUE7QUNzUFI7O0FEdlBJO0VBQ0ksVUFBQTtBQzBQUjs7QUQzUEk7RUFDSSxVQUFBO0FDOFBSOztBRC9QSTtFQUNJLFVBQUE7QUNrUVI7O0FEblFJO0VBQ0ksVUFBQTtBQ3NRUjs7QUR2UUk7RUFDSSxVQUFBO0FDMFFSOztBRDNRSTtFQUNJLFVBQUE7QUM4UVI7O0FEL1FJO0VBQ0ksVUFBQTtBQ2tSUjs7QURuUkk7RUFDSSxVQUFBO0FDc1JSOztBRHZSSTtFQUNJLFVBQUE7QUMwUlI7O0FEM1JJO0VBQ0ksVUFBQTtBQzhSUjs7QUQvUkk7RUFDSSxVQUFBO0FDa1NSOztBRG5TSTtFQUNJLFVBQUE7QUNzU1I7O0FEdlNJO0VBQ0ksVUFBQTtBQzBTUjs7QUQzU0k7RUFDSSxVQUFBO0FDOFNSOztBRC9TSTtFQUNJLFVBQUE7QUNrVFI7O0FEblRJO0VBQ0ksVUFBQTtBQ3NUUjs7QUR2VEk7RUFDSSxVQUFBO0FDMFRSOztBRDNUSTtFQUNJLFVBQUE7QUM4VFI7O0FEL1RJO0VBQ0ksVUFBQTtBQ2tVUjs7QURuVUk7RUFDSSxVQUFBO0FDc1VSOztBRHZVSTtFQUNJLFVBQUE7QUMwVVI7O0FEM1VJO0VBQ0ksVUFBQTtBQzhVUjs7QUQvVUk7RUFDSSxVQUFBO0FDa1ZSOztBRG5WSTtFQUNJLFVBQUE7QUNzVlI7O0FEdlZJO0VBQ0ksVUFBQTtBQzBWUjs7QUQzVkk7RUFDSSxVQUFBO0FDOFZSOztBRC9WSTtFQUNJLFVBQUE7QUNrV1I7O0FEbldJO0VBQ0ksVUFBQTtBQ3NXUjs7QUR2V0k7RUFDSSxVQUFBO0FDMFdSOztBRDNXSTtFQUNJLFVBQUE7QUM4V1I7O0FEL1dJO0VBQ0ksVUFBQTtBQ2tYUjs7QURuWEk7RUFDSSxVQUFBO0FDc1hSOztBRHZYSTtFQUNJLFVBQUE7QUMwWFI7O0FEM1hJO0VBQ0ksVUFBQTtBQzhYUjs7QUQvWEk7RUFDSSxVQUFBO0FDa1lSOztBRG5ZSTtFQUNJLFVBQUE7QUNzWVI7O0FEdllJO0VBQ0ksV0FBQTtBQzBZUjs7QURwWUE7RUFDSSxVQUFBO0FDdVlKOztBRHJZQTtFQUNJLFlBQUE7QUN3WUoiLCJmaWxlIjoic3JjL2FwcC9QYWdlcy9BZG1pbi9lZGl0LWNsaWVudC9lZGl0LWNsaWVudC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbInRhYmxlIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG4uYnVkZ2V0LWl0ZW1zIHtcclxuICAgIHdpZHRoOiA5MCU7XHJcbn1cclxuXHJcbkBtaXhpbiBkeW53aWR0aHMoJG1heHNpemUpIHtcclxuICAgIEBmb3IgJGkgZnJvbSAwIHRocm91Z2ggJG1heHNpemUge1xyXG4gICAgICAgIEBpbmNsdWRlIHdpZHRoLWNsYXNzKCRpKTtcclxuICAgIH1cclxufVxyXG5cclxuQG1peGluIHdpZHRoLWNsYXNzKCRzaXplKSB7XHJcbiAgICAudy0jeyRzaXplfSB7XHJcbiAgICAgICAgd2lkdGg6ICRzaXplICogMSU7XHJcbiAgICB9XHJcbn1cclxuXHJcbkBpbmNsdWRlIGR5bndpZHRocygxMDApO1xyXG5cclxuLnJlZCB7XHJcbiAgICBjb2xvcjogcmVkO1xyXG59XHJcbi5ncmVlbiB7XHJcbiAgICBjb2xvcjogZ3JlZW47XHJcbn1cclxuIiwidGFibGUge1xuICB3aWR0aDogMTAwJTtcbn1cblxuLmJ1ZGdldC1pdGVtcyB7XG4gIHdpZHRoOiA5MCU7XG59XG5cbi53LTAge1xuICB3aWR0aDogMCU7XG59XG5cbi53LTEge1xuICB3aWR0aDogMSU7XG59XG5cbi53LTIge1xuICB3aWR0aDogMiU7XG59XG5cbi53LTMge1xuICB3aWR0aDogMyU7XG59XG5cbi53LTQge1xuICB3aWR0aDogNCU7XG59XG5cbi53LTUge1xuICB3aWR0aDogNSU7XG59XG5cbi53LTYge1xuICB3aWR0aDogNiU7XG59XG5cbi53LTcge1xuICB3aWR0aDogNyU7XG59XG5cbi53LTgge1xuICB3aWR0aDogOCU7XG59XG5cbi53LTkge1xuICB3aWR0aDogOSU7XG59XG5cbi53LTEwIHtcbiAgd2lkdGg6IDEwJTtcbn1cblxuLnctMTEge1xuICB3aWR0aDogMTElO1xufVxuXG4udy0xMiB7XG4gIHdpZHRoOiAxMiU7XG59XG5cbi53LTEzIHtcbiAgd2lkdGg6IDEzJTtcbn1cblxuLnctMTQge1xuICB3aWR0aDogMTQlO1xufVxuXG4udy0xNSB7XG4gIHdpZHRoOiAxNSU7XG59XG5cbi53LTE2IHtcbiAgd2lkdGg6IDE2JTtcbn1cblxuLnctMTcge1xuICB3aWR0aDogMTclO1xufVxuXG4udy0xOCB7XG4gIHdpZHRoOiAxOCU7XG59XG5cbi53LTE5IHtcbiAgd2lkdGg6IDE5JTtcbn1cblxuLnctMjAge1xuICB3aWR0aDogMjAlO1xufVxuXG4udy0yMSB7XG4gIHdpZHRoOiAyMSU7XG59XG5cbi53LTIyIHtcbiAgd2lkdGg6IDIyJTtcbn1cblxuLnctMjMge1xuICB3aWR0aDogMjMlO1xufVxuXG4udy0yNCB7XG4gIHdpZHRoOiAyNCU7XG59XG5cbi53LTI1IHtcbiAgd2lkdGg6IDI1JTtcbn1cblxuLnctMjYge1xuICB3aWR0aDogMjYlO1xufVxuXG4udy0yNyB7XG4gIHdpZHRoOiAyNyU7XG59XG5cbi53LTI4IHtcbiAgd2lkdGg6IDI4JTtcbn1cblxuLnctMjkge1xuICB3aWR0aDogMjklO1xufVxuXG4udy0zMCB7XG4gIHdpZHRoOiAzMCU7XG59XG5cbi53LTMxIHtcbiAgd2lkdGg6IDMxJTtcbn1cblxuLnctMzIge1xuICB3aWR0aDogMzIlO1xufVxuXG4udy0zMyB7XG4gIHdpZHRoOiAzMyU7XG59XG5cbi53LTM0IHtcbiAgd2lkdGg6IDM0JTtcbn1cblxuLnctMzUge1xuICB3aWR0aDogMzUlO1xufVxuXG4udy0zNiB7XG4gIHdpZHRoOiAzNiU7XG59XG5cbi53LTM3IHtcbiAgd2lkdGg6IDM3JTtcbn1cblxuLnctMzgge1xuICB3aWR0aDogMzglO1xufVxuXG4udy0zOSB7XG4gIHdpZHRoOiAzOSU7XG59XG5cbi53LTQwIHtcbiAgd2lkdGg6IDQwJTtcbn1cblxuLnctNDEge1xuICB3aWR0aDogNDElO1xufVxuXG4udy00MiB7XG4gIHdpZHRoOiA0MiU7XG59XG5cbi53LTQzIHtcbiAgd2lkdGg6IDQzJTtcbn1cblxuLnctNDQge1xuICB3aWR0aDogNDQlO1xufVxuXG4udy00NSB7XG4gIHdpZHRoOiA0NSU7XG59XG5cbi53LTQ2IHtcbiAgd2lkdGg6IDQ2JTtcbn1cblxuLnctNDcge1xuICB3aWR0aDogNDclO1xufVxuXG4udy00OCB7XG4gIHdpZHRoOiA0OCU7XG59XG5cbi53LTQ5IHtcbiAgd2lkdGg6IDQ5JTtcbn1cblxuLnctNTAge1xuICB3aWR0aDogNTAlO1xufVxuXG4udy01MSB7XG4gIHdpZHRoOiA1MSU7XG59XG5cbi53LTUyIHtcbiAgd2lkdGg6IDUyJTtcbn1cblxuLnctNTMge1xuICB3aWR0aDogNTMlO1xufVxuXG4udy01NCB7XG4gIHdpZHRoOiA1NCU7XG59XG5cbi53LTU1IHtcbiAgd2lkdGg6IDU1JTtcbn1cblxuLnctNTYge1xuICB3aWR0aDogNTYlO1xufVxuXG4udy01NyB7XG4gIHdpZHRoOiA1NyU7XG59XG5cbi53LTU4IHtcbiAgd2lkdGg6IDU4JTtcbn1cblxuLnctNTkge1xuICB3aWR0aDogNTklO1xufVxuXG4udy02MCB7XG4gIHdpZHRoOiA2MCU7XG59XG5cbi53LTYxIHtcbiAgd2lkdGg6IDYxJTtcbn1cblxuLnctNjIge1xuICB3aWR0aDogNjIlO1xufVxuXG4udy02MyB7XG4gIHdpZHRoOiA2MyU7XG59XG5cbi53LTY0IHtcbiAgd2lkdGg6IDY0JTtcbn1cblxuLnctNjUge1xuICB3aWR0aDogNjUlO1xufVxuXG4udy02NiB7XG4gIHdpZHRoOiA2NiU7XG59XG5cbi53LTY3IHtcbiAgd2lkdGg6IDY3JTtcbn1cblxuLnctNjgge1xuICB3aWR0aDogNjglO1xufVxuXG4udy02OSB7XG4gIHdpZHRoOiA2OSU7XG59XG5cbi53LTcwIHtcbiAgd2lkdGg6IDcwJTtcbn1cblxuLnctNzEge1xuICB3aWR0aDogNzElO1xufVxuXG4udy03MiB7XG4gIHdpZHRoOiA3MiU7XG59XG5cbi53LTczIHtcbiAgd2lkdGg6IDczJTtcbn1cblxuLnctNzQge1xuICB3aWR0aDogNzQlO1xufVxuXG4udy03NSB7XG4gIHdpZHRoOiA3NSU7XG59XG5cbi53LTc2IHtcbiAgd2lkdGg6IDc2JTtcbn1cblxuLnctNzcge1xuICB3aWR0aDogNzclO1xufVxuXG4udy03OCB7XG4gIHdpZHRoOiA3OCU7XG59XG5cbi53LTc5IHtcbiAgd2lkdGg6IDc5JTtcbn1cblxuLnctODAge1xuICB3aWR0aDogODAlO1xufVxuXG4udy04MSB7XG4gIHdpZHRoOiA4MSU7XG59XG5cbi53LTgyIHtcbiAgd2lkdGg6IDgyJTtcbn1cblxuLnctODMge1xuICB3aWR0aDogODMlO1xufVxuXG4udy04NCB7XG4gIHdpZHRoOiA4NCU7XG59XG5cbi53LTg1IHtcbiAgd2lkdGg6IDg1JTtcbn1cblxuLnctODYge1xuICB3aWR0aDogODYlO1xufVxuXG4udy04NyB7XG4gIHdpZHRoOiA4NyU7XG59XG5cbi53LTg4IHtcbiAgd2lkdGg6IDg4JTtcbn1cblxuLnctODkge1xuICB3aWR0aDogODklO1xufVxuXG4udy05MCB7XG4gIHdpZHRoOiA5MCU7XG59XG5cbi53LTkxIHtcbiAgd2lkdGg6IDkxJTtcbn1cblxuLnctOTIge1xuICB3aWR0aDogOTIlO1xufVxuXG4udy05MyB7XG4gIHdpZHRoOiA5MyU7XG59XG5cbi53LTk0IHtcbiAgd2lkdGg6IDk0JTtcbn1cblxuLnctOTUge1xuICB3aWR0aDogOTUlO1xufVxuXG4udy05NiB7XG4gIHdpZHRoOiA5NiU7XG59XG5cbi53LTk3IHtcbiAgd2lkdGg6IDk3JTtcbn1cblxuLnctOTgge1xuICB3aWR0aDogOTglO1xufVxuXG4udy05OSB7XG4gIHdpZHRoOiA5OSU7XG59XG5cbi53LTEwMCB7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4ucmVkIHtcbiAgY29sb3I6IHJlZDtcbn1cblxuLmdyZWVuIHtcbiAgY29sb3I6IGdyZWVuO1xufSJdfQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](EditClientComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: "app-edit-client",
                templateUrl: "./edit-client.component.html",
                styleUrls: ["./edit-client.component.scss"],
            }]
    }], function () { return [{ type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__["MatDialog"] }, { type: src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_7__["AlertService"] }, { type: src_app_Services_common_client_service__WEBPACK_IMPORTED_MODULE_8__["ClientService"] }]; }, { clients: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], paginator: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
            args: [_angular_material_paginator__WEBPACK_IMPORTED_MODULE_3__["MatPaginator"], { static: false }]
        }] }); })();


/***/ }),

/***/ "./src/app/Pages/Admin/edit-computer-operator/edit-computer-operator.component.ts":
/*!****************************************************************************************!*\
  !*** ./src/app/Pages/Admin/edit-computer-operator/edit-computer-operator.component.ts ***!
  \****************************************************************************************/
/*! exports provided: EditComputerOperatorComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditComputerOperatorComponent", function() { return EditComputerOperatorComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_Models__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/Models */ "./src/app/Models/index.ts");
/* harmony import */ var _Create_create_computer_operator_create_computer_operator_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Create/create-computer-operator/create-computer-operator.component */ "./src/app/Pages/Admin/Create/create-computer-operator/create-computer-operator.component.ts");
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/table */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/table.js");
/* harmony import */ var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/paginator */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/paginator.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/dialog.js");
/* harmony import */ var src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/Services/Alert/alert.service */ "./src/app/Services/Alert/alert.service.ts");
/* harmony import */ var src_app_Services_common_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/Services/common/user.service */ "./src/app/Services/common/user.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");













function EditComputerOperatorComponent_div_3_th_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " Action ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function EditComputerOperatorComponent_div_3_td_5_Template(rf, ctx) { if (rf & 1) {
    const _r94 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "button", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function EditComputerOperatorComponent_div_3_td_5_Template_button_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r94); const element_r92 = ctx.$implicit; const ctx_r93 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r93.openDialog("Update", element_r92); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "i", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "button", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function EditComputerOperatorComponent_div_3_td_5_Template_button_click_3_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r94); const element_r92 = ctx.$implicit; const ctx_r95 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r95.openDialog("Delete", element_r92); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "i", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function EditComputerOperatorComponent_div_3_th_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " User ID ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function EditComputerOperatorComponent_div_3_td_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r96 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", element_r96.userId, " ");
} }
function EditComputerOperatorComponent_div_3_th_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " USERNAME ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function EditComputerOperatorComponent_div_3_td_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r97 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", element_r97.username, " ");
} }
function EditComputerOperatorComponent_div_3_th_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " FIRST NAME ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function EditComputerOperatorComponent_div_3_td_14_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r98 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", element_r98.firstName, " ");
} }
function EditComputerOperatorComponent_div_3_th_16_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " LAST NAME ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function EditComputerOperatorComponent_div_3_td_17_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r99 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", element_r99.lastName, " ");
} }
function EditComputerOperatorComponent_div_3_tr_18_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "tr", 25);
} }
function EditComputerOperatorComponent_div_3_tr_19_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "tr", 26);
} }
const _c0 = function () { return [5, 10, 20, 50]; };
function EditComputerOperatorComponent_div_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "table", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](3, 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, EditComputerOperatorComponent_div_3_th_4_Template, 2, 0, "th", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, EditComputerOperatorComponent_div_3_td_5_Template, 5, 0, "td", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](6, 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, EditComputerOperatorComponent_div_3_th_7_Template, 2, 0, "th", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, EditComputerOperatorComponent_div_3_td_8_Template, 2, 1, "td", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](9, 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](10, EditComputerOperatorComponent_div_3_th_10_Template, 2, 0, "th", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](11, EditComputerOperatorComponent_div_3_td_11_Template, 2, 1, "td", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](12, 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](13, EditComputerOperatorComponent_div_3_th_13_Template, 2, 0, "th", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](14, EditComputerOperatorComponent_div_3_td_14_Template, 2, 1, "td", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](15, 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](16, EditComputerOperatorComponent_div_3_th_16_Template, 2, 0, "th", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](17, EditComputerOperatorComponent_div_3_td_17_Template, 2, 1, "td", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](18, EditComputerOperatorComponent_div_3_tr_18_Template, 1, 0, "tr", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](19, EditComputerOperatorComponent_div_3_tr_19_Template, 1, 0, "tr", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](20, "mat-paginator", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r79 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("dataSource", ctx_r79.dataSource);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matHeaderRowDef", ctx_r79.displayedColumns)("matHeaderRowDefSticky", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matRowDefColumns", ctx_r79.displayedColumns);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("pageSizeOptions", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](5, _c0));
} }
class EditComputerOperatorComponent {
    constructor(dialog, alertService, userService) {
        this.dialog = dialog;
        this.alertService = alertService;
        this.userService = userService;
        this.displayedColumns = ['actionsColumn', 'userId', 'username', 'firstName', 'lastName'];
    }
    ngOnInit() {
        this.GetUsers();
    }
    refreshData() {
        this.dataSource = new _angular_material_table__WEBPACK_IMPORTED_MODULE_3__["MatTableDataSource"](this.users);
        setTimeout(() => this.dataSource.paginator = this.paginator);
    }
    GetUsers() {
        this.userService.getUsers()
            .subscribe(data => {
            this.users = data.usersFromRepo.map(item => {
                return new src_app_Models__WEBPACK_IMPORTED_MODULE_1__["User"](item.userId, item.username, "", item.firstName, item.lastName, item.photo);
            });
            this.refreshData();
        });
    }
    openDialog(action, obj) {
        this.BO = new _Create_create_computer_operator_create_computer_operator_component__WEBPACK_IMPORTED_MODULE_2__["UserUpdateBO"]();
        this.BO.action = action;
        this.BO.user = new src_app_Models__WEBPACK_IMPORTED_MODULE_1__["User"](obj.userId, obj.username, "", obj.firstName, obj.lastName, obj.photo);
        if (action == "Delete")
            this.dialogWidth = '250px';
        else if (action == "Update")
            this.dialogWidth = '100%';
        const dialogRef = this.dialog.open(_Create_create_computer_operator_create_computer_operator_component__WEBPACK_IMPORTED_MODULE_2__["CreateComputerOperatorComponent"], {
            width: this.dialogWidth,
            data: this.BO
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result.event == 'Update') {
                this.updateRowData(result.data);
            }
            else if (result.event == 'Delete') {
                this.deleteRowData(result.data);
            }
            else if (result.event == 'Cancel') {
                this.alertService.info("Update has been cancelled");
            }
        });
    }
    updateRowData(returnUser) {
        debugger;
        this.userService.updateUser(returnUser)
            .subscribe(data => {
            debugger;
            this.users = data.map(item => {
                return new src_app_Models__WEBPACK_IMPORTED_MODULE_1__["User"](item.userId, item.username, "", item.firstName, item.lastName, item.photo);
            });
            this.refreshData();
            this.alertService.success("User has been update successfully");
        }, (error) => {
            this.alertService.success(error.error);
        });
        // this.users = this.users.map(u => u === BO_obj.oldObject ? BO_obj.newObject : u);
        // this.refreshData();
    }
    deleteRowData(returnUser) {
        this.userService.deleteUser(returnUser)
            .subscribe(data => {
            debugger;
            this.users = data.map(item => {
                return new src_app_Models__WEBPACK_IMPORTED_MODULE_1__["User"](item.userId, item.username, "", item.firstName, item.lastName, item.photo);
            });
            this.refreshData();
            this.alertService.success("User has been deleted successfully");
        }, (error) => {
            this.alertService.success(error.error);
        });
    }
}
EditComputerOperatorComponent.ɵfac = function EditComputerOperatorComponent_Factory(t) { return new (t || EditComputerOperatorComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__["MatDialog"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_6__["AlertService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_common_user_service__WEBPACK_IMPORTED_MODULE_7__["UserService"])); };
EditComputerOperatorComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: EditComputerOperatorComponent, selectors: [["app-edit-computer-operator"]], viewQuery: function EditComputerOperatorComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_angular_material_paginator__WEBPACK_IMPORTED_MODULE_4__["MatPaginator"], true);
    } if (rf & 2) {
        var _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.paginator = _t.first);
    } }, inputs: { users: "users" }, decls: 4, vars: 1, consts: [[1, "text-center"], [1, "d-flex", "justify-content-center"], ["class", "budget-items", 4, "ngIf"], [1, "budget-items"], [1, "mat-elevation-z8"], ["mat-table", "", 3, "dataSource"], ["matColumnDef", "actionsColumn"], ["mat-header-cell", "", "class", "w-10", 4, "matHeaderCellDef"], ["mat-cell", "", 4, "matCellDef"], ["matColumnDef", "userId"], ["mat-header-cell", "", "class", "w-4", 4, "matHeaderCellDef"], ["matColumnDef", "username"], ["matColumnDef", "firstName"], ["mat-header-cell", "", "class", "w-15", 4, "matHeaderCellDef"], ["matColumnDef", "lastName"], ["mat-header-row", "", 4, "matHeaderRowDef", "matHeaderRowDefSticky"], ["mat-row", "", 4, "matRowDef", "matRowDefColumns"], ["showFirstLastButtons", "", 3, "pageSizeOptions"], ["mat-header-cell", "", 1, "w-10"], ["mat-cell", ""], ["mat-icon-button", "", "color", "primary", "focusable", "false", 3, "click"], [1, "fa", "fa-pencil", "mat-icon"], [1, "fa", "fa-trash", "mat-icon"], ["mat-header-cell", "", 1, "w-4"], ["mat-header-cell", "", 1, "w-15"], ["mat-header-row", ""], ["mat-row", ""]], template: function EditComputerOperatorComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "h2", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Edit User");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, EditComputerOperatorComponent_div_3_Template, 21, 6, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.users && ctx.users.length > 0);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_8__["NgIf"], _angular_material_table__WEBPACK_IMPORTED_MODULE_3__["MatTable"], _angular_material_table__WEBPACK_IMPORTED_MODULE_3__["MatColumnDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_3__["MatHeaderCellDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_3__["MatCellDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_3__["MatHeaderRowDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_3__["MatRowDef"], _angular_material_paginator__WEBPACK_IMPORTED_MODULE_4__["MatPaginator"], _angular_material_table__WEBPACK_IMPORTED_MODULE_3__["MatHeaderCell"], _angular_material_table__WEBPACK_IMPORTED_MODULE_3__["MatCell"], _angular_material_button__WEBPACK_IMPORTED_MODULE_9__["MatButton"], _angular_material_table__WEBPACK_IMPORTED_MODULE_3__["MatHeaderRow"], _angular_material_table__WEBPACK_IMPORTED_MODULE_3__["MatRow"]], styles: ["table[_ngcontent-%COMP%] {\n  width: 100%;\n}\n\n.budget-items[_ngcontent-%COMP%] {\n  width: 90%;\n}\n\n.w-0[_ngcontent-%COMP%] {\n  width: 0%;\n}\n\n.w-1[_ngcontent-%COMP%] {\n  width: 1%;\n}\n\n.w-2[_ngcontent-%COMP%] {\n  width: 2%;\n}\n\n.w-3[_ngcontent-%COMP%] {\n  width: 3%;\n}\n\n.w-4[_ngcontent-%COMP%] {\n  width: 4%;\n}\n\n.w-5[_ngcontent-%COMP%] {\n  width: 5%;\n}\n\n.w-6[_ngcontent-%COMP%] {\n  width: 6%;\n}\n\n.w-7[_ngcontent-%COMP%] {\n  width: 7%;\n}\n\n.w-8[_ngcontent-%COMP%] {\n  width: 8%;\n}\n\n.w-9[_ngcontent-%COMP%] {\n  width: 9%;\n}\n\n.w-10[_ngcontent-%COMP%] {\n  width: 10%;\n}\n\n.w-11[_ngcontent-%COMP%] {\n  width: 11%;\n}\n\n.w-12[_ngcontent-%COMP%] {\n  width: 12%;\n}\n\n.w-13[_ngcontent-%COMP%] {\n  width: 13%;\n}\n\n.w-14[_ngcontent-%COMP%] {\n  width: 14%;\n}\n\n.w-15[_ngcontent-%COMP%] {\n  width: 15%;\n}\n\n.w-16[_ngcontent-%COMP%] {\n  width: 16%;\n}\n\n.w-17[_ngcontent-%COMP%] {\n  width: 17%;\n}\n\n.w-18[_ngcontent-%COMP%] {\n  width: 18%;\n}\n\n.w-19[_ngcontent-%COMP%] {\n  width: 19%;\n}\n\n.w-20[_ngcontent-%COMP%] {\n  width: 20%;\n}\n\n.w-21[_ngcontent-%COMP%] {\n  width: 21%;\n}\n\n.w-22[_ngcontent-%COMP%] {\n  width: 22%;\n}\n\n.w-23[_ngcontent-%COMP%] {\n  width: 23%;\n}\n\n.w-24[_ngcontent-%COMP%] {\n  width: 24%;\n}\n\n.w-25[_ngcontent-%COMP%] {\n  width: 25%;\n}\n\n.w-26[_ngcontent-%COMP%] {\n  width: 26%;\n}\n\n.w-27[_ngcontent-%COMP%] {\n  width: 27%;\n}\n\n.w-28[_ngcontent-%COMP%] {\n  width: 28%;\n}\n\n.w-29[_ngcontent-%COMP%] {\n  width: 29%;\n}\n\n.w-30[_ngcontent-%COMP%] {\n  width: 30%;\n}\n\n.w-31[_ngcontent-%COMP%] {\n  width: 31%;\n}\n\n.w-32[_ngcontent-%COMP%] {\n  width: 32%;\n}\n\n.w-33[_ngcontent-%COMP%] {\n  width: 33%;\n}\n\n.w-34[_ngcontent-%COMP%] {\n  width: 34%;\n}\n\n.w-35[_ngcontent-%COMP%] {\n  width: 35%;\n}\n\n.w-36[_ngcontent-%COMP%] {\n  width: 36%;\n}\n\n.w-37[_ngcontent-%COMP%] {\n  width: 37%;\n}\n\n.w-38[_ngcontent-%COMP%] {\n  width: 38%;\n}\n\n.w-39[_ngcontent-%COMP%] {\n  width: 39%;\n}\n\n.w-40[_ngcontent-%COMP%] {\n  width: 40%;\n}\n\n.w-41[_ngcontent-%COMP%] {\n  width: 41%;\n}\n\n.w-42[_ngcontent-%COMP%] {\n  width: 42%;\n}\n\n.w-43[_ngcontent-%COMP%] {\n  width: 43%;\n}\n\n.w-44[_ngcontent-%COMP%] {\n  width: 44%;\n}\n\n.w-45[_ngcontent-%COMP%] {\n  width: 45%;\n}\n\n.w-46[_ngcontent-%COMP%] {\n  width: 46%;\n}\n\n.w-47[_ngcontent-%COMP%] {\n  width: 47%;\n}\n\n.w-48[_ngcontent-%COMP%] {\n  width: 48%;\n}\n\n.w-49[_ngcontent-%COMP%] {\n  width: 49%;\n}\n\n.w-50[_ngcontent-%COMP%] {\n  width: 50%;\n}\n\n.w-51[_ngcontent-%COMP%] {\n  width: 51%;\n}\n\n.w-52[_ngcontent-%COMP%] {\n  width: 52%;\n}\n\n.w-53[_ngcontent-%COMP%] {\n  width: 53%;\n}\n\n.w-54[_ngcontent-%COMP%] {\n  width: 54%;\n}\n\n.w-55[_ngcontent-%COMP%] {\n  width: 55%;\n}\n\n.w-56[_ngcontent-%COMP%] {\n  width: 56%;\n}\n\n.w-57[_ngcontent-%COMP%] {\n  width: 57%;\n}\n\n.w-58[_ngcontent-%COMP%] {\n  width: 58%;\n}\n\n.w-59[_ngcontent-%COMP%] {\n  width: 59%;\n}\n\n.w-60[_ngcontent-%COMP%] {\n  width: 60%;\n}\n\n.w-61[_ngcontent-%COMP%] {\n  width: 61%;\n}\n\n.w-62[_ngcontent-%COMP%] {\n  width: 62%;\n}\n\n.w-63[_ngcontent-%COMP%] {\n  width: 63%;\n}\n\n.w-64[_ngcontent-%COMP%] {\n  width: 64%;\n}\n\n.w-65[_ngcontent-%COMP%] {\n  width: 65%;\n}\n\n.w-66[_ngcontent-%COMP%] {\n  width: 66%;\n}\n\n.w-67[_ngcontent-%COMP%] {\n  width: 67%;\n}\n\n.w-68[_ngcontent-%COMP%] {\n  width: 68%;\n}\n\n.w-69[_ngcontent-%COMP%] {\n  width: 69%;\n}\n\n.w-70[_ngcontent-%COMP%] {\n  width: 70%;\n}\n\n.w-71[_ngcontent-%COMP%] {\n  width: 71%;\n}\n\n.w-72[_ngcontent-%COMP%] {\n  width: 72%;\n}\n\n.w-73[_ngcontent-%COMP%] {\n  width: 73%;\n}\n\n.w-74[_ngcontent-%COMP%] {\n  width: 74%;\n}\n\n.w-75[_ngcontent-%COMP%] {\n  width: 75%;\n}\n\n.w-76[_ngcontent-%COMP%] {\n  width: 76%;\n}\n\n.w-77[_ngcontent-%COMP%] {\n  width: 77%;\n}\n\n.w-78[_ngcontent-%COMP%] {\n  width: 78%;\n}\n\n.w-79[_ngcontent-%COMP%] {\n  width: 79%;\n}\n\n.w-80[_ngcontent-%COMP%] {\n  width: 80%;\n}\n\n.w-81[_ngcontent-%COMP%] {\n  width: 81%;\n}\n\n.w-82[_ngcontent-%COMP%] {\n  width: 82%;\n}\n\n.w-83[_ngcontent-%COMP%] {\n  width: 83%;\n}\n\n.w-84[_ngcontent-%COMP%] {\n  width: 84%;\n}\n\n.w-85[_ngcontent-%COMP%] {\n  width: 85%;\n}\n\n.w-86[_ngcontent-%COMP%] {\n  width: 86%;\n}\n\n.w-87[_ngcontent-%COMP%] {\n  width: 87%;\n}\n\n.w-88[_ngcontent-%COMP%] {\n  width: 88%;\n}\n\n.w-89[_ngcontent-%COMP%] {\n  width: 89%;\n}\n\n.w-90[_ngcontent-%COMP%] {\n  width: 90%;\n}\n\n.w-91[_ngcontent-%COMP%] {\n  width: 91%;\n}\n\n.w-92[_ngcontent-%COMP%] {\n  width: 92%;\n}\n\n.w-93[_ngcontent-%COMP%] {\n  width: 93%;\n}\n\n.w-94[_ngcontent-%COMP%] {\n  width: 94%;\n}\n\n.w-95[_ngcontent-%COMP%] {\n  width: 95%;\n}\n\n.w-96[_ngcontent-%COMP%] {\n  width: 96%;\n}\n\n.w-97[_ngcontent-%COMP%] {\n  width: 97%;\n}\n\n.w-98[_ngcontent-%COMP%] {\n  width: 98%;\n}\n\n.w-99[_ngcontent-%COMP%] {\n  width: 99%;\n}\n\n.w-100[_ngcontent-%COMP%] {\n  width: 100%;\n}\n\n.red[_ngcontent-%COMP%] {\n  color: red;\n}\n\n.green[_ngcontent-%COMP%] {\n  color: green;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUGFnZXMvQWRtaW4vZWRpdC1jb21wdXRlci1vcGVyYXRvci9DOlxcRGV2ZWxvcG1lbnRcXFNhdHRpXFxGaW5hbmNlVHJhY2tlci9zcmNcXGFwcFxcUGFnZXNcXEFkbWluXFxlZGl0LWNvbXB1dGVyLW9wZXJhdG9yXFxlZGl0LWNvbXB1dGVyLW9wZXJhdG9yLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9QYWdlcy9BZG1pbi9lZGl0LWNvbXB1dGVyLW9wZXJhdG9yL2VkaXQtY29tcHV0ZXItb3BlcmF0b3IuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFBO0FDQ0o7O0FERUE7RUFDSSxVQUFBO0FDQ0o7O0FEU0k7RUFDSSxTQUFBO0FDTlI7O0FES0k7RUFDSSxTQUFBO0FDRlI7O0FEQ0k7RUFDSSxTQUFBO0FDRVI7O0FESEk7RUFDSSxTQUFBO0FDTVI7O0FEUEk7RUFDSSxTQUFBO0FDVVI7O0FEWEk7RUFDSSxTQUFBO0FDY1I7O0FEZkk7RUFDSSxTQUFBO0FDa0JSOztBRG5CSTtFQUNJLFNBQUE7QUNzQlI7O0FEdkJJO0VBQ0ksU0FBQTtBQzBCUjs7QUQzQkk7RUFDSSxTQUFBO0FDOEJSOztBRC9CSTtFQUNJLFVBQUE7QUNrQ1I7O0FEbkNJO0VBQ0ksVUFBQTtBQ3NDUjs7QUR2Q0k7RUFDSSxVQUFBO0FDMENSOztBRDNDSTtFQUNJLFVBQUE7QUM4Q1I7O0FEL0NJO0VBQ0ksVUFBQTtBQ2tEUjs7QURuREk7RUFDSSxVQUFBO0FDc0RSOztBRHZESTtFQUNJLFVBQUE7QUMwRFI7O0FEM0RJO0VBQ0ksVUFBQTtBQzhEUjs7QUQvREk7RUFDSSxVQUFBO0FDa0VSOztBRG5FSTtFQUNJLFVBQUE7QUNzRVI7O0FEdkVJO0VBQ0ksVUFBQTtBQzBFUjs7QUQzRUk7RUFDSSxVQUFBO0FDOEVSOztBRC9FSTtFQUNJLFVBQUE7QUNrRlI7O0FEbkZJO0VBQ0ksVUFBQTtBQ3NGUjs7QUR2Rkk7RUFDSSxVQUFBO0FDMEZSOztBRDNGSTtFQUNJLFVBQUE7QUM4RlI7O0FEL0ZJO0VBQ0ksVUFBQTtBQ2tHUjs7QURuR0k7RUFDSSxVQUFBO0FDc0dSOztBRHZHSTtFQUNJLFVBQUE7QUMwR1I7O0FEM0dJO0VBQ0ksVUFBQTtBQzhHUjs7QUQvR0k7RUFDSSxVQUFBO0FDa0hSOztBRG5ISTtFQUNJLFVBQUE7QUNzSFI7O0FEdkhJO0VBQ0ksVUFBQTtBQzBIUjs7QUQzSEk7RUFDSSxVQUFBO0FDOEhSOztBRC9ISTtFQUNJLFVBQUE7QUNrSVI7O0FEbklJO0VBQ0ksVUFBQTtBQ3NJUjs7QUR2SUk7RUFDSSxVQUFBO0FDMElSOztBRDNJSTtFQUNJLFVBQUE7QUM4SVI7O0FEL0lJO0VBQ0ksVUFBQTtBQ2tKUjs7QURuSkk7RUFDSSxVQUFBO0FDc0pSOztBRHZKSTtFQUNJLFVBQUE7QUMwSlI7O0FEM0pJO0VBQ0ksVUFBQTtBQzhKUjs7QUQvSkk7RUFDSSxVQUFBO0FDa0tSOztBRG5LSTtFQUNJLFVBQUE7QUNzS1I7O0FEdktJO0VBQ0ksVUFBQTtBQzBLUjs7QUQzS0k7RUFDSSxVQUFBO0FDOEtSOztBRC9LSTtFQUNJLFVBQUE7QUNrTFI7O0FEbkxJO0VBQ0ksVUFBQTtBQ3NMUjs7QUR2TEk7RUFDSSxVQUFBO0FDMExSOztBRDNMSTtFQUNJLFVBQUE7QUM4TFI7O0FEL0xJO0VBQ0ksVUFBQTtBQ2tNUjs7QURuTUk7RUFDSSxVQUFBO0FDc01SOztBRHZNSTtFQUNJLFVBQUE7QUMwTVI7O0FEM01JO0VBQ0ksVUFBQTtBQzhNUjs7QUQvTUk7RUFDSSxVQUFBO0FDa05SOztBRG5OSTtFQUNJLFVBQUE7QUNzTlI7O0FEdk5JO0VBQ0ksVUFBQTtBQzBOUjs7QUQzTkk7RUFDSSxVQUFBO0FDOE5SOztBRC9OSTtFQUNJLFVBQUE7QUNrT1I7O0FEbk9JO0VBQ0ksVUFBQTtBQ3NPUjs7QUR2T0k7RUFDSSxVQUFBO0FDME9SOztBRDNPSTtFQUNJLFVBQUE7QUM4T1I7O0FEL09JO0VBQ0ksVUFBQTtBQ2tQUjs7QURuUEk7RUFDSSxVQUFBO0FDc1BSOztBRHZQSTtFQUNJLFVBQUE7QUMwUFI7O0FEM1BJO0VBQ0ksVUFBQTtBQzhQUjs7QUQvUEk7RUFDSSxVQUFBO0FDa1FSOztBRG5RSTtFQUNJLFVBQUE7QUNzUVI7O0FEdlFJO0VBQ0ksVUFBQTtBQzBRUjs7QUQzUUk7RUFDSSxVQUFBO0FDOFFSOztBRC9RSTtFQUNJLFVBQUE7QUNrUlI7O0FEblJJO0VBQ0ksVUFBQTtBQ3NSUjs7QUR2Ukk7RUFDSSxVQUFBO0FDMFJSOztBRDNSSTtFQUNJLFVBQUE7QUM4UlI7O0FEL1JJO0VBQ0ksVUFBQTtBQ2tTUjs7QURuU0k7RUFDSSxVQUFBO0FDc1NSOztBRHZTSTtFQUNJLFVBQUE7QUMwU1I7O0FEM1NJO0VBQ0ksVUFBQTtBQzhTUjs7QUQvU0k7RUFDSSxVQUFBO0FDa1RSOztBRG5USTtFQUNJLFVBQUE7QUNzVFI7O0FEdlRJO0VBQ0ksVUFBQTtBQzBUUjs7QUQzVEk7RUFDSSxVQUFBO0FDOFRSOztBRC9USTtFQUNJLFVBQUE7QUNrVVI7O0FEblVJO0VBQ0ksVUFBQTtBQ3NVUjs7QUR2VUk7RUFDSSxVQUFBO0FDMFVSOztBRDNVSTtFQUNJLFVBQUE7QUM4VVI7O0FEL1VJO0VBQ0ksVUFBQTtBQ2tWUjs7QURuVkk7RUFDSSxVQUFBO0FDc1ZSOztBRHZWSTtFQUNJLFVBQUE7QUMwVlI7O0FEM1ZJO0VBQ0ksVUFBQTtBQzhWUjs7QUQvVkk7RUFDSSxVQUFBO0FDa1dSOztBRG5XSTtFQUNJLFVBQUE7QUNzV1I7O0FEdldJO0VBQ0ksVUFBQTtBQzBXUjs7QUQzV0k7RUFDSSxVQUFBO0FDOFdSOztBRC9XSTtFQUNJLFVBQUE7QUNrWFI7O0FEblhJO0VBQ0ksVUFBQTtBQ3NYUjs7QUR2WEk7RUFDSSxVQUFBO0FDMFhSOztBRDNYSTtFQUNJLFVBQUE7QUM4WFI7O0FEL1hJO0VBQ0ksVUFBQTtBQ2tZUjs7QURuWUk7RUFDSSxVQUFBO0FDc1lSOztBRHZZSTtFQUNJLFdBQUE7QUMwWVI7O0FEcFlBO0VBQ0ksVUFBQTtBQ3VZSjs7QURyWUE7RUFDSSxZQUFBO0FDd1lKIiwiZmlsZSI6InNyYy9hcHAvUGFnZXMvQWRtaW4vZWRpdC1jb21wdXRlci1vcGVyYXRvci9lZGl0LWNvbXB1dGVyLW9wZXJhdG9yLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsidGFibGUge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbi5idWRnZXQtaXRlbXMge1xyXG4gICAgd2lkdGg6IDkwJTtcclxufVxyXG5cclxuQG1peGluIGR5bndpZHRocygkbWF4c2l6ZSkge1xyXG4gICAgQGZvciAkaSBmcm9tIDAgdGhyb3VnaCAkbWF4c2l6ZSB7XHJcbiAgICAgICAgQGluY2x1ZGUgd2lkdGgtY2xhc3MoJGkpO1xyXG4gICAgfVxyXG59XHJcblxyXG5AbWl4aW4gd2lkdGgtY2xhc3MoJHNpemUpIHtcclxuICAgIC53LSN7JHNpemV9IHtcclxuICAgICAgICB3aWR0aDogJHNpemUgKiAxJTtcclxuICAgIH1cclxufVxyXG5cclxuQGluY2x1ZGUgZHlud2lkdGhzKDEwMCk7XHJcblxyXG4ucmVkIHtcclxuICAgIGNvbG9yOiByZWQ7XHJcbn1cclxuLmdyZWVuIHtcclxuICAgIGNvbG9yOiBncmVlbjtcclxufVxyXG4iLCJ0YWJsZSB7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4uYnVkZ2V0LWl0ZW1zIHtcbiAgd2lkdGg6IDkwJTtcbn1cblxuLnctMCB7XG4gIHdpZHRoOiAwJTtcbn1cblxuLnctMSB7XG4gIHdpZHRoOiAxJTtcbn1cblxuLnctMiB7XG4gIHdpZHRoOiAyJTtcbn1cblxuLnctMyB7XG4gIHdpZHRoOiAzJTtcbn1cblxuLnctNCB7XG4gIHdpZHRoOiA0JTtcbn1cblxuLnctNSB7XG4gIHdpZHRoOiA1JTtcbn1cblxuLnctNiB7XG4gIHdpZHRoOiA2JTtcbn1cblxuLnctNyB7XG4gIHdpZHRoOiA3JTtcbn1cblxuLnctOCB7XG4gIHdpZHRoOiA4JTtcbn1cblxuLnctOSB7XG4gIHdpZHRoOiA5JTtcbn1cblxuLnctMTAge1xuICB3aWR0aDogMTAlO1xufVxuXG4udy0xMSB7XG4gIHdpZHRoOiAxMSU7XG59XG5cbi53LTEyIHtcbiAgd2lkdGg6IDEyJTtcbn1cblxuLnctMTMge1xuICB3aWR0aDogMTMlO1xufVxuXG4udy0xNCB7XG4gIHdpZHRoOiAxNCU7XG59XG5cbi53LTE1IHtcbiAgd2lkdGg6IDE1JTtcbn1cblxuLnctMTYge1xuICB3aWR0aDogMTYlO1xufVxuXG4udy0xNyB7XG4gIHdpZHRoOiAxNyU7XG59XG5cbi53LTE4IHtcbiAgd2lkdGg6IDE4JTtcbn1cblxuLnctMTkge1xuICB3aWR0aDogMTklO1xufVxuXG4udy0yMCB7XG4gIHdpZHRoOiAyMCU7XG59XG5cbi53LTIxIHtcbiAgd2lkdGg6IDIxJTtcbn1cblxuLnctMjIge1xuICB3aWR0aDogMjIlO1xufVxuXG4udy0yMyB7XG4gIHdpZHRoOiAyMyU7XG59XG5cbi53LTI0IHtcbiAgd2lkdGg6IDI0JTtcbn1cblxuLnctMjUge1xuICB3aWR0aDogMjUlO1xufVxuXG4udy0yNiB7XG4gIHdpZHRoOiAyNiU7XG59XG5cbi53LTI3IHtcbiAgd2lkdGg6IDI3JTtcbn1cblxuLnctMjgge1xuICB3aWR0aDogMjglO1xufVxuXG4udy0yOSB7XG4gIHdpZHRoOiAyOSU7XG59XG5cbi53LTMwIHtcbiAgd2lkdGg6IDMwJTtcbn1cblxuLnctMzEge1xuICB3aWR0aDogMzElO1xufVxuXG4udy0zMiB7XG4gIHdpZHRoOiAzMiU7XG59XG5cbi53LTMzIHtcbiAgd2lkdGg6IDMzJTtcbn1cblxuLnctMzQge1xuICB3aWR0aDogMzQlO1xufVxuXG4udy0zNSB7XG4gIHdpZHRoOiAzNSU7XG59XG5cbi53LTM2IHtcbiAgd2lkdGg6IDM2JTtcbn1cblxuLnctMzcge1xuICB3aWR0aDogMzclO1xufVxuXG4udy0zOCB7XG4gIHdpZHRoOiAzOCU7XG59XG5cbi53LTM5IHtcbiAgd2lkdGg6IDM5JTtcbn1cblxuLnctNDAge1xuICB3aWR0aDogNDAlO1xufVxuXG4udy00MSB7XG4gIHdpZHRoOiA0MSU7XG59XG5cbi53LTQyIHtcbiAgd2lkdGg6IDQyJTtcbn1cblxuLnctNDMge1xuICB3aWR0aDogNDMlO1xufVxuXG4udy00NCB7XG4gIHdpZHRoOiA0NCU7XG59XG5cbi53LTQ1IHtcbiAgd2lkdGg6IDQ1JTtcbn1cblxuLnctNDYge1xuICB3aWR0aDogNDYlO1xufVxuXG4udy00NyB7XG4gIHdpZHRoOiA0NyU7XG59XG5cbi53LTQ4IHtcbiAgd2lkdGg6IDQ4JTtcbn1cblxuLnctNDkge1xuICB3aWR0aDogNDklO1xufVxuXG4udy01MCB7XG4gIHdpZHRoOiA1MCU7XG59XG5cbi53LTUxIHtcbiAgd2lkdGg6IDUxJTtcbn1cblxuLnctNTIge1xuICB3aWR0aDogNTIlO1xufVxuXG4udy01MyB7XG4gIHdpZHRoOiA1MyU7XG59XG5cbi53LTU0IHtcbiAgd2lkdGg6IDU0JTtcbn1cblxuLnctNTUge1xuICB3aWR0aDogNTUlO1xufVxuXG4udy01NiB7XG4gIHdpZHRoOiA1NiU7XG59XG5cbi53LTU3IHtcbiAgd2lkdGg6IDU3JTtcbn1cblxuLnctNTgge1xuICB3aWR0aDogNTglO1xufVxuXG4udy01OSB7XG4gIHdpZHRoOiA1OSU7XG59XG5cbi53LTYwIHtcbiAgd2lkdGg6IDYwJTtcbn1cblxuLnctNjEge1xuICB3aWR0aDogNjElO1xufVxuXG4udy02MiB7XG4gIHdpZHRoOiA2MiU7XG59XG5cbi53LTYzIHtcbiAgd2lkdGg6IDYzJTtcbn1cblxuLnctNjQge1xuICB3aWR0aDogNjQlO1xufVxuXG4udy02NSB7XG4gIHdpZHRoOiA2NSU7XG59XG5cbi53LTY2IHtcbiAgd2lkdGg6IDY2JTtcbn1cblxuLnctNjcge1xuICB3aWR0aDogNjclO1xufVxuXG4udy02OCB7XG4gIHdpZHRoOiA2OCU7XG59XG5cbi53LTY5IHtcbiAgd2lkdGg6IDY5JTtcbn1cblxuLnctNzAge1xuICB3aWR0aDogNzAlO1xufVxuXG4udy03MSB7XG4gIHdpZHRoOiA3MSU7XG59XG5cbi53LTcyIHtcbiAgd2lkdGg6IDcyJTtcbn1cblxuLnctNzMge1xuICB3aWR0aDogNzMlO1xufVxuXG4udy03NCB7XG4gIHdpZHRoOiA3NCU7XG59XG5cbi53LTc1IHtcbiAgd2lkdGg6IDc1JTtcbn1cblxuLnctNzYge1xuICB3aWR0aDogNzYlO1xufVxuXG4udy03NyB7XG4gIHdpZHRoOiA3NyU7XG59XG5cbi53LTc4IHtcbiAgd2lkdGg6IDc4JTtcbn1cblxuLnctNzkge1xuICB3aWR0aDogNzklO1xufVxuXG4udy04MCB7XG4gIHdpZHRoOiA4MCU7XG59XG5cbi53LTgxIHtcbiAgd2lkdGg6IDgxJTtcbn1cblxuLnctODIge1xuICB3aWR0aDogODIlO1xufVxuXG4udy04MyB7XG4gIHdpZHRoOiA4MyU7XG59XG5cbi53LTg0IHtcbiAgd2lkdGg6IDg0JTtcbn1cblxuLnctODUge1xuICB3aWR0aDogODUlO1xufVxuXG4udy04NiB7XG4gIHdpZHRoOiA4NiU7XG59XG5cbi53LTg3IHtcbiAgd2lkdGg6IDg3JTtcbn1cblxuLnctODgge1xuICB3aWR0aDogODglO1xufVxuXG4udy04OSB7XG4gIHdpZHRoOiA4OSU7XG59XG5cbi53LTkwIHtcbiAgd2lkdGg6IDkwJTtcbn1cblxuLnctOTEge1xuICB3aWR0aDogOTElO1xufVxuXG4udy05MiB7XG4gIHdpZHRoOiA5MiU7XG59XG5cbi53LTkzIHtcbiAgd2lkdGg6IDkzJTtcbn1cblxuLnctOTQge1xuICB3aWR0aDogOTQlO1xufVxuXG4udy05NSB7XG4gIHdpZHRoOiA5NSU7XG59XG5cbi53LTk2IHtcbiAgd2lkdGg6IDk2JTtcbn1cblxuLnctOTcge1xuICB3aWR0aDogOTclO1xufVxuXG4udy05OCB7XG4gIHdpZHRoOiA5OCU7XG59XG5cbi53LTk5IHtcbiAgd2lkdGg6IDk5JTtcbn1cblxuLnctMTAwIHtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbi5yZWQge1xuICBjb2xvcjogcmVkO1xufVxuXG4uZ3JlZW4ge1xuICBjb2xvcjogZ3JlZW47XG59Il19 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](EditComputerOperatorComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-edit-computer-operator',
                templateUrl: './edit-computer-operator.component.html',
                styleUrls: ['./edit-computer-operator.component.scss']
            }]
    }], function () { return [{ type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__["MatDialog"] }, { type: src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_6__["AlertService"] }, { type: src_app_Services_common_user_service__WEBPACK_IMPORTED_MODULE_7__["UserService"] }]; }, { users: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], paginator: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
            args: [_angular_material_paginator__WEBPACK_IMPORTED_MODULE_4__["MatPaginator"], { static: false }]
        }] }); })();


/***/ }),

/***/ "./src/app/Pages/Admin/edit-service-type/edit-service-type.component.ts":
/*!******************************************************************************!*\
  !*** ./src/app/Pages/Admin/edit-service-type/edit-service-type.component.ts ***!
  \******************************************************************************/
/*! exports provided: EditServiceTypeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditServiceTypeComponent", function() { return EditServiceTypeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


class EditServiceTypeComponent {
    constructor() {
    }
    ngOnInit() {
    }
}
EditServiceTypeComponent.ɵfac = function EditServiceTypeComponent_Factory(t) { return new (t || EditServiceTypeComponent)(); };
EditServiceTypeComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: EditServiceTypeComponent, selectors: [["app-edit-service-type"]], decls: 2, vars: 0, consts: [[1, "d-flex", "align-items-center", "justify-content-center", "h-100", "w-100", "h2", "text-danger"]], template: function EditServiceTypeComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "SERVICE TYPE EDIT - WORK IN PROGRESS");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL1BhZ2VzL0FkbWluL2VkaXQtc2VydmljZS10eXBlL2VkaXQtc2VydmljZS10eXBlLmNvbXBvbmVudC5zY3NzIn0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](EditServiceTypeComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-edit-service-type',
                templateUrl: './edit-service-type.component.html',
                styleUrls: ['./edit-service-type.component.scss']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/Pages/Admin/edit-transaction-type/edit-transaction-type.component.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/Pages/Admin/edit-transaction-type/edit-transaction-type.component.ts ***!
  \**************************************************************************************/
/*! exports provided: EditTransactionTypeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditTransactionTypeComponent", function() { return EditTransactionTypeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


class EditTransactionTypeComponent {
    constructor() {
    }
    ngOnInit() {
    }
}
EditTransactionTypeComponent.ɵfac = function EditTransactionTypeComponent_Factory(t) { return new (t || EditTransactionTypeComponent)(); };
EditTransactionTypeComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: EditTransactionTypeComponent, selectors: [["app-edit-transaction-type"]], decls: 2, vars: 0, consts: [[1, "d-flex", "align-items-center", "justify-content-center", "h-100", "w-100", "h2", "text-danger"]], template: function EditTransactionTypeComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "TRANSACTION TYPE EDIT - WORK IN PROGRESS");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL1BhZ2VzL0FkbWluL2VkaXQtdHJhbnNhY3Rpb24tdHlwZS9lZGl0LXRyYW5zYWN0aW9uLXR5cGUuY29tcG9uZW50LnNjc3MifQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](EditTransactionTypeComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-edit-transaction-type',
                templateUrl: './edit-transaction-type.component.html',
                styleUrls: ['./edit-transaction-type.component.scss']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/Pages/Admin/index.ts":
/*!**************************************!*\
  !*** ./src/app/Pages/Admin/index.ts ***!
  \**************************************/
/*! exports provided: EditComputerOperatorComponent, EditClientComponent, EditServiceTypeComponent, EditTransactionTypeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _edit_computer_operator_edit_computer_operator_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edit-computer-operator/edit-computer-operator.component */ "./src/app/Pages/Admin/edit-computer-operator/edit-computer-operator.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "EditComputerOperatorComponent", function() { return _edit_computer_operator_edit_computer_operator_component__WEBPACK_IMPORTED_MODULE_0__["EditComputerOperatorComponent"]; });

/* harmony import */ var _edit_client_edit_client_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit-client/edit-client.component */ "./src/app/Pages/Admin/edit-client/edit-client.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "EditClientComponent", function() { return _edit_client_edit_client_component__WEBPACK_IMPORTED_MODULE_1__["EditClientComponent"]; });

/* harmony import */ var _edit_service_type_edit_service_type_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./edit-service-type/edit-service-type.component */ "./src/app/Pages/Admin/edit-service-type/edit-service-type.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "EditServiceTypeComponent", function() { return _edit_service_type_edit_service_type_component__WEBPACK_IMPORTED_MODULE_2__["EditServiceTypeComponent"]; });

/* harmony import */ var _edit_transaction_type_edit_transaction_type_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./edit-transaction-type/edit-transaction-type.component */ "./src/app/Pages/Admin/edit-transaction-type/edit-transaction-type.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "EditTransactionTypeComponent", function() { return _edit_transaction_type_edit_transaction_type_component__WEBPACK_IMPORTED_MODULE_3__["EditTransactionTypeComponent"]; });







/***/ }),

/***/ "./src/app/Pages/Common/PopUps/add-new-client/add-new-client.component.ts":
/*!********************************************************************************!*\
  !*** ./src/app/Pages/Common/PopUps/add-new-client/add-new-client.component.ts ***!
  \********************************************************************************/
/*! exports provided: AddNewClientComponent, ClientUpdateBO */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddNewClientComponent", function() { return AddNewClientComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientUpdateBO", function() { return ClientUpdateBO; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/animations */ "./node_modules/@angular/animations/__ivy_ngcc__/fesm2015/animations.js");
/* harmony import */ var angular2_uuid__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! angular2-uuid */ "./node_modules/angular2-uuid/index.js");
/* harmony import */ var angular2_uuid__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(angular2_uuid__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var src_app_Models__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/Models */ "./src/app/Models/index.ts");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/dialog.js");
/* harmony import */ var src_app_Services_common_client_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/Services/common/client.service */ "./src/app/Services/common/client.service.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/form-field.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/input.js");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/icon */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/icon.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");















const _c0 = ["video"];
const _c1 = ["canvas"];
function AddNewClientComponent_div_0_div_38_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "img", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r123 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", ctx_r123.PhotoDivShow != 1);
} }
function AddNewClientComponent_div_0_div_38_div_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "img", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r124 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", ctx_r124.imgURL, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
} }
function AddNewClientComponent_div_0_div_38_Template(rf, ctx) { if (rf & 1) {
    const _r126 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, AddNewClientComponent_div_0_div_38_div_1_Template, 2, 1, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, AddNewClientComponent_div_0_div_38_div_2_Template, 2, 1, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "button", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AddNewClientComponent_div_0_div_38_Template_button_click_4_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r126); const ctx_r125 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r125.onClick(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "mat-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "file_upload");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, " Upload Photo ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "input", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r119 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r119.imgURL);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r119.imgURL);
} }
function AddNewClientComponent_div_0_div_39_Template(rf, ctx) { if (rf & 1) {
    const _r130 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "img", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "video", 31, 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "canvas", 33, 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AddNewClientComponent_div_0_div_39_Template_div_click_8_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r130); const ctx_r129 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r129.startCamera(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "Start Camera");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AddNewClientComponent_div_0_div_39_Template_div_click_11_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r130); const ctx_r131 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r131.capture(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "Take Photo");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AddNewClientComponent_div_0_div_39_Template_div_click_14_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r130); const ctx_r132 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r132.startCamera(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "Re-take Photo");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r120 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", ctx_r120.PhotoDivShow != 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", ctx_r120.PhotoDivShow != 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", ctx_r120.PhotoDivShow != 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", ctx_r120.PhotoDivShow != 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", ctx_r120.PhotoDivShow != 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", ctx_r120.PhotoDivShow != 3);
} }
function AddNewClientComponent_div_0_span_43_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Save Client");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function AddNewClientComponent_div_0_span_44_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Add Client");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function AddNewClientComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    const _r134 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "form", 2, 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "mat-form-field", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "Enter Customer Name");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "input", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function AddNewClientComponent_div_0_Template_input_ngModelChange_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r134); const ctx_r133 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r133.clientName = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "mat-icon", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "sentiment_very_satisfied");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "mat-form-field", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "Enter Phone Number");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "input", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function AddNewClientComponent_div_0_Template_input_ngModelChange_16_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r134); const ctx_r135 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r135.phone = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "mat-icon", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "add_ic_call");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "mat-form-field", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "Enter Village");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "input", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function AddNewClientComponent_div_0_Template_input_ngModelChange_23_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r134); const ctx_r136 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r136.village = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "mat-icon", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, "group");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "label", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "input", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AddNewClientComponent_div_0_Template_input_click_31_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r134); const ctx_r137 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r137.radioSelect(true); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](32, " From Folder ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "label", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "input", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AddNewClientComponent_div_0_Template_input_click_34_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r134); const ctx_r138 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r138.radioSelect(false); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](35, " From Web Cam ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](38, AddNewClientComponent_div_0_div_38_Template, 9, 2, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](39, AddNewClientComponent_div_0_div_39_Template, 17, 6, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "button", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AddNewClientComponent_div_0_Template_button_click_42_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r134); const ctx_r139 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r139.saveClient(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](43, AddNewClientComponent_div_0_span_43_Template, 2, 0, "span", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](44, AddNewClientComponent_div_0_span_44_Template, 2, 0, "span", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](45, "button", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AddNewClientComponent_div_0_Template_button_click_45_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r134); const ctx_r140 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r140.closeDialog(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](46, "Close");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const _r118 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](2);
    const ctx_r115 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r115.clientName);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r115.phone);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r115.village);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r115.UploadFromFolder);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r115.UploadFromFolder);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", !_r118.valid);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r115.inputClient);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r115.inputClient);
} }
function AddNewClientComponent_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    const _r142 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Sure to delete ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "?");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "button", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AddNewClientComponent_ng_template_1_Template_button_click_9_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r142); const ctx_r141 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r141.confirmDelete(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "Yes");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "button", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AddNewClientComponent_ng_template_1_Template_button_click_12_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r142); const ctx_r143 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r143.closeDialog(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "No Thanks");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r117 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r117.title);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", "warn");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", "primary");
} }
class AddNewClientComponent {
    constructor(clientService, renderer, dialogRef, BO, sanitizer) {
        this.clientService = clientService;
        this.renderer = renderer;
        this.dialogRef = dialogRef;
        this.BO = BO;
        this.sanitizer = sanitizer;
        this.UploadFromFolder = true;
        this.PhotoDivShow = 1;
        this.videoWidth = 0;
        this.videoHeight = 0;
        this.constraints = {
            video: {
                facingMode: "environment",
                width: { ideal: 400 },
                height: { ideal: 400 },
            },
        };
    }
    ngOnInit() {
        this.generateUUID();
        if (this.BO) {
            this.inputClient = this.BO.client;
            this.title = this.inputClient.clientName;
            this.action = this.BO.action;
            this.clientName = this.inputClient.clientName;
            this.village = this.inputClient.village;
            this.phone = this.inputClient.phone;
            var url = `${this.clientService.apiUrl}/Resources/Images/` + this.inputClient.photo;
            this.imgURL = this.sanitizer.sanitize(_angular_core__WEBPACK_IMPORTED_MODULE_0__["SecurityContext"].RESOURCE_URL, this.sanitizer.bypassSecurityTrustResourceUrl(url));
        }
    }
    generateUUID() {
        this.uuidValue = angular2_uuid__WEBPACK_IMPORTED_MODULE_2__["UUID"].UUID();
    }
    onClick() {
        const fileUpload = document.getElementById("fileUpload");
        fileUpload.onchange = () => {
            this.file = {
                data: fileUpload.files[0],
                state: "in",
                inProgress: false,
                progress: 0,
                canRetry: false,
                canCancel: true,
            };
            var mimeType = fileUpload.files[0].type;
            if (mimeType.match(/image\/*/) == null) {
                // this.message = "Only images are supported.";
                return;
            }
            var reader = new FileReader();
            reader.readAsDataURL(fileUpload.files[0]);
            reader.onload = (_event) => {
                this.imgURL = reader.result;
            };
            fileUpload.value = "";
        };
        fileUpload.click();
    }
    saveClient() {
        var _photoBase64String = "";
        var _file = null;
        var _photo;
        this.uuidValue = this.uuidValue + ".png";
        if (this.UploadFromFolder)
            _file = this.file;
        else if (this.photoBase64String)
            _photoBase64String = this.photoBase64String;
        else if (this.inputClient)
            _photo = this.inputClient.photo;
        if (!this.inputClient) {
            const client = new src_app_Models__WEBPACK_IMPORTED_MODULE_3__["Client"](1, this.clientName, this.phone, this.village, this.uuidValue, 0);
            this.clientService
                .createClient(client, _photoBase64String, _file)
                .subscribe((data) => {
                this.dialogRef.close({ event: "Created" });
            }, (error) => {
                console.log(error);
            });
        }
        else {
            if (this.UploadFromFolder)
                _file = this.file;
            else
                _photoBase64String = this.photoBase64String;
            const client = new src_app_Models__WEBPACK_IMPORTED_MODULE_3__["Client"](this.inputClient.id, this.clientName, this.phone, this.village, _file
                ? _file
                : _photoBase64String
                    ? _photoBase64String
                    : this.inputClient.photo, 0);
            this.clientService
                .updateClient(client, _photoBase64String, _file)
                .subscribe((data) => {
                this.dialogRef.close({ event: "Update", data: data });
            }, (error) => {
                console.log(error);
            });
        }
    }
    startCamera() {
        if (!!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia)) {
            navigator.mediaDevices
                .getUserMedia(this.constraints)
                .then(this.attachVideo.bind(this))
                .catch(this.handleError);
        }
        else {
            alert("Sorry, camera not available.");
        }
    }
    attachVideo(stream) {
        this.mediaStream = stream;
        this.renderer.setProperty(this.videoElement.nativeElement, "srcObject", stream);
        this.renderer.listen(this.videoElement.nativeElement, "play", (event) => {
            this.videoHeight = this.videoElement.nativeElement.videoHeight;
            this.videoWidth = this.videoElement.nativeElement.videoWidth;
        });
        this.PhotoDivShow = 2;
    }
    detachVideo() {
        if (this.mediaStream && this.mediaStream.getTracks) {
            this.mediaStream
                .getTracks()
                .forEach((track) => track.stop());
        }
        this.renderer.setProperty(this.videoElement.nativeElement, "srcObject", null);
    }
    capture() {
        this.renderer.setProperty(this.canvas.nativeElement, "width", this.videoWidth);
        this.renderer.setProperty(this.canvas.nativeElement, "height", this.videoHeight);
        this.canvas.nativeElement
            .getContext("2d")
            .drawImage(this.videoElement.nativeElement, 0, 0, 400, 400);
        this.savePhoto();
        this.detachVideo();
        this.PhotoDivShow = 3;
    }
    savePhoto() {
        var canvasEle = document.getElementById("canvas");
        this.photoBase64String = canvasEle.toDataURL("image/png");
    }
    handleError(error) {
        console.log("Error: ", error);
    }
    radioSelect(uploadFromFolder) {
        this.UploadFromFolder = uploadFromFolder;
    }
    confirmDelete() {
        this.dialogRef.close({ event: this.action, data: this.inputClient });
    }
    closeDialog() {
        this.dialogRef.close({ event: "Cancel" });
    }
}
AddNewClientComponent.ɵfac = function AddNewClientComponent_Factory(t) { return new (t || AddNewClientComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_common_client_service__WEBPACK_IMPORTED_MODULE_5__["ClientService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["Renderer2"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_4__["MatDialogRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_4__["MAT_DIALOG_DATA"], 8), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__["DomSanitizer"])); };
AddNewClientComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AddNewClientComponent, selectors: [["app-add-new-client"]], viewQuery: function AddNewClientComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c0, true);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c1, true);
    } if (rf & 2) {
        var _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.videoElement = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.canvas = _t.first);
    } }, decls: 3, vars: 2, consts: [[4, "ngIf", "ngIfElse"], ["deleteTemplate", ""], [1, "md-form", 2, "min-height", "400px"], ["clientForm", "ngForm"], [1, "container"], [1, "row"], [1, "col"], ["appearance", "outline"], ["matInput", "", "required", "", "name", "name", 3, "ngModel", "ngModelChange"], ["matSuffix", ""], ["matInput", "", "required", "", "name", "phone", 3, "ngModel", "ngModelChange"], ["matInput", "", "required", "", "name", "village", 3, "ngModel", "ngModelChange"], [1, "col", "d-flex", "justify-content-center"], [1, "custom-control", "custom-switch"], ["data-toggle", "buttons", 1, "btn-group", "btn-group-toggle"], [1, "btn", "btn-secondary", "active"], ["type", "radio", "name", "options", "id", "optionFromFolder", "autocomplete", "off", "checked", "", 3, "click"], [1, "btn", "btn-secondary"], ["type", "radio", "name", "options", "id", "optionFromWebCam", "autocomplete", "off", 3, "click"], [1, "row", "mt-3"], ["class", "file-field", 4, "ngIf"], [1, "row", "d-flex", "justify-content-center"], ["mat-raised-button", "", "color", "primary", 1, "m-3", 3, "disabled", "click"], [4, "ngIf"], ["mat-raised-button", "", "color", "warn", 3, "click"], [1, "file-field"], ["class", "row d-flex justify-content-center", 4, "ngIf"], ["type", "button", "mat-button", "", "color", "warn", 3, "click"], ["type", "file", "id", "fileUpload", "name", "fileUpload", 2, "display", "none"], ["src", "../../../../../assets/placeholder-avatar.jpg", "alt", "Sample Photo", 1, "rounded-circle", "z-depth-1-half", "avatar-pic", 3, "hidden"], ["alt", "Sample Photo", 1, "rounded-circle", "z-depth-1-half", "avatar-pic", 3, "src"], ["autoplay", "", 1, "vid", "rounded-circle", "z-depth-1-half", "avatar-pic", 3, "hidden"], ["video", ""], ["id", "canvas", 1, "vid", "rounded-circle", "z-depth-1-half", "avatar-pic", 3, "hidden"], ["canvas", ""], [1, "btn", "btn-mdb-color", "btn-rounded", "float-left", 3, "hidden", "click"], [1, "row", "center-align-field", "justify-content-center"], [1, "mr-3"], ["mat-raised-button", "", "cdkFocusInitial", "", 3, "color", "click"], ["mat-stroked-button", "", 3, "color", "click"]], template: function AddNewClientComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, AddNewClientComponent_div_0_Template, 47, 8, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, AddNewClientComponent_ng_template_1_Template, 14, 3, "ng-template", null, 1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    } if (rf & 2) {
        const _r116 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.action != "Delete")("ngIfElse", _r116);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_7__["NgIf"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["NgForm"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__["MatFormField"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__["MatLabel"], _angular_material_input__WEBPACK_IMPORTED_MODULE_10__["MatInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["RequiredValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["NgModel"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_11__["MatIcon"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__["MatSuffix"], _angular_material_button__WEBPACK_IMPORTED_MODULE_12__["MatButton"]], styles: [".avatar-pic[_ngcontent-%COMP%] {\n  width: 150px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUGFnZXMvQ29tbW9uL1BvcFVwcy9hZGQtbmV3LWNsaWVudC9DOlxcRGV2ZWxvcG1lbnRcXFNhdHRpXFxGaW5hbmNlVHJhY2tlci9zcmNcXGFwcFxcUGFnZXNcXENvbW1vblxcUG9wVXBzXFxhZGQtbmV3LWNsaWVudFxcYWRkLW5ldy1jbGllbnQuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL1BhZ2VzL0NvbW1vbi9Qb3BVcHMvYWRkLW5ldy1jbGllbnQvYWRkLW5ldy1jbGllbnQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxZQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9QYWdlcy9Db21tb24vUG9wVXBzL2FkZC1uZXctY2xpZW50L2FkZC1uZXctY2xpZW50LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmF2YXRhci1waWMge1xyXG4gICAgd2lkdGg6IDE1MHB4O1xyXG59XHJcbiIsIi5hdmF0YXItcGljIHtcbiAgd2lkdGg6IDE1MHB4O1xufSJdfQ== */"], data: { animation: [
            Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["trigger"])("fadeInOut", [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["state"])("in", Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ opacity: 100 })),
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])("* => void", [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])(300, Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ opacity: 0 }))]),
            ]),
        ] } });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AddNewClientComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: "app-add-new-client",
                templateUrl: "./add-new-client.component.html",
                styleUrls: ["./add-new-client.component.scss"],
                animations: [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["trigger"])("fadeInOut", [
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["state"])("in", Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ opacity: 100 })),
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])("* => void", [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])(300, Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ opacity: 0 }))]),
                    ]),
                ],
            }]
    }], function () { return [{ type: src_app_Services_common_client_service__WEBPACK_IMPORTED_MODULE_5__["ClientService"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Renderer2"] }, { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_4__["MatDialogRef"] }, { type: ClientUpdateBO, decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
            }, {
                type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
                args: [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_4__["MAT_DIALOG_DATA"]]
            }] }, { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__["DomSanitizer"] }]; }, { videoElement: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
            args: ["video", { static: false }]
        }], canvas: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
            args: ["canvas", { static: false }]
        }] }); })();
class ClientUpdateBO {
    constructor(client = null, action = "") {
        this.client = client;
        this.action = action;
    }
}


/***/ }),

/***/ "./src/app/Pages/Common/PopUps/add-new-service-type/add-new-service-type.component.ts":
/*!********************************************************************************************!*\
  !*** ./src/app/Pages/Common/PopUps/add-new-service-type/add-new-service-type.component.ts ***!
  \********************************************************************************************/
/*! exports provided: AddNewServiceTypeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddNewServiceTypeComponent", function() { return AddNewServiceTypeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_Models__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/Models */ "./src/app/Models/index.ts");
/* harmony import */ var src_app_Services_common_servicetype_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/Services/common/servicetype.service */ "./src/app/Services/common/servicetype.service.ts");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/dialog.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/form-field.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/input.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");









class AddNewServiceTypeComponent {
    constructor(servicetypeService, dialogRef) {
        this.servicetypeService = servicetypeService;
        this.dialogRef = dialogRef;
    }
    ngOnInit() {
        this.serviceType = new src_app_Models__WEBPACK_IMPORTED_MODULE_1__["ServiceType"](0, "", "");
    }
    AddNewServiceType() {
        this.servicetypeService.createServiceType(this.serviceType)
            .subscribe(data => {
            this.dialogRef.close({ event: 'Created' });
        }, error => {
            console.log(error);
        });
    }
    closeDialog() {
        this.dialogRef.close({ event: 'Cancel' });
    }
}
AddNewServiceTypeComponent.ɵfac = function AddNewServiceTypeComponent_Factory(t) { return new (t || AddNewServiceTypeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_common_servicetype_service__WEBPACK_IMPORTED_MODULE_2__["ServicetypeService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialogRef"])); };
AddNewServiceTypeComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AddNewServiceTypeComponent, selectors: [["app-add-new-service-type"]], decls: 14, vars: 3, consts: [["frmAddNewServiceType", "ngForm"], [2, "width", "100%"], ["matInput", "", "required", "", "placeholder", "ShortName", "name", "srvTypeShortName", 3, "ngModel", "ngModelChange"], ["matInput", "", "required", "", "placeholder", "Description", "name", "srvTypeDescription", 3, "ngModel", "ngModelChange"], ["mat-raised-button", "", "color", "primary", 1, "m-3", 3, "disabled", "click"], ["mat-raised-button", "", "color", "warn", 3, "click"]], template: function AddNewServiceTypeComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "form", null, 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "mat-form-field", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "Service Type ShortName");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "input", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function AddNewServiceTypeComponent_Template_input_ngModelChange_5_listener($event) { return ctx.serviceType.sType = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "mat-form-field", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "Service Type Description");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "input", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function AddNewServiceTypeComponent_Template_input_ngModelChange_9_listener($event) { return ctx.serviceType.sTypeDesc = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "button", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AddNewServiceTypeComponent_Template_button_click_10_listener() { return ctx.AddNewServiceType(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "Add Service Type");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AddNewServiceTypeComponent_Template_button_click_12_listener() { return ctx.closeDialog(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "Close");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        const _r230 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.serviceType.sType);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.serviceType.sTypeDesc);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", !_r230.valid);
    } }, directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgForm"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__["MatFormField"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__["MatLabel"], _angular_material_input__WEBPACK_IMPORTED_MODULE_6__["MatInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["RequiredValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgModel"], _angular_material_button__WEBPACK_IMPORTED_MODULE_7__["MatButton"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL1BhZ2VzL0NvbW1vbi9Qb3BVcHMvYWRkLW5ldy1zZXJ2aWNlLXR5cGUvYWRkLW5ldy1zZXJ2aWNlLXR5cGUuY29tcG9uZW50LnNjc3MifQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AddNewServiceTypeComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-add-new-service-type',
                templateUrl: './add-new-service-type.component.html',
                styleUrls: ['./add-new-service-type.component.scss']
            }]
    }], function () { return [{ type: src_app_Services_common_servicetype_service__WEBPACK_IMPORTED_MODULE_2__["ServicetypeService"] }, { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialogRef"] }]; }, null); })();


/***/ }),

/***/ "./src/app/Pages/Common/PopUps/add-new-transaction-type/add-new-transaction-type.component.ts":
/*!****************************************************************************************************!*\
  !*** ./src/app/Pages/Common/PopUps/add-new-transaction-type/add-new-transaction-type.component.ts ***!
  \****************************************************************************************************/
/*! exports provided: AddNewTransactionTypeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddNewTransactionTypeComponent", function() { return AddNewTransactionTypeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_Models_TransactionType_transaction_type_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/Models/TransactionType/transaction-type.model */ "./src/app/Models/TransactionType/transaction-type.model.ts");
/* harmony import */ var src_app_Services_common_transaction_type_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/Services/common/transaction-type.service */ "./src/app/Services/common/transaction-type.service.ts");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/dialog.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/form-field.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/input.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");









class AddNewTransactionTypeComponent {
    constructor(transactiontypeService, dialogRef) {
        this.transactiontypeService = transactiontypeService;
        this.dialogRef = dialogRef;
    }
    ngOnInit() {
        this.transactionType = new src_app_Models_TransactionType_transaction_type_model__WEBPACK_IMPORTED_MODULE_1__["TransactionType"](0, "");
    }
    AddNewTransactionType() {
        this.transactiontypeService.createTransactionType(this.transactionType)
            .subscribe(data => {
            this.dialogRef.close({ event: 'Created' });
        }, error => {
            console.log(error);
        });
    }
    closeDialog() {
        this.dialogRef.close({ event: 'Cancel' });
    }
}
AddNewTransactionTypeComponent.ɵfac = function AddNewTransactionTypeComponent_Factory(t) { return new (t || AddNewTransactionTypeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_common_transaction_type_service__WEBPACK_IMPORTED_MODULE_2__["TransactionTypeService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialogRef"])); };
AddNewTransactionTypeComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AddNewTransactionTypeComponent, selectors: [["app-add-new-transaction-type"]], decls: 10, vars: 2, consts: [["frmAddNewTransactionType", "ngForm"], [2, "width", "100%"], ["matInput", "", "required", "", "placeholder", "TRANSACTION TYPE", "name", "tranType", 3, "ngModel", "ngModelChange"], ["mat-raised-button", "", "color", "primary", 1, "m-3", 3, "disabled", "click"], ["mat-raised-button", "", "color", "warn", 3, "click"]], template: function AddNewTransactionTypeComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "form", null, 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "mat-form-field", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "Transaction Type : ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "input", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function AddNewTransactionTypeComponent_Template_input_ngModelChange_5_listener($event) { return ctx.transactionType.tType = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AddNewTransactionTypeComponent_Template_button_click_6_listener() { return ctx.AddNewTransactionType(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "Add Transaction Type");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "button", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AddNewTransactionTypeComponent_Template_button_click_8_listener() { return ctx.closeDialog(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "Close");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        const _r231 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.transactionType.tType);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", !_r231.valid);
    } }, directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgForm"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__["MatFormField"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__["MatLabel"], _angular_material_input__WEBPACK_IMPORTED_MODULE_6__["MatInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["RequiredValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgModel"], _angular_material_button__WEBPACK_IMPORTED_MODULE_7__["MatButton"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL1BhZ2VzL0NvbW1vbi9Qb3BVcHMvYWRkLW5ldy10cmFuc2FjdGlvbi10eXBlL2FkZC1uZXctdHJhbnNhY3Rpb24tdHlwZS5jb21wb25lbnQuc2NzcyJ9 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AddNewTransactionTypeComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-add-new-transaction-type',
                templateUrl: './add-new-transaction-type.component.html',
                styleUrls: ['./add-new-transaction-type.component.scss']
            }]
    }], function () { return [{ type: src_app_Services_common_transaction_type_service__WEBPACK_IMPORTED_MODULE_2__["TransactionTypeService"] }, { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialogRef"] }]; }, null); })();


/***/ }),

/***/ "./src/app/Pages/Common/PopUps/cash-entry-edit-item/cash-entry-edit-item.component.ts":
/*!********************************************************************************************!*\
  !*** ./src/app/Pages/Common/PopUps/cash-entry-edit-item/cash-entry-edit-item.component.ts ***!
  \********************************************************************************************/
/*! exports provided: CashEntryEditItemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CashEntryEditItemComponent", function() { return CashEntryEditItemComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/dialog.js");
/* harmony import */ var src_app_Models_CashEntry_cash_entry_update_bo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/Models/CashEntry/cash-entry-update-bo */ "./src/app/Models/CashEntry/cash-entry-update-bo.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _Operator_cash_entry_add_item_cash_entry_add_item_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../Operator/cash-entry-add-item/cash-entry-add-item.component */ "./src/app/Pages/Operator/cash-entry-add-item/cash-entry-add-item.component.ts");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");








function CashEntryEditItemComponent_h1_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "h1", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Edit :: Transaction");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function CashEntryEditItemComponent_div_2_Template(rf, ctx) { if (rf & 1) {
    const _r176 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "section", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "app-cash-entry-add-item", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("formSubmit", function CashEntryEditItemComponent_div_2_Template_app_cash_entry_add_item_formSubmit_3_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r176); const ctx_r175 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r175.doAction($event); })("modalCancel", function CashEntryEditItemComponent_div_2_Template_app_cash_entry_add_item_modalCancel_3_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r176); const ctx_r177 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r177.closeDialog(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r172 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("cashEntryItem", ctx_r172.local_data);
} }
function CashEntryEditItemComponent_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    const _r179 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Sure to delete ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "?");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "button", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CashEntryEditItemComponent_ng_template_3_Template_button_click_9_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r179); const ctx_r178 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r178.confirmDelete(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "Yes");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "button", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CashEntryEditItemComponent_ng_template_3_Template_button_click_12_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r179); const ctx_r180 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r180.closeDialog(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "No Thanks");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r174 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r174.local_data.SNo);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", "warn");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", "primary");
} }
class CashEntryEditItemComponent {
    constructor(dialogRef, BO) {
        this.dialogRef = dialogRef;
        this.BO = BO;
    }
    ngOnInit() {
        this.local_data = Object.assign({}, this.BO.oldObject);
        this.action = this.BO.action;
    }
    doAction(return_data) {
        this.BO.newObject = return_data;
        this.dialogRef.close({ event: this.action, data: this.BO });
    }
    confirmDelete() {
        this.dialogRef.close({ event: this.action, data: this.local_data });
    }
    closeDialog() {
        this.dialogRef.close({ event: 'Cancel' });
    }
}
CashEntryEditItemComponent.ɵfac = function CashEntryEditItemComponent_Factory(t) { return new (t || CashEntryEditItemComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"], 8)); };
CashEntryEditItemComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: CashEntryEditItemComponent, selectors: [["app-cash-entry-edit-item"]], decls: 5, vars: 3, consts: [["mat-dialog-title", "", 4, "ngIf"], ["mat-dialog-content", ""], [4, "ngIf", "ngIfElse"], ["deleteTemplate", ""], ["mat-dialog-title", ""], [1, "add-item-section"], [1, "add-item-container"], [2, "padding", "30px", 3, "cashEntryItem", "formSubmit", "modalCancel"], [1, "container"], [1, "row", "center-align-field"], [1, "mr-3"], ["mat-raised-button", "", "cdkFocusInitial", "", 3, "color", "click"], ["mat-stroked-button", "", 3, "color", "click"]], template: function CashEntryEditItemComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, CashEntryEditItemComponent_h1_0_Template, 3, 0, "h1", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, CashEntryEditItemComponent_div_2_Template, 4, 1, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, CashEntryEditItemComponent_ng_template_3_Template, 14, 3, "ng-template", null, 3, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        const _r173 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.action != "Delete");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.action != "Delete")("ngIfElse", _r173);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["NgIf"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogContent"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogTitle"], _Operator_cash_entry_add_item_cash_entry_add_item_component__WEBPACK_IMPORTED_MODULE_4__["CashEntryAddItemComponent"], _angular_material_button__WEBPACK_IMPORTED_MODULE_5__["MatButton"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL1BhZ2VzL0NvbW1vbi9Qb3BVcHMvY2FzaC1lbnRyeS1lZGl0LWl0ZW0vY2FzaC1lbnRyeS1lZGl0LWl0ZW0uY29tcG9uZW50LnNjc3MifQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CashEntryEditItemComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-cash-entry-edit-item',
                templateUrl: './cash-entry-edit-item.component.html',
                styleUrls: ['./cash-entry-edit-item.component.scss']
            }]
    }], function () { return [{ type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"] }, { type: src_app_Models_CashEntry_cash_entry_update_bo__WEBPACK_IMPORTED_MODULE_2__["CashEntryUpdateBO"], decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
            }, {
                type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
                args: [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"]]
            }] }]; }, null); })();


/***/ }),

/***/ "./src/app/Pages/Common/loading-spinner/loading-spinner.component.ts":
/*!***************************************************************************!*\
  !*** ./src/app/Pages/Common/loading-spinner/loading-spinner.component.ts ***!
  \***************************************************************************/
/*! exports provided: LoadingSpinnerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadingSpinnerComponent", function() { return LoadingSpinnerComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/progress-spinner */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/progress-spinner.js");



class LoadingSpinnerComponent {
    constructor() {
        this.diameter = 100;
        this.color = 'primary';
        this.mode = 'indeterminate';
    }
    ngOnInit() {
    }
}
LoadingSpinnerComponent.ɵfac = function LoadingSpinnerComponent_Factory(t) { return new (t || LoadingSpinnerComponent)(); };
LoadingSpinnerComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: LoadingSpinnerComponent, selectors: [["app-loading-spinner"]], inputs: { diameter: "diameter", color: "color", mode: "mode" }, decls: 2, vars: 3, consts: [[1, "d-flex", "align-content-center", "justify-content-center", "open-close-container"], [1, "tp-margin", 3, "diameter", "color", "mode"]], template: function LoadingSpinnerComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "mat-progress-spinner", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("diameter", ctx.diameter)("color", ctx.color)("mode", ctx.mode);
    } }, directives: [_angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_1__["MatProgressSpinner"]], styles: ["[_nghost-%COMP%] {\n  display: block;\n}\n\n.tp-margin[_ngcontent-%COMP%] {\n  margin: 0 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUGFnZXMvQ29tbW9uL2xvYWRpbmctc3Bpbm5lci9DOlxcRGV2ZWxvcG1lbnRcXFNhdHRpXFxGaW5hbmNlVHJhY2tlci9zcmNcXGFwcFxcUGFnZXNcXENvbW1vblxcbG9hZGluZy1zcGlubmVyXFxsb2FkaW5nLXNwaW5uZXIuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL1BhZ2VzL0NvbW1vbi9sb2FkaW5nLXNwaW5uZXIvbG9hZGluZy1zcGlubmVyLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtBQ0NKOztBREVBO0VBQ0ksY0FBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvUGFnZXMvQ29tbW9uL2xvYWRpbmctc3Bpbm5lci9sb2FkaW5nLXNwaW5uZXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxufVxyXG5cclxuLnRwLW1hcmdpbiB7XHJcbiAgICBtYXJnaW46IDAgMTBweDtcclxufVxyXG5cclxuLy8gLm9wZW4tY2xvc2UtY29udGFpbmVyIHtcclxuLy8gICAgIC8vIGJvcmRlcjogMXB4IHNvbGlkICNkZGRkZGQ7XHJcbi8vICAgICAvLyBtYXJnaW4tdG9wOiAxZW07XHJcbi8vICAgICAvLyBwYWRkaW5nOiAyMHB4IDIwcHggMHB4IDIwcHg7XHJcbi8vICAgICAvLyBjb2xvcjogIzAwMDAwMDtcclxuLy8gICAgIC8vIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4vLyAgICAgLy8gZm9udC1zaXplOiAyMHB4O1xyXG4vLyB9XHJcbiIsIjpob3N0IHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG5cbi50cC1tYXJnaW4ge1xuICBtYXJnaW46IDAgMTBweDtcbn0iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](LoadingSpinnerComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-loading-spinner',
                templateUrl: './loading-spinner.component.html',
                styleUrls: ['./loading-spinner.component.scss']
            }]
    }], function () { return []; }, { diameter: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], color: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], mode: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();


/***/ }),

/***/ "./src/app/Pages/Common/login/login.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/Pages/Common/login/login.component.ts ***!
  \*******************************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var src_app_Services_Auth_authentication_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/Services/Auth/authentication.service */ "./src/app/Services/Auth/authentication.service.ts");
/* harmony import */ var src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/Services/Alert/alert.service */ "./src/app/Services/Alert/alert.service.ts");






class LoginComponent {
    constructor(formBuilder, route, router, authenticationService, alertService) {
        this.formBuilder = formBuilder;
        this.route = route;
        this.router = router;
        this.authenticationService = authenticationService;
        this.alertService = alertService;
        // frmLoginForm: FormGroup;
        this.loading = false;
        this.submitted = false;
        this.model = { username: "", password: "" };
        // redirect to home if already logged in
        if (this.isLoggedIn()) {
            this.router.navigate(['/']);
        }
    }
    ngOnInit() {
        this.model.username = "suresh";
        this.model.password = "suresh";
        // this.login();
    }
    // get f() { return this.frmLoginForm.controls; }
    login() {
        this.authenticationService.login(this.model)
            .subscribe(data => {
            this.alertService.success('Login successful', true);
            this.router.navigate(['/CashEntry']);
        }, error => {
            console.log('failed to login' + error);
            this.alertService.error(error.error);
        });
    }
    logout() {
        this.authenticationService.logout();
    }
    isLoggedIn() {
        const token = localStorage.getItem('currentUserToken');
        return !!token;
    }
}
LoginComponent.ɵfac = function LoginComponent_Factory(t) { return new (t || LoginComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_Auth_authentication_service__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_4__["AlertService"])); };
LoginComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: LoginComponent, selectors: [["app-login"]], decls: 39, vars: 3, consts: [[1, "maindiv"], [1, "d-flex", "justify-content-center", "h-100"], [1, "card"], [1, "card-header"], [1, "d-flex", "justify-content-end", "social_icon"], [1, "fa", "fa-facebook-square"], [1, "fa", "fa-google-plus-square"], [1, "fa", "fa-twitter-square"], [1, "card-body"], [3, "ngSubmit"], ["loginForm", "ngForm"], [1, "input-group", "form-group"], [1, "input-group-prepend"], [1, "input-group-text"], [1, "fa", "fa-user"], ["type", "text", "name", "username", "required", "", "placeholder", "Username", "autofocus", "", 1, "form-control", 3, "ngModel", "ngModelChange"], [1, "fa", "fa-key"], ["type", "password", "name", "password", "required", "", "placeholder", "Password", 1, "form-control", 3, "ngModel", "ngModelChange"], [1, "row", "align-items-center", "remember"], ["type", "checkbox"], [1, "form-group"], ["type", "submit", "value", "Login", 1, "btn", "float-right", "login_btn", 3, "disabled"], [1, "card-footer"], [1, "d-flex", "justify-content-center", "links"], ["href", "#"], [1, "d-flex", "justify-content-center"]], template: function LoginComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "Sign In");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "i", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](10, "i", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](12, "i", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "form", 9, 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngSubmit", function LoginComponent_Template_form_ngSubmit_14_listener() { return ctx.login(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "span", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](19, "i", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function LoginComponent_Template_input_ngModelChange_20_listener($event) { return ctx.model.username = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "span", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](24, "i", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "input", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function LoginComponent_Template_input_ngModelChange_25_listener($event) { return ctx.model.password = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](27, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](28, "Remember Me ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](30, "input", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](33, " Don't have an account?");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "a", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](35, "Sign Up");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "a", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](38, "Forgot your password?");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.model.username);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.model.password);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", !_r0.valid);
    } }, directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgForm"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["RequiredValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgModel"]], styles: ["@font-face {\n  font-family: \"Numans\";\n  font-style: normal;\n  font-weight: 400;\n  src: url('numans-v9-latin-regular.eot');\n  src: local(\"Numans\"), local(\"Numans-Regular\"), url('numans-v9-latin-regular.eot?#iefix') format(\"embedded-opentype\"), url('numans-v9-latin-regular.woff2') format(\"woff2\"), url('numans-v9-latin-regular.woff') format(\"woff\"), url('numans-v9-latin-regular.ttf') format(\"truetype\"), url('numans-v9-latin-regular.svg#Numans') format(\"svg\");\n}\n.maindiv[_ngcontent-%COMP%] {\n  height: 700px;\n  font-family: \"Numans\", sans-serif;\n  background: url('Background.jpg') no-repeat center center fixed;\n  background-size: cover;\n}\n.container[_ngcontent-%COMP%] {\n  height: 100%;\n  align-content: center;\n}\n.card[_ngcontent-%COMP%] {\n  height: 370px;\n  margin-top: auto;\n  margin-bottom: auto;\n  width: 400px;\n  background-color: rgba(0, 0, 0, 0.5) !important;\n}\n.social_icon[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-size: 60px;\n  margin-left: 10px;\n  color: #ffc312;\n}\n.social_icon[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]:hover {\n  color: white;\n  cursor: pointer;\n}\n.card-header[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  color: white;\n}\n.social_icon[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 20px;\n  top: -45px;\n}\n.input-group-prepend[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  width: 50px;\n  background-color: #ffc312;\n  color: black;\n  border: 0 !important;\n}\ninput[_ngcontent-%COMP%]:focus {\n  outline: 0 0 0 0 !important;\n  box-shadow: 0 0 0 0 !important;\n}\n.remember[_ngcontent-%COMP%] {\n  color: white;\n}\n.remember[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  width: 20px;\n  height: 20px;\n  margin-left: 15px;\n  margin-right: 5px;\n}\n.login_btn[_ngcontent-%COMP%] {\n  color: black;\n  background-color: #ffc312;\n  width: 100px;\n}\n.login_btn[_ngcontent-%COMP%]:hover {\n  color: black;\n  background-color: white;\n}\n.links[_ngcontent-%COMP%] {\n  color: white;\n}\n.links[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  margin-left: 4px;\n}\n.input-group-text[_ngcontent-%COMP%] {\n  justify-content: center;\n  align-items: center;\n}\n.input-group-text[_ngcontent-%COMP%]   .fa[_ngcontent-%COMP%] {\n  font-size: 1.6rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUGFnZXMvQ29tbW9uL2xvZ2luL0M6XFxEZXZlbG9wbWVudFxcU2F0dGlcXEZpbmFuY2VUcmFja2VyL3NyY1xcYXBwXFxQYWdlc1xcQ29tbW9uXFxsb2dpblxcbG9naW4uY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL1BhZ2VzL0NvbW1vbi9sb2dpbi9sb2dpbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSwyQkFBQTtBQUNBO0VBQ0kscUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsdUNBQUE7RUFDQSw4VUFBQTtBQ0NKO0FEV0E7RUFDSSxhQUFBO0VBQ0EsaUNBQUE7RUFDQSwrREFBQTtFQUlBLHNCQUFBO0FDVEo7QURZQTtFQUNJLFlBQUE7RUFDQSxxQkFBQTtBQ1RKO0FEWUE7RUFDSSxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSwrQ0FBQTtBQ1RKO0FEWUE7RUFDSSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FDVEo7QURZQTtFQUNJLFlBQUE7RUFDQSxlQUFBO0FDVEo7QURZQTtFQUNJLFlBQUE7QUNUSjtBRFlBO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtBQ1RKO0FEWUE7RUFDSSxXQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0VBQ0Esb0JBQUE7QUNUSjtBRFlBO0VBQ0ksMkJBQUE7RUFDQSw4QkFBQTtBQ1RKO0FEWUE7RUFDSSxZQUFBO0FDVEo7QURZQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtBQ1RKO0FEWUE7RUFDSSxZQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0FDVEo7QURZQTtFQUNJLFlBQUE7RUFDQSx1QkFBQTtBQ1RKO0FEWUE7RUFDSSxZQUFBO0FDVEo7QURZQTtFQUNJLGdCQUFBO0FDVEo7QURZQTtFQUNJLHVCQUFBO0VBQ0EsbUJBQUE7QUNUSjtBRFdJO0VBQ0ksaUJBQUE7QUNUUiIsImZpbGUiOiJzcmMvYXBwL1BhZ2VzL0NvbW1vbi9sb2dpbi9sb2dpbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8qIG51bWFucy1yZWd1bGFyIC0gbGF0aW4gKi9cclxuQGZvbnQtZmFjZSB7XHJcbiAgICBmb250LWZhbWlseTogXCJOdW1hbnNcIjtcclxuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICBzcmM6IHVybChcIi4uLy4uLy4uLy4uL2Fzc2V0cy9mb250cy9OdW1hbnMvbnVtYW5zLXY5LWxhdGluLXJlZ3VsYXIuZW90XCIpOyAvLyBJRTkgQ29tcGF0IE1vZGVzXHJcbiAgICBzcmM6IGxvY2FsKFwiTnVtYW5zXCIpLCBsb2NhbChcIk51bWFucy1SZWd1bGFyXCIpLFxyXG4gICAgICAgIHVybChcIi4uLy4uLy4uLy4uL2Fzc2V0cy9mb250cy9OdW1hbnMvbnVtYW5zLXY5LWxhdGluLXJlZ3VsYXIuZW90PyNpZWZpeFwiKSBmb3JtYXQoXCJlbWJlZGRlZC1vcGVudHlwZVwiKSxcclxuICAgICAgICAvLyBJRTYtSUU4XHJcbiAgICAgICAgICAgIHVybChcIi4uLy4uLy4uLy4uL2Fzc2V0cy9mb250cy9OdW1hbnMvbnVtYW5zLXY5LWxhdGluLXJlZ3VsYXIud29mZjJcIikgZm9ybWF0KFwid29mZjJcIiksXHJcbiAgICAgICAgLy8gU3VwZXIgTW9kZXJuIEJyb3dzZXJzXHJcbiAgICAgICAgICAgIHVybChcIi4uLy4uLy4uLy4uL2Fzc2V0cy9mb250cy9OdW1hbnMvbnVtYW5zLXY5LWxhdGluLXJlZ3VsYXIud29mZlwiKSBmb3JtYXQoXCJ3b2ZmXCIpLFxyXG4gICAgICAgIC8vIE1vZGVybiBCcm93c2Vyc1xyXG4gICAgICAgICAgICB1cmwoXCIuLi8uLi8uLi8uLi9hc3NldHMvZm9udHMvTnVtYW5zL251bWFucy12OS1sYXRpbi1yZWd1bGFyLnR0ZlwiKSBmb3JtYXQoXCJ0cnVldHlwZVwiKSxcclxuICAgICAgICAvLyBTYWZhcmksIEFuZHJvaWQsIGlPU1xyXG4gICAgICAgICAgICB1cmwoXCIuLi8uLi8uLi8uLi9hc3NldHMvZm9udHMvTnVtYW5zL251bWFucy12OS1sYXRpbi1yZWd1bGFyLnN2ZyNOdW1hbnNcIikgZm9ybWF0KFwic3ZnXCIpOyAvLyBMZWdhY3kgaU9TXHJcbn1cclxuXHJcbi5tYWluZGl2IHtcclxuICAgIGhlaWdodDogNzAwcHg7XHJcbiAgICBmb250LWZhbWlseTogXCJOdW1hbnNcIiwgc2Fucy1zZXJpZjtcclxuICAgIGJhY2tncm91bmQ6IHVybChcIi4uLy4uLy4uLy4uL2Fzc2V0cy9CYWNrZ3JvdW5kLmpwZ1wiKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlciBmaXhlZDtcclxuICAgIC13ZWJraXQtYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuICAgIC1tb3otYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuICAgIC1vLWJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbiAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG59XHJcblxyXG4uY29udGFpbmVyIHtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIGFsaWduLWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG5cclxuLmNhcmQge1xyXG4gICAgaGVpZ2h0OiAzNzBweDtcclxuICAgIG1hcmdpbi10b3A6IGF1dG87XHJcbiAgICBtYXJnaW4tYm90dG9tOiBhdXRvO1xyXG4gICAgd2lkdGg6IDQwMHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgwLCAwLCAwLCAwLjUpICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5zb2NpYWxfaWNvbiBzcGFuIHtcclxuICAgIGZvbnQtc2l6ZTogNjBweDtcclxuICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xyXG4gICAgY29sb3I6ICNmZmMzMTI7XHJcbn1cclxuXHJcbi5zb2NpYWxfaWNvbiBzcGFuOmhvdmVyIHtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLmNhcmQtaGVhZGVyIGgzIHtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxuLnNvY2lhbF9pY29uIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHJpZ2h0OiAyMHB4O1xyXG4gICAgdG9wOiAtNDVweDtcclxufVxyXG5cclxuLmlucHV0LWdyb3VwLXByZXBlbmQgc3BhbiB7XHJcbiAgICB3aWR0aDogNTBweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmMzMTI7XHJcbiAgICBjb2xvcjogYmxhY2s7XHJcbiAgICBib3JkZXI6IDAgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW5wdXQ6Zm9jdXMge1xyXG4gICAgb3V0bGluZTogMCAwIDAgMCAhaW1wb3J0YW50O1xyXG4gICAgYm94LXNoYWRvdzogMCAwIDAgMCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ucmVtZW1iZXIge1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG4ucmVtZW1iZXIgaW5wdXQge1xyXG4gICAgd2lkdGg6IDIwcHg7XHJcbiAgICBoZWlnaHQ6IDIwcHg7XHJcbiAgICBtYXJnaW4tbGVmdDogMTVweDtcclxuICAgIG1hcmdpbi1yaWdodDogNXB4O1xyXG59XHJcblxyXG4ubG9naW5fYnRuIHtcclxuICAgIGNvbG9yOiBibGFjaztcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmMzMTI7XHJcbiAgICB3aWR0aDogMTAwcHg7XHJcbn1cclxuXHJcbi5sb2dpbl9idG46aG92ZXIge1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbn1cclxuXHJcbi5saW5rcyB7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbn1cclxuXHJcbi5saW5rcyBhIHtcclxuICAgIG1hcmdpbi1sZWZ0OiA0cHg7XHJcbn1cclxuXHJcbi5pbnB1dC1ncm91cC10ZXh0IHtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuXHJcbiAgICAuZmEge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMS42cmVtO1xyXG4gICAgfVxyXG59XHJcbiIsIi8qIG51bWFucy1yZWd1bGFyIC0gbGF0aW4gKi9cbkBmb250LWZhY2Uge1xuICBmb250LWZhbWlseTogXCJOdW1hbnNcIjtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBmb250LXdlaWdodDogNDAwO1xuICBzcmM6IHVybChcIi4uLy4uLy4uLy4uL2Fzc2V0cy9mb250cy9OdW1hbnMvbnVtYW5zLXY5LWxhdGluLXJlZ3VsYXIuZW90XCIpO1xuICBzcmM6IGxvY2FsKFwiTnVtYW5zXCIpLCBsb2NhbChcIk51bWFucy1SZWd1bGFyXCIpLCB1cmwoXCIuLi8uLi8uLi8uLi9hc3NldHMvZm9udHMvTnVtYW5zL251bWFucy12OS1sYXRpbi1yZWd1bGFyLmVvdD8jaWVmaXhcIikgZm9ybWF0KFwiZW1iZWRkZWQtb3BlbnR5cGVcIiksIHVybChcIi4uLy4uLy4uLy4uL2Fzc2V0cy9mb250cy9OdW1hbnMvbnVtYW5zLXY5LWxhdGluLXJlZ3VsYXIud29mZjJcIikgZm9ybWF0KFwid29mZjJcIiksIHVybChcIi4uLy4uLy4uLy4uL2Fzc2V0cy9mb250cy9OdW1hbnMvbnVtYW5zLXY5LWxhdGluLXJlZ3VsYXIud29mZlwiKSBmb3JtYXQoXCJ3b2ZmXCIpLCB1cmwoXCIuLi8uLi8uLi8uLi9hc3NldHMvZm9udHMvTnVtYW5zL251bWFucy12OS1sYXRpbi1yZWd1bGFyLnR0ZlwiKSBmb3JtYXQoXCJ0cnVldHlwZVwiKSwgdXJsKFwiLi4vLi4vLi4vLi4vYXNzZXRzL2ZvbnRzL051bWFucy9udW1hbnMtdjktbGF0aW4tcmVndWxhci5zdmcjTnVtYW5zXCIpIGZvcm1hdChcInN2Z1wiKTtcbn1cbi5tYWluZGl2IHtcbiAgaGVpZ2h0OiA3MDBweDtcbiAgZm9udC1mYW1pbHk6IFwiTnVtYW5zXCIsIHNhbnMtc2VyaWY7XG4gIGJhY2tncm91bmQ6IHVybChcIi4uLy4uLy4uLy4uL2Fzc2V0cy9CYWNrZ3JvdW5kLmpwZ1wiKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlciBmaXhlZDtcbiAgLXdlYmtpdC1iYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICAtbW96LWJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gIC1vLWJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG59XG5cbi5jb250YWluZXIge1xuICBoZWlnaHQ6IDEwMCU7XG4gIGFsaWduLWNvbnRlbnQ6IGNlbnRlcjtcbn1cblxuLmNhcmQge1xuICBoZWlnaHQ6IDM3MHB4O1xuICBtYXJnaW4tdG9wOiBhdXRvO1xuICBtYXJnaW4tYm90dG9tOiBhdXRvO1xuICB3aWR0aDogNDAwcHg7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMCwgMCwgMCwgMC41KSAhaW1wb3J0YW50O1xufVxuXG4uc29jaWFsX2ljb24gc3BhbiB7XG4gIGZvbnQtc2l6ZTogNjBweDtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIGNvbG9yOiAjZmZjMzEyO1xufVxuXG4uc29jaWFsX2ljb24gc3Bhbjpob3ZlciB7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG4uY2FyZC1oZWFkZXIgaDMge1xuICBjb2xvcjogd2hpdGU7XG59XG5cbi5zb2NpYWxfaWNvbiB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDIwcHg7XG4gIHRvcDogLTQ1cHg7XG59XG5cbi5pbnB1dC1ncm91cC1wcmVwZW5kIHNwYW4ge1xuICB3aWR0aDogNTBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmYzMxMjtcbiAgY29sb3I6IGJsYWNrO1xuICBib3JkZXI6IDAgIWltcG9ydGFudDtcbn1cblxuaW5wdXQ6Zm9jdXMge1xuICBvdXRsaW5lOiAwIDAgMCAwICFpbXBvcnRhbnQ7XG4gIGJveC1zaGFkb3c6IDAgMCAwIDAgIWltcG9ydGFudDtcbn1cblxuLnJlbWVtYmVyIHtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG4ucmVtZW1iZXIgaW5wdXQge1xuICB3aWR0aDogMjBweDtcbiAgaGVpZ2h0OiAyMHB4O1xuICBtYXJnaW4tbGVmdDogMTVweDtcbiAgbWFyZ2luLXJpZ2h0OiA1cHg7XG59XG5cbi5sb2dpbl9idG4ge1xuICBjb2xvcjogYmxhY2s7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmMzMTI7XG4gIHdpZHRoOiAxMDBweDtcbn1cblxuLmxvZ2luX2J0bjpob3ZlciB7XG4gIGNvbG9yOiBibGFjaztcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG59XG5cbi5saW5rcyB7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cblxuLmxpbmtzIGEge1xuICBtYXJnaW4tbGVmdDogNHB4O1xufVxuXG4uaW5wdXQtZ3JvdXAtdGV4dCB7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLmlucHV0LWdyb3VwLXRleHQgLmZhIHtcbiAgZm9udC1zaXplOiAxLjZyZW07XG59Il19 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](LoginComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-login',
                templateUrl: './login.component.html',
                styleUrls: ['./login.component.scss']
            }]
    }], function () { return [{ type: _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"] }, { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] }, { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }, { type: src_app_Services_Auth_authentication_service__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"] }, { type: src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_4__["AlertService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/Pages/Operator/cash-entry-add-item/cash-entry-add-item.component.ts":
/*!*************************************************************************************!*\
  !*** ./src/app/Pages/Operator/cash-entry-add-item/cash-entry-add-item.component.ts ***!
  \*************************************************************************************/
/*! exports provided: CashEntryAddItemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CashEntryAddItemComponent", function() { return CashEntryAddItemComponent; });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var src_app_app_route_animation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/app-route-animation */ "./src/app/app-route-animation.ts");
/* harmony import */ var src_app_Models__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/Models */ "./src/app/Models/index.ts");
/* harmony import */ var _Common_PopUps_add_new_client_add_new_client_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../Common/PopUps/add-new-client/add-new-client.component */ "./src/app/Pages/Common/PopUps/add-new-client/add-new-client.component.ts");
/* harmony import */ var _Common_PopUps_add_new_service_type_add_new_service_type_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../Common/PopUps/add-new-service-type/add-new-service-type.component */ "./src/app/Pages/Common/PopUps/add-new-service-type/add-new-service-type.component.ts");
/* harmony import */ var src_app_Models_TransactionType_transaction_type_model__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/Models/TransactionType/transaction-type.model */ "./src/app/Models/TransactionType/transaction-type.model.ts");
/* harmony import */ var _Common_PopUps_add_new_transaction_type_add_new_transaction_type_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../Common/PopUps/add-new-transaction-type/add-new-transaction-type.component */ "./src/app/Pages/Common/PopUps/add-new-transaction-type/add-new-transaction-type.component.ts");
/* harmony import */ var src_app_Services_common_client_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/Services/common/client.service */ "./src/app/Services/common/client.service.ts");
/* harmony import */ var src_app_Services_Auth_authentication_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/Services/Auth/authentication.service */ "./src/app/Services/Auth/authentication.service.ts");
/* harmony import */ var src_app_Services_common_user_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/Services/common/user.service */ "./src/app/Services/common/user.service.ts");
/* harmony import */ var src_app_Services_common_servicetype_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/Services/common/servicetype.service */ "./src/app/Services/common/servicetype.service.ts");
/* harmony import */ var src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/Services/Alert/alert.service */ "./src/app/Services/Alert/alert.service.ts");
/* harmony import */ var src_app_Services_common_transaction_type_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/Services/common/transaction-type.service */ "./src/app/Services/common/transaction-type.service.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/dialog.js");
/* harmony import */ var _Common_loading_spinner_loading_spinner_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../Common/loading-spinner/loading-spinner.component */ "./src/app/Pages/Common/loading-spinner/loading-spinner.component.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/form-field.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/input.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");
/* harmony import */ var _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/material/autocomplete */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/autocomplete.js");
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/material/core */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _helpers_currency_formatter_pipe__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ../../../_helpers/currency-formatter.pipe */ "./src/app/_helpers/currency-formatter.pipe.ts");





























const _c0 = ["instance"];
const _c1 = ["itemForm"];
function CashEntryAddItemComponent_div_6_mat_option_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-option", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "img", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const user_r242 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", user_r242.firstName + " " + user_r242.lastName);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("src", user_r242.photo, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](user_r242.firstName + " " + user_r242.lastName);
} }
function CashEntryAddItemComponent_div_6_Template(rf, ctx) { if (rf & 1) {
    const _r244 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-form-field");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "input", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("focusout", function CashEntryAddItemComponent_div_6_Template_input_focusout_2_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r244); const ctx_r243 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r243.focusOutValidationFunction(ctx_r243.myCompOperator, ctx_r243.users); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "mat-autocomplete", 21, 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("optionSelected", function CashEntryAddItemComponent_div_6_Template_mat_autocomplete_optionSelected_3_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r244); const ctx_r245 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r245.onSelectCompOperator($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](5, CashEntryAddItemComponent_div_6_mat_option_5_Template, 4, 3, "mat-option", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](6, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const _r240 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](4);
    const ctx_r233 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("matAutocomplete", _r240)("formControl", ctx_r233.myCompOperator);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("displayWith", ctx_r233.displayFnCompOperator);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](6, 4, ctx_r233.filteredCompOperator));
} }
function CashEntryAddItemComponent_div_10_mat_option_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-option", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const tranType_r248 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", tranType_r248.tType);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](tranType_r248.tType);
} }
function CashEntryAddItemComponent_div_10_Template(rf, ctx) { if (rf & 1) {
    const _r250 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-form-field", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "input", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("focusout", function CashEntryAddItemComponent_div_10_Template_input_focusout_2_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r250); const ctx_r249 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r249.focusOutValidationFunction(ctx_r249.myTransactionType, ctx_r249.transactionTypes); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "mat-autocomplete", 27, 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("optionSelected", function CashEntryAddItemComponent_div_10_Template_mat_autocomplete_optionSelected_3_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r250); const ctx_r251 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r251.onSelectTransactionType($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](5, CashEntryAddItemComponent_div_10_mat_option_5_Template, 3, 2, "mat-option", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](6, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "mat-option", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CashEntryAddItemComponent_div_10_Template_mat_option_click_7_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r250); const ctx_r252 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r252.addNewTransactionType(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "span", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "add_circle_outline");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](11, "Add a new Transaction Type");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const _r246 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](4);
    const ctx_r234 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("matAutocomplete", _r246)("formControl", ctx_r234.myTransactionType);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("displayWith", ctx_r234.displayFnTransactionType)("panelWidth", 400);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](6, 6, ctx_r234.filteredTransactionType));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", "AddNew");
} }
function CashEntryAddItemComponent_div_19_mat_option_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-option", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const srvType_r255 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", srvType_r255.sType);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](srvType_r255.sType + " - " + srvType_r255.sTypeDesc);
} }
function CashEntryAddItemComponent_div_19_Template(rf, ctx) { if (rf & 1) {
    const _r257 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-form-field", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "input", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("focusout", function CashEntryAddItemComponent_div_19_Template_input_focusout_2_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r257); const ctx_r256 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r256.focusOutValidationFunction(ctx_r256.myServiceType, ctx_r256.serviceTypes); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "mat-autocomplete", 27, 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("optionSelected", function CashEntryAddItemComponent_div_19_Template_mat_autocomplete_optionSelected_3_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r257); const ctx_r258 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r258.onSelectServiceType($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](5, CashEntryAddItemComponent_div_19_mat_option_5_Template, 3, 2, "mat-option", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](6, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "mat-option", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CashEntryAddItemComponent_div_19_Template_mat_option_click_7_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r257); const ctx_r259 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r259.addNewServiceType(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "span", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "add_circle_outline");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](11, "Add a new Service");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const _r253 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](4);
    const ctx_r235 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("matAutocomplete", _r253)("formControl", ctx_r235.myServiceType);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("displayWith", ctx_r235.displayFnServiveType)("panelWidth", 400);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](6, 6, ctx_r235.filteredServiceType));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", "AddNew");
} }
const _c2 = function (a0, a1) { return { red: a0, green: a1 }; };
function CashEntryAddItemComponent_div_41_mat_option_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-option", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "div", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "img", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "span", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "span", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "small", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13, " | ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](14, "small", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](16, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "span", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](18);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](19, "currency");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const client_r262 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", client_r262.clientName);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("src", client_r262.photo, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](client_r262.clientName);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](client_r262.village);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](client_r262.phone);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction2"](10, _c2, client_r262.balance > 0, client_r262.balance <= 0));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("Balance - ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](19, 7, client_r262.balance, "INR"), "");
} }
function CashEntryAddItemComponent_div_41_Template(rf, ctx) { if (rf & 1) {
    const _r264 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-form-field");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "input", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("focusout", function CashEntryAddItemComponent_div_41_Template_input_focusout_2_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r264); const ctx_r263 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r263.focusOutValidationFunction(ctx_r263.myControl, ctx_r263.clients); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "mat-autocomplete", 27, 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("optionSelected", function CashEntryAddItemComponent_div_41_Template_mat_autocomplete_optionSelected_3_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r264); const ctx_r265 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r265.onSelectClient($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](5, CashEntryAddItemComponent_div_41_mat_option_5_Template, 20, 13, "mat-option", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](6, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "mat-option", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CashEntryAddItemComponent_div_41_Template_mat_option_click_7_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r264); const ctx_r266 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r266.addNewClient(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "span", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "add_circle_outline");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](11, "Add a new Client");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const _r260 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](4);
    const ctx_r236 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("matAutocomplete", _r260)("formControl", ctx_r236.myControl);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("displayWith", ctx_r236.displayFn)("panelWidth", 400);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](6, 6, ctx_r236.filteredOptions));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", "AddNew");
} }
function CashEntryAddItemComponent_span_51_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1, "Add");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
function CashEntryAddItemComponent_span_52_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1, "Save");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
function CashEntryAddItemComponent_div_53_Template(rf, ctx) { if (rf & 1) {
    const _r268 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "button", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CashEntryAddItemComponent_div_53_Template_button_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r268); const ctx_r267 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r267.closeDialog(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, " Cancel ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("color", "primary");
} }
class CashEntryAddItemComponent {
    //Type Ahead code ends here
    constructor(clientService, authenticationService, userService, servicetypeService, alertService, transactionTypeService, sanitizer, dialog, el) {
        this.clientService = clientService;
        this.authenticationService = authenticationService;
        this.userService = userService;
        this.servicetypeService = servicetypeService;
        this.alertService = alertService;
        this.transactionTypeService = transactionTypeService;
        this.sanitizer = sanitizer;
        this.dialog = dialog;
        this.el = el;
        this.state = 'start';
        this.myControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]();
        this.formSubmit = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.modalCancel = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.dropdownText = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        this.isPageLoaded = false;
        this.noOfDataPointsLoaded = 0;
        //TypeAhead code
        this.focus$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        this.click$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        this.searchClient = (textClient$) => {
            const debouncedTextClient$ = textClient$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["debounceTime"])(200), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["distinctUntilChanged"])());
            const clicksWithClosedPopupClient$ = this.click$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["filter"])(() => !this.instance.isPopupOpen()));
            const inputFocusClient$ = this.focus$;
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["merge"])(debouncedTextClient$, inputFocusClient$, clicksWithClosedPopupClient$).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(term => term === '' ? this.clients.map(item => item.clientName) : (this.clients.filter(v => v.clientName.toLowerCase().indexOf(term.toLowerCase()) > -1).map(item => item.clientName))
                .slice(0, 10)));
        };
        this.searchOperator = (text$) => {
            const debouncedText$ = text$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["debounceTime"])(200), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["distinctUntilChanged"])());
            const clicksWithClosedPopup$ = this.click$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["filter"])(() => !this.instance.isPopupOpen()));
            const inputFocus$ = this.focus$;
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["merge"])(debouncedText$, inputFocus$, clicksWithClosedPopup$).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(term => term === '' ? this.users.map(item => item.username) : (this.users.filter(v => v.username.toLowerCase().indexOf(term.toLowerCase()) > -1).map(item => item.username))
                .slice(0, 10)));
        };
        this.currentUser = localStorage.getItem('currentUserToken');
        this.myCompOperator = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]();
        this.myServiceType = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]();
        this.myTransactionType = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]();
        this.errorMessages = [];
    }
    ngOnInit() {
        this.initializeForm();
        this.GetClients();
        this.GetUsers();
        this.GetServiceTypes();
        this.GetTransactionTypes();
    }
    ngOnChanges() {
        this.GetClients();
        this.GetUsers();
        this.GetServiceTypes();
        this.GetTransactionTypes();
    }
    initializeForm() {
        if (this.cashEntryItem) {
            this.isNewItem = false;
        }
        else {
            this.isNewItem = true;
            this.cashEntryItem = new src_app_Models__WEBPACK_IMPORTED_MODULE_6__["CashEntryItem"]();
            this.cashEntryItem.compOperaratorId = this.authenticationService.currentUserObject.userId;
        }
    }
    _filterCompOperator(value) {
        const filterValue = value.toLowerCase();
        return this.users.filter(user => (user.firstName + " " + user.lastName).toLowerCase().includes(filterValue));
    }
    focusOutValidationFunction(ctrl, dataArray) {
        if (ctrl.value == '' && dataArray === this.transactionTypes) {
            this.transactionType = '';
        }
        // if (ctrl.value && ctrl.value != "")
        //   if (dataArray === this.users) {
        //     if (dataArray.filter(user => (user.firstName + " " + user.lastName).toLowerCase() === ctrl.value.toLowerCase()).length == 0)
        //       ctrl.setValue("");
        //   }
        //   else if (dataArray == this.serviceTypes) {
        //     if (dataArray.filter(serviceType => serviceType.sType.toLowerCase() === ctrl.value.toLowerCase()).length == 0)
        //       ctrl.setValue("");
        //   }
        //   else if (dataArray == this.clients) {
        //     if (dataArray.filter(client => client.clientName.toLowerCase() === ctrl.value.toLowerCase()).length == 0)
        //       ctrl.setValue("");
        //   }
        //   else if (dataArray == this.transactionTypes) {
        //     if (dataArray.filter(transactionType => transactionType.tType.toLowerCase() === ctrl.value.toLowerCase()).length == 0)
        //       ctrl.setValue("");
        //   }
    }
    validateAutoComplete(ctrl, dataArray) {
        if (ctrl.value && ctrl.value != "") {
            if (dataArray === this.users) {
                if (dataArray.filter(user => (user.firstName + " " + user.lastName).toLowerCase() === ctrl.value.toLowerCase()).length == 0)
                    return false;
                else
                    return true;
                // ctrl.setValue("");
            }
            else if (dataArray == this.serviceTypes) {
                if (dataArray.filter(serviceType => serviceType.sType.toLowerCase() === ctrl.value.toLowerCase()).length == 0)
                    return false;
                else
                    return true;
                // ctrl.setValue("");
            }
            else if (dataArray == this.clients) {
                if (dataArray.filter(client => client.clientName.toLowerCase() === ctrl.value.toLowerCase()).length == 0)
                    return false;
                else
                    return true;
                // ctrl.setValue("");
            }
            else if (dataArray == this.transactionTypes) {
                if (dataArray.filter(transactionType => transactionType.tType.toLowerCase() === ctrl.value.toLowerCase()).length == 0)
                    return false;
                else
                    return true;
                //ctrl.setValue("");
            }
        }
        else
            return true;
    }
    displayFnCompOperator(user) {
        return user ? user : undefined;
    }
    GetUsers() {
        this.userService.getUsers()
            .subscribe(data => {
            this.users = data.usersFromRepo.map(item => {
                return new src_app_Models__WEBPACK_IMPORTED_MODULE_6__["User"](item.userId, item.username, "", item.firstName, item.lastName, this.sanitizer.bypassSecurityTrustUrl(`${this.clientService.apiUrl}/Resources/Images/` + item.photo));
            });
            this.filteredCompOperator = this.myCompOperator.valueChanges.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["startWith"])(''), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(user => user ? this._filterCompOperator(user) : this.users.slice()));
            if (this.cashEntryItem.compOperaratorId) {
                var currentUser = this.users.find(s => s.userId == this.cashEntryItem.compOperaratorId);
                this.myCompOperator.setValue(currentUser.firstName + " " + currentUser.lastName);
            }
            this.UploadPageLoadStatus();
        });
    }
    _filterServiceType(value) {
        const filterValue = value.toLowerCase();
        return this.serviceTypes.filter(serviceType => (serviceType.sType + " - " + serviceType.sTypeDesc).toLowerCase().includes(filterValue));
    }
    displayFnServiveType(serviceType) {
        return serviceType ? serviceType : undefined;
    }
    GetServiceTypes(fetchFromServer = false) {
        this.servicetypeService.getServiceTypes(fetchFromServer)
            .subscribe(data => {
            this.serviceTypes = data.serviceTypesFromRepo.map(item => {
                return new src_app_Models__WEBPACK_IMPORTED_MODULE_6__["ServiceType"](item.sid, item.sType, item.sTypeDesc);
            });
            this.filteredServiceType = this.myServiceType.valueChanges.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["startWith"])(''), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(serviceType => serviceType ? this._filterServiceType(serviceType) : this.serviceTypes.slice()));
            if (this.cashEntryItem.serviceTypeId) {
                var currentServiceTypeId = this.serviceTypes.find(s => s.sid == this.cashEntryItem.serviceTypeId);
                this.myServiceType.setValue(currentServiceTypeId.sType);
            }
            this.UploadPageLoadStatus();
        });
    }
    _filterTransactionType(value) {
        const filterValue = value.toLowerCase();
        return this.transactionTypes.filter(transactionType => transactionType.tType.toLowerCase().includes(filterValue));
    }
    displayFnTransactionType(transactionType) {
        return transactionType ? transactionType : undefined;
    }
    GetTransactionTypes(fetchFromServer = false) {
        //transactionTypes
        this.transactionTypeService.getTransactionTypes(fetchFromServer)
            .subscribe(data => {
            this.transactionTypes = data.transactionTypesFromRepo.map(item => {
                return new src_app_Models_TransactionType_transaction_type_model__WEBPACK_IMPORTED_MODULE_9__["TransactionType"](item.tTypeId, item.tType);
            });
            this.filteredTransactionType = this.myTransactionType.valueChanges.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["startWith"])(''), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(transactionType => transactionType ? this._filterTransactionType(transactionType) : this.transactionTypes.slice()));
            if (this.cashEntryItem.description) {
                var desc = this.cashEntryItem.description;
                if (desc.indexOf(" - ") > -1) {
                    this.transactionType = desc.substring(0, desc.indexOf(" - "));
                    this.transactionNumber = desc.substring(desc.indexOf(" - ") + 3);
                }
                else {
                    this.transactionType = desc;
                }
                var currentTransactionTypeId = this.transactionTypes.find(t => t.tType == this.transactionType);
                this.myTransactionType.setValue(currentTransactionTypeId.tType);
            }
            this.UploadPageLoadStatus();
        });
    }
    onSubmit(form) {
        debugger;
        this.errorMessages = [];
        if (!this.validateAutoComplete(this.myControl, this.clients))
            this.errorMessages.push("INVALID CUSTOMER NAME");
        if (!this.validateAutoComplete(this.myCompOperator, this.users))
            this.errorMessages.push("INVALID COMPUTER OPERATOR NAME");
        if (!this.validateAutoComplete(this.myServiceType, this.serviceTypes))
            this.errorMessages.push("INVALID SERVICE TYPE");
        if (!this.validateAutoComplete(this.myTransactionType, this.transactionTypes))
            this.errorMessages.push("INVALID TRANSACTION TYPE");
        if (!this.transactionType) {
            this.errorMessages.push("TRANSACTION TYPE");
        }
        if (!this.cashEntryItem.serviceTypeId) {
            this.errorMessages.push("SERVICE TYPE");
        }
        if (!this.cashEntryItem.clientId) {
            this.errorMessages.push("CUSTOMER");
        }
        if (!this.cashEntryItem.amount)
            this.cashEntryItem.amount = 0;
        if (!this.cashEntryItem.debitAmount)
            this.cashEntryItem.debitAmount = 0;
        if (this.cashEntryItem.amount == 0 && this.cashEntryItem.debitAmount == 0) {
            this.errorMessages.push("CREDIT or DEBIT");
        }
        else {
            this.cashEntryItem.paidAmount = this.cashEntryItem.amount - this.cashEntryItem.debitAmount;
        }
        if (this.errorMessages.length > 0) {
            this.validationError();
            return;
        }
        if (!this.transactionNumber)
            this.transactionNumber = "";
        if (this.transactionNumber == "")
            this.cashEntryItem.description = this.transactionType;
        else
            this.cashEntryItem.description = this.transactionType + " - " + this.transactionNumber;
        this.formSubmit.emit(JSON.parse(JSON.stringify(this.cashEntryItem)));
        this.myControl.setValue("");
        this.myServiceType.setValue("");
        this.myTransactionType.setValue("");
        this.resetFormControl(this.myControl);
        this.resetFormControl(this.myServiceType);
        this.resetFormControl(this.myTransactionType);
        form.resetForm();
        this.resetFormControl(this.itemForm.form);
    }
    validationError() {
        this.alertService.info("Required fields are missing: " + "<br>"
            + "<ul><li><b style='color: red; font-style: italic;'>" + this.errorMessages.join("</b></li><li><b style='color: red; font-style: italic;'>").toString() + "</b></li></ul>", false, 5000);
    }
    closeDialog() {
        this.modalCancel.emit();
    }
    resetFormControl(ctr) {
        ctr.markAsPristine();
        ctr.markAsUntouched();
        ctr.updateValueAndValidity();
    }
    onSelectClient(event) {
        this.cashEntryItem.clientId = this.clients.find(u => u.clientName == event.option.value).id;
    }
    onSelectCompOperator(event) {
        if (event.option.value != 'AddNew')
            this.cashEntryItem.compOperaratorId = this.users.find(c => c.firstName + ' ' + c.lastName == event.option.value).userId;
    }
    onSelectServiceType(event) {
        if (event.option.value != 'AddNew')
            this.cashEntryItem.serviceTypeId = this.serviceTypes.find(s => s.sType == event.option.value).sid;
    }
    onSelectTransactionType(event) {
        if (event.option.value != 'AddNew') {
            if (event.option.value == '')
                this.transactionType = '';
            else
                this.transactionType = this.transactionTypes.find(t => t.tType == event.option.value).tType;
            this.calculatePaidAmount();
        }
        console.log(this.transactionType);
    }
    displayFn(client) {
        return client ? client : undefined;
    }
    _filter(value) {
        const filterValue = value.toLowerCase();
        return this.clients.filter(client => client.clientName.toLowerCase().includes(filterValue));
    }
    GetClients(fetchFromServer = false) {
        this.clientService.getClients(fetchFromServer)
            .subscribe(data => {
            this.clients = data.clientsFromRepo.map(item => {
                return new src_app_Models__WEBPACK_IMPORTED_MODULE_6__["Client"](item.id, item.clientName, item.phone, item.village, this.sanitizer.bypassSecurityTrustUrl(`${this.clientService.apiUrl}/Resources/Images/` + item.photo), item.balance);
            });
            if (this.clients.length > 1) {
                var OTHERSClient = this.clients.find(x => x.clientName == "OTHERS");
                this.clients.splice(this.clients.indexOf(OTHERSClient), 1);
                this.clients.unshift(OTHERSClient);
            }
            this.filteredOptions = this.myControl.valueChanges.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["startWith"])(''), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(client => client ? this._filter(client) : this.clients.slice()));
            if (this.cashEntryItem)
                if (this.cashEntryItem.clientId) {
                    var currentClient = this.clients.find(c => c.id == this.cashEntryItem.clientId);
                    this.myControl.setValue(currentClient.clientName);
                }
            this.UploadPageLoadStatus();
        });
    }
    calculatePaidAmount() {
        if (this.transactionType == src_environments_environment__WEBPACK_IMPORTED_MODULE_0__["environment"].OldBalanceTransactionType) {
            this.cashEntryItem.debitAmount = -1 * (this.cashEntryItem.amount ? this.cashEntryItem.amount : 0);
            this.cashEntryItem.paidAmount = (this.cashEntryItem.amount ? this.cashEntryItem.amount : 0);
        }
        else
            this.cashEntryItem.paidAmount = (this.cashEntryItem.amount ? this.cashEntryItem.amount : 0)
                - (this.cashEntryItem.debitAmount ? this.cashEntryItem.debitAmount : 0);
    }
    UploadPageLoadStatus() {
        this.noOfDataPointsLoaded = this.noOfDataPointsLoaded + 1;
        if (this.noOfDataPointsLoaded >= 4) {
            this.isPageLoaded = true;
        }
    }
    addNewServiceType() {
        const dialogRef = this.dialog.open(_Common_PopUps_add_new_service_type_add_new_service_type_component__WEBPACK_IMPORTED_MODULE_8__["AddNewServiceTypeComponent"], {
            width: '400px',
            disableClose: true
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result.event == "Created") {
                this.alertService.success("Service Type has been created successfully");
                this.GetServiceTypes(true);
            }
            else if (result.event == "Cancel") {
                this.alertService.error("Service Type creation has been cancelled");
            }
        });
    }
    addNewTransactionType() {
        const dialogRef = this.dialog.open(_Common_PopUps_add_new_transaction_type_add_new_transaction_type_component__WEBPACK_IMPORTED_MODULE_10__["AddNewTransactionTypeComponent"], {
            width: '400px',
            disableClose: true
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result.event == "Created") {
                this.alertService.success("Transaction Type has been created successfully");
                this.GetTransactionTypes(true);
            }
            else if (result.event == "Cancel") {
                this.alertService.error("Transaction Type creation has been cancelled");
            }
        });
    }
    addNewClient() {
        const dialogRef = this.dialog.open(_Common_PopUps_add_new_client_add_new_client_component__WEBPACK_IMPORTED_MODULE_7__["AddNewClientComponent"], {
            width: '100%',
            disableClose: true
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result.event == "Created") {
                this.alertService.success("Client has been created successfully");
                this.GetClients(true);
            }
            else if (result.event == "Cancel") {
                this.alertService.error("Client creation has been cancelled");
            }
        });
    }
}
CashEntryAddItemComponent.ɵfac = function CashEntryAddItemComponent_Factory(t) { return new (t || CashEntryAddItemComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_Services_common_client_service__WEBPACK_IMPORTED_MODULE_11__["ClientService"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_Services_Auth_authentication_service__WEBPACK_IMPORTED_MODULE_12__["AuthenticationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_Services_common_user_service__WEBPACK_IMPORTED_MODULE_13__["UserService"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_Services_common_servicetype_service__WEBPACK_IMPORTED_MODULE_14__["ServicetypeService"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_15__["AlertService"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_Services_common_transaction_type_service__WEBPACK_IMPORTED_MODULE_16__["TransactionTypeService"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_17__["DomSanitizer"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_18__["MatDialog"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])); };
CashEntryAddItemComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: CashEntryAddItemComponent, selectors: [["app-cash-entry-add-item"]], viewQuery: function CashEntryAddItemComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵstaticViewQuery"](_c0, true);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵviewQuery"](_c1, true);
    } if (rf & 2) {
        var _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.instance = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.itemForm = _t.first);
    } }, inputs: { cashEntryItem: "cashEntryItem", clients: "clients", users: "users", serviceTypes: "serviceTypes", transactionTypes: "transactionTypes" }, outputs: { formSubmit: "formSubmit", modalCancel: "modalCancel" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵNgOnChangesFeature"]], decls: 54, vars: 36, consts: [[3, "ngSubmit"], ["itemForm", "ngForm"], [1, "form-row", "row"], [1, "col-3", "loader-overlay", 3, "hidden"], [3, "diameter"], ["class", "col-3", 4, "ngIf"], [1, "col-3"], [1, "full-width-field"], ["matInput", "", "autofocus", "", "type", "text", "name", "description", "id", "txtdescription", 3, "ngModel", "ngModelChange"], [1, "col"], ["matInput", "", "type", "number", "name", "amount", "id", "txtAmount", 3, "ngModel", "ngModelChange"], ["matInput", "", "type", "text", "name", "remainingAmount", "id", "txtRemainingAmount", 3, "ngModel", "disabled", "ngModelChange"], ["matInput", "", "disabled", "", "type", "text", "name", "PaidAmount", "id", "txtPaidAmount", 3, "ngClass", "value"], [1, "col", "loader-overlay", 3, "hidden"], ["class", "col", 4, "ngIf"], ["matInput", "", "type", "text", "name", "remarks", "id", "txtRemarks", 3, "ngModel", "ngModelChange"], [1, "col", "center-align-field"], [1, "mr-3"], ["mat-raised-button", "", "type", "submit", 3, "color", "disabled"], [4, "ngIf"], ["required", "", "type", "text", "name", "dropdownCompOperator", "id", "dropdownCompOperator", "matInput", "", "placeholder", "COMPUTER OPERATOR", 3, "matAutocomplete", "formControl", "focusout"], [3, "displayWith", "optionSelected"], ["ddlCO", "matAutocomplete"], ["style", "margin-top: 10px;", 3, "value", 4, "ngFor", "ngForOf"], [2, "margin-top", "10px", 3, "value"], ["aria-hidden", "", "height", "50", "width", "50", 1, "example-option-img", "rounded-circle", 3, "src"], ["required", "", "type", "text", "name", "dropdownTransactionType", "id", "dropdownTransactionType", "matInput", "", "placeholder", "TRANSACTION TYPE", 3, "matAutocomplete", "formControl", "focusout"], [3, "displayWith", "panelWidth", "optionSelected"], ["ddlTransactionType", "matAutocomplete"], ["style", "margin-top: 2px;", 3, "value", 4, "ngFor", "ngForOf"], [1, "cssAddNewClient", 3, "value", "click"], [1, "material-icons", 2, "font-size", "50px"], [2, "margin-top", "2px", 3, "value"], ["required", "", "type", "text", "name", "dropdownServiceType", "id", "dropdownServiceType", "matInput", "", "placeholder", "SERVICE TYPE", 3, "matAutocomplete", "formControl", "focusout"], ["ddlServiceType", "matAutocomplete"], ["required", "", "type", "text", "name", "dropdownClient", "id", "dropdownClient", "matInput", "", "placeholder", "CUSTOMER", 3, "matAutocomplete", "formControl", "focusout"], ["auto", "matAutocomplete"], [1, "container"], [1, "row", 2, "height", "50px"], [1, "col", 2, "line-height", "15px"], [1, "row"], [2, "font-family", "Lato", "text-transform", "uppercase", "color", "#00cc86", "font-weight", "bold"], [2, "font-size", "15px"], [1, "cssClientVillage", 2, "font-weight", "bold", "font-style", "italic"], [1, "cssClientPhone", 2, "font-weight", "bold", "font-style", "italic"], [2, "font-size", "13px", 3, "ngClass"], ["mat-stroked-button", "", "type", "button", 3, "color", "click"]], template: function CashEntryAddItemComponent_Template(rf, ctx) { if (rf & 1) {
        const _r269 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "form", 0, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function CashEntryAddItemComponent_Template_form_ngSubmit_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r269); const _r232 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](1); return ctx.onSubmit(_r232); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](5, "app-loading-spinner", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](6, CashEntryAddItemComponent_div_6_Template, 7, 6, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](9, "app-loading-spinner", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](10, CashEntryAddItemComponent_div_10_Template, 12, 8, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "mat-form-field", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](14, "TRANSACTION NUMBER");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function CashEntryAddItemComponent_Template_input_ngModelChange_15_listener($event) { return ctx.transactionNumber = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](16, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](18, "app-loading-spinner", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](19, CashEntryAddItemComponent_div_19_Template, 12, 8, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](20, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](21, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "mat-form-field");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](23, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](24, "CREDIT");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](25, "input", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function CashEntryAddItemComponent_Template_input_ngModelChange_25_listener($event) { return ctx.cashEntryItem.amount = $event; })("ngModelChange", function CashEntryAddItemComponent_Template_input_ngModelChange_25_listener() { return ctx.calculatePaidAmount(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](26, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](27, "mat-form-field");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](28, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](29, "DEBIT");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](30, "input", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function CashEntryAddItemComponent_Template_input_ngModelChange_30_listener($event) { return ctx.cashEntryItem.debitAmount = $event; })("ngModelChange", function CashEntryAddItemComponent_Template_input_ngModelChange_30_listener() { return ctx.calculatePaidAmount(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](31, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](32, "mat-form-field");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](33, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](34, "PAID AMOUNT");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](35, "input", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](36, "currencyFormatter");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](37, "currency");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](38, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](39, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](40, "app-loading-spinner", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](41, CashEntryAddItemComponent_div_41_Template, 12, 8, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](42, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](43, "mat-form-field", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](44, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](45, "REMARKS");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](46, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function CashEntryAddItemComponent_Template_input_ngModelChange_46_listener($event) { return ctx.cashEntryItem.remarks = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](47, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](48, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](49, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](50, "button", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](51, CashEntryAddItemComponent_span_51_Template, 2, 0, "span", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](52, CashEntryAddItemComponent_span_52_Template, 2, 0, "span", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](53, CashEntryAddItemComponent_div_53_Template, 3, 1, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        const _r232 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("hidden", ctx.users);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("diameter", 30)("@ComponentAnimation", ctx.state);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.users);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("hidden", ctx.transactionTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("diameter", 30)("@ComponentAnimation", ctx.state);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.transactionTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.transactionNumber);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("hidden", ctx.serviceTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("diameter", 30)("@ComponentAnimation", ctx.state);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.serviceTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.cashEntryItem.amount);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.cashEntryItem.debitAmount)("disabled", ctx.transactionType == "OLD BALANCE RECEIVED");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction2"](33, _c2, ctx.cashEntryItem.paidAmount < 0, ctx.cashEntryItem.paidAmount > 0))("value", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](36, 28, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](37, 30, ctx.cashEntryItem.paidAmount, "INR")));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("hidden", ctx.clients);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("diameter", 30)("@ComponentAnimation", ctx.state);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.clients);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.cashEntryItem.remarks);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("color", ctx.isNewItem ? "primary" : "warn")("disabled", !_r232.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.isNewItem);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", !ctx.isNewItem);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", !ctx.isNewItem);
    } }, directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgForm"], _Common_loading_spinner_loading_spinner_component__WEBPACK_IMPORTED_MODULE_19__["LoadingSpinnerComponent"], _angular_common__WEBPACK_IMPORTED_MODULE_20__["NgIf"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_21__["MatFormField"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_21__["MatLabel"], _angular_material_input__WEBPACK_IMPORTED_MODULE_22__["MatInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgModel"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NumberValueAccessor"], _angular_common__WEBPACK_IMPORTED_MODULE_20__["NgClass"], _angular_material_button__WEBPACK_IMPORTED_MODULE_23__["MatButton"], _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_24__["MatAutocompleteTrigger"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["RequiredValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControlDirective"], _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_24__["MatAutocomplete"], _angular_common__WEBPACK_IMPORTED_MODULE_20__["NgForOf"], _angular_material_core__WEBPACK_IMPORTED_MODULE_25__["MatOption"]], pipes: [_helpers_currency_formatter_pipe__WEBPACK_IMPORTED_MODULE_26__["CurrencyFormatterPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_20__["CurrencyPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_20__["AsyncPipe"]], styles: [".example-h2[_ngcontent-%COMP%] {\n  margin: 10px;\n}\n\n.example-section[_ngcontent-%COMP%] {\n  display: flex;\n  align-content: center;\n  align-items: center;\n  height: 60px;\n}\n\n.example-margin[_ngcontent-%COMP%] {\n  margin: 0 10px;\n}\n\n.loader-overlay[_ngcontent-%COMP%] {\n  z-index: 1;\n  height: 100%;\n  width: 100%;\n  position: relative;\n}\n\n.cssAddNewClient[_ngcontent-%COMP%] {\n  margin-top: 11px;\n}\n\n.cssAddNewClient[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  vertical-align: middle;\n}\n\n.full-width-field[_ngcontent-%COMP%] {\n  width: 100%;\n}\n\n.center-align-field[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n\n\n.tooltip[_ngcontent-%COMP%] {\n  \n}\n\n.tooltip[_ngcontent-%COMP%]   .tooltiptext[_ngcontent-%COMP%] {\n  visibility: hidden;\n  width: 120px;\n  background-color: black;\n  color: #fff;\n  text-align: center;\n  padding: 5px 0;\n  border-radius: 6px;\n  position: absolute;\n  z-index: 1;\n}\n\n.tooltip[_ngcontent-%COMP%]   .tooltip[_ngcontent-%COMP%]:hover   .tooltiptext[_ngcontent-%COMP%] {\n  visibility: visible;\n}\n\n.red[_ngcontent-%COMP%] {\n  color: red;\n  font-weight: 700;\n}\n\n.green[_ngcontent-%COMP%] {\n  color: green;\n  font-weight: 700;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUGFnZXMvT3BlcmF0b3IvY2FzaC1lbnRyeS1hZGQtaXRlbS9DOlxcRGV2ZWxvcG1lbnRcXFNhdHRpXFxGaW5hbmNlVHJhY2tlci9zcmNcXGFwcFxcUGFnZXNcXE9wZXJhdG9yXFxjYXNoLWVudHJ5LWFkZC1pdGVtXFxjYXNoLWVudHJ5LWFkZC1pdGVtLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9QYWdlcy9PcGVyYXRvci9jYXNoLWVudHJ5LWFkZC1pdGVtL2Nhc2gtZW50cnktYWRkLWl0ZW0uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxZQUFBO0FDQ0o7O0FERUE7RUFDSSxhQUFBO0VBQ0EscUJBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7QUNDSjs7QURFQTtFQUNJLGNBQUE7QUNDSjs7QURFQTtFQUNJLFVBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0FDQ0o7O0FERUE7RUFDSSxnQkFBQTtBQ0NKOztBRENJO0VBQ0ksc0JBQUE7QUNDUjs7QURHQTtFQUNJLFdBQUE7QUNBSjs7QURHQTtFQUNJLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FDQUo7O0FER0EsaUJBQUE7O0FBQ0E7RUFhSSxvRUFBQTtBQ1pKOztBREFJO0VBQ0ksa0JBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7QUNFUjs7QURFSTtFQUNJLG1CQUFBO0FDQVI7O0FESUE7RUFDSSxVQUFBO0VBQ0EsZ0JBQUE7QUNESjs7QURHQTtFQUNJLFlBQUE7RUFDQSxnQkFBQTtBQ0FKIiwiZmlsZSI6InNyYy9hcHAvUGFnZXMvT3BlcmF0b3IvY2FzaC1lbnRyeS1hZGQtaXRlbS9jYXNoLWVudHJ5LWFkZC1pdGVtLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmV4YW1wbGUtaDIge1xyXG4gICAgbWFyZ2luOiAxMHB4O1xyXG59XHJcblxyXG4uZXhhbXBsZS1zZWN0aW9uIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgaGVpZ2h0OiA2MHB4O1xyXG59XHJcblxyXG4uZXhhbXBsZS1tYXJnaW4ge1xyXG4gICAgbWFyZ2luOiAwIDEwcHg7XHJcbn1cclxuXHJcbi5sb2FkZXItb3ZlcmxheSB7XHJcbiAgICB6LWluZGV4OiAxO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbi5jc3NBZGROZXdDbGllbnQge1xyXG4gICAgbWFyZ2luLXRvcDogMTFweDtcclxuXHJcbiAgICBzcGFuIHtcclxuICAgICAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG4gICAgfVxyXG59XHJcblxyXG4uZnVsbC13aWR0aC1maWVsZCB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufVxyXG5cclxuLmNlbnRlci1hbGlnbi1maWVsZCB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4vKiBUb29sdGlwIHRleHQgKi9cclxuLnRvb2x0aXAge1xyXG4gICAgLnRvb2x0aXB0ZXh0IHtcclxuICAgICAgICB2aXNpYmlsaXR5OiBoaWRkZW47XHJcbiAgICAgICAgd2lkdGg6IDEyMHB4O1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IGJsYWNrO1xyXG4gICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICBwYWRkaW5nOiA1cHggMDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgIHotaW5kZXg6IDE7XHJcbiAgICB9XHJcblxyXG4gICAgLyogU2hvdyB0aGUgdG9vbHRpcCB0ZXh0IHdoZW4geW91IG1vdXNlIG92ZXIgdGhlIHRvb2x0aXAgY29udGFpbmVyICovXHJcbiAgICAudG9vbHRpcDpob3ZlciAudG9vbHRpcHRleHQge1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHZpc2libGU7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5yZWQge1xyXG4gICAgY29sb3I6IHJlZDtcclxuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbn1cclxuLmdyZWVuIHtcclxuICAgIGNvbG9yOiBncmVlbjtcclxuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbn1cclxuIiwiLmV4YW1wbGUtaDIge1xuICBtYXJnaW46IDEwcHg7XG59XG5cbi5leGFtcGxlLXNlY3Rpb24ge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGhlaWdodDogNjBweDtcbn1cblxuLmV4YW1wbGUtbWFyZ2luIHtcbiAgbWFyZ2luOiAwIDEwcHg7XG59XG5cbi5sb2FkZXItb3ZlcmxheSB7XG4gIHotaW5kZXg6IDE7XG4gIGhlaWdodDogMTAwJTtcbiAgd2lkdGg6IDEwMCU7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cblxuLmNzc0FkZE5ld0NsaWVudCB7XG4gIG1hcmdpbi10b3A6IDExcHg7XG59XG4uY3NzQWRkTmV3Q2xpZW50IHNwYW4ge1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xufVxuXG4uZnVsbC13aWR0aC1maWVsZCB7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4uY2VudGVyLWFsaWduLWZpZWxkIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5cbi8qIFRvb2x0aXAgdGV4dCAqL1xuLnRvb2x0aXAge1xuICAvKiBTaG93IHRoZSB0b29sdGlwIHRleHQgd2hlbiB5b3UgbW91c2Ugb3ZlciB0aGUgdG9vbHRpcCBjb250YWluZXIgKi9cbn1cbi50b29sdGlwIC50b29sdGlwdGV4dCB7XG4gIHZpc2liaWxpdHk6IGhpZGRlbjtcbiAgd2lkdGg6IDEyMHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcbiAgY29sb3I6ICNmZmY7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZzogNXB4IDA7XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB6LWluZGV4OiAxO1xufVxuLnRvb2x0aXAgLnRvb2x0aXA6aG92ZXIgLnRvb2x0aXB0ZXh0IHtcbiAgdmlzaWJpbGl0eTogdmlzaWJsZTtcbn1cblxuLnJlZCB7XG4gIGNvbG9yOiByZWQ7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG59XG5cbi5ncmVlbiB7XG4gIGNvbG9yOiBncmVlbjtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbn0iXX0= */"], data: { animation: [src_app_app_route_animation__WEBPACK_IMPORTED_MODULE_5__["slideInAnimationForComponents"]] } });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](CashEntryAddItemComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"],
        args: [{
                selector: 'app-cash-entry-add-item',
                templateUrl: './cash-entry-add-item.component.html',
                styleUrls: ['./cash-entry-add-item.component.scss'],
                animations: [src_app_app_route_animation__WEBPACK_IMPORTED_MODULE_5__["slideInAnimationForComponents"]]
            }]
    }], function () { return [{ type: src_app_Services_common_client_service__WEBPACK_IMPORTED_MODULE_11__["ClientService"] }, { type: src_app_Services_Auth_authentication_service__WEBPACK_IMPORTED_MODULE_12__["AuthenticationService"] }, { type: src_app_Services_common_user_service__WEBPACK_IMPORTED_MODULE_13__["UserService"] }, { type: src_app_Services_common_servicetype_service__WEBPACK_IMPORTED_MODULE_14__["ServicetypeService"] }, { type: src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_15__["AlertService"] }, { type: src_app_Services_common_transaction_type_service__WEBPACK_IMPORTED_MODULE_16__["TransactionTypeService"] }, { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_17__["DomSanitizer"] }, { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_18__["MatDialog"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"] }]; }, { cashEntryItem: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"]
        }], formSubmit: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"]
        }], modalCancel: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"]
        }], clients: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"]
        }], users: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"]
        }], serviceTypes: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"]
        }], transactionTypes: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"]
        }], instance: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
            args: ['instance', { static: true }]
        }], itemForm: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
            args: ["itemForm"]
        }] }); })();


/***/ }),

/***/ "./src/app/Pages/Operator/cash-entry-item-list/cash-entry-item-list.component.ts":
/*!***************************************************************************************!*\
  !*** ./src/app/Pages/Operator/cash-entry-item-list/cash-entry-item-list.component.ts ***!
  \***************************************************************************************/
/*! exports provided: CashEntryItemListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CashEntryItemListComponent", function() { return CashEntryItemListComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_Models__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/Models */ "./src/app/Models/index.ts");
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/table */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/table.js");
/* harmony import */ var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/paginator */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/paginator.js");
/* harmony import */ var _Common_PopUps_cash_entry_edit_item_cash_entry_edit_item_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../Common/PopUps/cash-entry-edit-item/cash-entry-edit-item.component */ "./src/app/Pages/Common/PopUps/cash-entry-edit-item/cash-entry-edit-item.component.ts");
/* harmony import */ var src_app_Models_CashEntry_cash_entry_update_bo__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/Models/CashEntry/cash-entry-update-bo */ "./src/app/Models/CashEntry/cash-entry-update-bo.ts");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/dialog.js");
/* harmony import */ var src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/Services/Alert/alert.service */ "./src/app/Services/Alert/alert.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");
/* harmony import */ var _helpers_currency_formatter_pipe__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../_helpers/currency-formatter.pipe */ "./src/app/_helpers/currency-formatter.pipe.ts");















function CashEntryItemListComponent_div_14_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " No Transaction(s) are done today ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function CashEntryItemListComponent_div_15_th_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " Action ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function CashEntryItemListComponent_div_15_td_5_Template(rf, ctx) { if (rf & 1) {
    const _r218 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "button", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CashEntryItemListComponent_div_15_td_5_Template_button_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r218); const element_r216 = ctx.$implicit; const ctx_r217 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r217.openDialog("Update", element_r216); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "i", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "button", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CashEntryItemListComponent_div_15_td_5_Template_button_click_3_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r218); const element_r216 = ctx.$implicit; const ctx_r219 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r219.openDialog("Delete", element_r216); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "i", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function CashEntryItemListComponent_div_15_td_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "td", 45);
} }
function CashEntryItemListComponent_div_15_th_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " S No. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function CashEntryItemListComponent_div_15_td_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r220 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", element_r220.sNo, " ");
} }
function CashEntryItemListComponent_div_15_td_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " Total ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("colspan", 5);
} }
function CashEntryItemListComponent_div_15_th_12_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " COMPUTER OPERATOR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function CashEntryItemListComponent_div_15_td_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r221 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", element_r221.compOperarator.firstName + " " + element_r221.compOperarator.lastName, " ");
} }
const _c0 = function () { return { "display": "none" }; };
function CashEntryItemListComponent_div_15_td_14_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "td", 47);
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](1, _c0));
} }
function CashEntryItemListComponent_div_15_th_16_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " TRANSACTION DETAILS ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function CashEntryItemListComponent_div_15_td_17_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r222 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", element_r222.description, " ");
} }
function CashEntryItemListComponent_div_15_td_18_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "td", 47);
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](1, _c0));
} }
function CashEntryItemListComponent_div_15_th_20_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " SERVICE TYPE ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function CashEntryItemListComponent_div_15_td_21_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r223 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", element_r223.serviceType.sType + " - " + element_r223.serviceType.sTypeDesc, " ");
} }
function CashEntryItemListComponent_div_15_td_22_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "td", 47);
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](1, _c0));
} }
function CashEntryItemListComponent_div_15_th_24_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " CUSTOMER ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function CashEntryItemListComponent_div_15_td_25_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r224 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", element_r224.client.clientName, " ");
} }
function CashEntryItemListComponent_div_15_td_26_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "td", 47);
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](1, _c0));
} }
function CashEntryItemListComponent_div_15_th_28_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " CREDIT ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
const _c1 = function (a0, a1) { return { red: a0, green: a1 }; };
function CashEntryItemListComponent_div_15_td_29_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "currencyFormatter");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](3, "currency");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r225 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](7, _c1, element_r225.amount < 0, element_r225.amount > 0));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 2, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](3, 4, element_r225.amount, "INR")), " ");
} }
function CashEntryItemListComponent_div_15_td_30_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "currencyFormatter");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](3, "currency");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r203 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](7, _c1, ctx_r203.getTotalAmount() < 0, ctx_r203.getTotalAmount() > 0));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 2, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](3, 4, ctx_r203.getTotalAmount(), "INR")), " ");
} }
function CashEntryItemListComponent_div_15_th_32_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " DEBIT ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function CashEntryItemListComponent_div_15_td_33_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "currencyFormatter");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](3, "currency");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r226 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](7, _c1, element_r226.debitAmount > 0, element_r226.debitAmount <= 0));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 2, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](3, 4, element_r226.debitAmount, "INR")), " ");
} }
function CashEntryItemListComponent_div_15_td_34_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "currencyFormatter");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](3, "currency");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r206 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](7, _c1, ctx_r206.getTotalDebitAmount() > 0, ctx_r206.getTotalDebitAmount() <= 0));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 2, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](3, 4, ctx_r206.getTotalDebitAmount(), "INR")), " ");
} }
function CashEntryItemListComponent_div_15_th_36_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " PAID AMOUNT ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function CashEntryItemListComponent_div_15_td_37_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "currencyFormatter");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](3, "currency");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r227 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](7, _c1, element_r227.paidAmount < 0, element_r227.paidAmount > 0));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 2, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](3, 4, element_r227.paidAmount, "INR")), " ");
} }
function CashEntryItemListComponent_div_15_td_38_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "currencyFormatter");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](3, "currency");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r209 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](7, _c1, ctx_r209.getTotalPaidAmount() < 0, ctx_r209.getTotalPaidAmount() > 0));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 2, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](3, 4, ctx_r209.getTotalPaidAmount(), "INR")), " ");
} }
function CashEntryItemListComponent_div_15_th_40_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " REMARKS ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function CashEntryItemListComponent_div_15_td_41_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r228 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", element_r228.remarks, " ");
} }
function CashEntryItemListComponent_div_15_td_42_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "td", 45);
} }
function CashEntryItemListComponent_div_15_tr_43_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "tr", 54);
} }
function CashEntryItemListComponent_div_15_tr_44_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "tr", 55);
} }
function CashEntryItemListComponent_div_15_tr_45_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "tr", 56);
} }
const _c2 = function () { return [5, 10, 20, 50]; };
function CashEntryItemListComponent_div_15_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "table", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](3, 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, CashEntryItemListComponent_div_15_th_4_Template, 2, 0, "th", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, CashEntryItemListComponent_div_15_td_5_Template, 5, 0, "td", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, CashEntryItemListComponent_div_15_td_6_Template, 1, 0, "td", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](7, 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, CashEntryItemListComponent_div_15_th_8_Template, 2, 0, "th", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](9, CashEntryItemListComponent_div_15_td_9_Template, 2, 1, "td", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](10, CashEntryItemListComponent_div_15_td_10_Template, 2, 1, "td", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](11, 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](12, CashEntryItemListComponent_div_15_th_12_Template, 2, 0, "th", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](13, CashEntryItemListComponent_div_15_td_13_Template, 2, 1, "td", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](14, CashEntryItemListComponent_div_15_td_14_Template, 1, 2, "td", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](15, 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](16, CashEntryItemListComponent_div_15_th_16_Template, 2, 0, "th", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](17, CashEntryItemListComponent_div_15_td_17_Template, 2, 1, "td", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](18, CashEntryItemListComponent_div_15_td_18_Template, 1, 2, "td", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](19, 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](20, CashEntryItemListComponent_div_15_th_20_Template, 2, 0, "th", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](21, CashEntryItemListComponent_div_15_td_21_Template, 2, 1, "td", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](22, CashEntryItemListComponent_div_15_td_22_Template, 1, 2, "td", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](23, 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](24, CashEntryItemListComponent_div_15_th_24_Template, 2, 0, "th", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](25, CashEntryItemListComponent_div_15_td_25_Template, 2, 1, "td", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](26, CashEntryItemListComponent_div_15_td_26_Template, 1, 2, "td", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](27, 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](28, CashEntryItemListComponent_div_15_th_28_Template, 2, 0, "th", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](29, CashEntryItemListComponent_div_15_td_29_Template, 4, 10, "td", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](30, CashEntryItemListComponent_div_15_td_30_Template, 4, 10, "td", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](31, 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](32, CashEntryItemListComponent_div_15_th_32_Template, 2, 0, "th", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](33, CashEntryItemListComponent_div_15_td_33_Template, 4, 10, "td", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](34, CashEntryItemListComponent_div_15_td_34_Template, 4, 10, "td", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](35, 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](36, CashEntryItemListComponent_div_15_th_36_Template, 2, 0, "th", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](37, CashEntryItemListComponent_div_15_td_37_Template, 4, 10, "td", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](38, CashEntryItemListComponent_div_15_td_38_Template, 4, 10, "td", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](39, 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](40, CashEntryItemListComponent_div_15_th_40_Template, 2, 0, "th", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](41, CashEntryItemListComponent_div_15_td_41_Template, 2, 1, "td", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](42, CashEntryItemListComponent_div_15_td_42_Template, 1, 0, "td", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](43, CashEntryItemListComponent_div_15_tr_43_Template, 1, 0, "tr", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](44, CashEntryItemListComponent_div_15_tr_44_Template, 1, 0, "tr", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](45, CashEntryItemListComponent_div_15_tr_45_Template, 1, 0, "tr", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](46, "mat-paginator", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r182 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("dataSource", ctx_r182.dataSource);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](41);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matHeaderRowDef", ctx_r182.displayedColumns)("matHeaderRowDefSticky", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matRowDefColumns", ctx_r182.displayedColumns);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matFooterRowDef", ctx_r182.displayedColumns)("matFooterRowDefSticky", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("pageSizeOptions", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](7, _c2));
} }
class CashEntryItemListComponent {
    constructor(dialog, alertService) {
        this.dialog = dialog;
        this.alertService = alertService;
        this.deleteBudgetItem = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.update = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        //Table code
        this.displayedColumns = ['actionsColumn', 'SNo', 'compOperator', 'description', 'serviceType', 'client', 'amount', 'remainingAmount', 'paidAmount', 'remarks'];
    }
    ngOnInit() {
        this.refreshData();
    }
    ngOnChanges() {
        this.refreshData();
    }
    delete(budgetItem) {
        this.deleteBudgetItem.emit(budgetItem);
    }
    refreshData() {
        this.dataSource = new _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatTableDataSource"](this.cashEntryDisplayItems);
        setTimeout(() => this.dataSource.paginator = this.paginator);
    }
    getTotalAmount() {
        return this.cashEntryDisplayItems.map(t => t.amount).reduce((acc, value) => acc + value, 0);
    }
    getTotalDebitAmount() {
        return this.cashEntryDisplayItems.map(t => t.debitAmount).reduce((acc, value) => acc + value, 0);
    }
    getTotalPaidAmount() {
        return this.cashEntryDisplayItems.map(t => t.paidAmount).reduce((acc, value) => acc + value, 0);
    }
    openDialog(action, obj) {
        this.BO = new src_app_Models_CashEntry_cash_entry_update_bo__WEBPACK_IMPORTED_MODULE_5__["CashEntryUpdateBO"]();
        this.BO.action = action;
        this.BO.oldObject = new src_app_Models__WEBPACK_IMPORTED_MODULE_1__["CashEntryItem"](obj.sNo, obj.compOperarator.userId, obj.description, obj.serviceType.sid, obj.client.id, obj.amount, obj.debitAmount, obj.paidAmount, obj.remarks);
        if (action == "Delete")
            this.dialogWidth = '250px';
        else if (action == "Update")
            this.dialogWidth = '100%';
        const dialogRef = this.dialog.open(_Common_PopUps_cash_entry_edit_item_cash_entry_edit_item_component__WEBPACK_IMPORTED_MODULE_4__["CashEntryEditItemComponent"], {
            width: this.dialogWidth,
            data: this.BO
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result.event == 'Update') {
                this.updateRowData(result.data);
            }
            else if (result.event == 'Delete') {
                this.deleteRowData(result.data);
            }
            else if (result.event == 'Cancel') {
                this.alertService.info("Update has been cancelled");
            }
        });
    }
    updateRowData(BO_obj) {
        this.update.emit(BO_obj);
        this.refreshData();
    }
    deleteRowData(row_obj) {
        this.deleteBudgetItem.emit(row_obj);
        this.refreshData();
    }
}
CashEntryItemListComponent.ɵfac = function CashEntryItemListComponent_Factory(t) { return new (t || CashEntryItemListComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__["MatDialog"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_7__["AlertService"])); };
CashEntryItemListComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: CashEntryItemListComponent, selectors: [["app-cash-entry-item-list"]], viewQuery: function CashEntryItemListComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_angular_material_paginator__WEBPACK_IMPORTED_MODULE_3__["MatPaginator"], true);
    } if (rf & 2) {
        var _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.paginator = _t.first);
    } }, inputs: { cashEntryDisplayItems: "cashEntryDisplayItems", totalDebit: "totalDebit" }, outputs: { deleteBudgetItem: "deleteBudgetItem", update: "update" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]], decls: 16, vars: 3, consts: [[1, "budget-items-section"], [1, "budget-items-container"], [1, "income-column"], [1, "container"], [1, "row"], [1, "col-sm", "headerSection"], [2, "color", "firebrick"], ["routerLink", "/DebitReport", "skipLocationChange", ""], [1, "col-sm"], ["class", "h3", "style", "padding-left: 50px; color: red; justify-content: center; text-align: center;", 4, "ngIf"], ["class", "budget-items d-flex justify-content-center", 4, "ngIf"], [1, "h3", 2, "padding-left", "50px", "color", "red", "justify-content", "center", "text-align", "center"], [1, "budget-items", "d-flex", "justify-content-center"], [1, "mat-elevation-z8"], ["mat-table", "", 3, "dataSource"], ["matColumnDef", "actionsColumn"], ["mat-header-cell", "", "class", "w-10", 4, "matHeaderCellDef"], ["mat-cell", "", 4, "matCellDef"], ["mat-footer-cell", "", 4, "matFooterCellDef"], ["matColumnDef", "SNo"], ["mat-header-cell", "", "class", "w-4", 4, "matHeaderCellDef"], ["matColumnDef", "compOperator"], ["mat-footer-cell", "", 3, "ngStyle", 4, "matFooterCellDef"], ["matColumnDef", "description"], ["mat-header-cell", "", "class", "w-15", 4, "matHeaderCellDef"], ["matColumnDef", "serviceType"], ["matColumnDef", "client"], ["matColumnDef", "amount"], ["mat-header-cell", "", "class", "w-7", 4, "matHeaderCellDef"], ["mat-cell", "", 3, "ngClass", 4, "matCellDef"], ["mat-footer-cell", "", 3, "ngClass", 4, "matFooterCellDef"], ["matColumnDef", "remainingAmount"], ["matColumnDef", "paidAmount"], ["mat-header-cell", "", "class", "w-6", 4, "matHeaderCellDef"], ["matColumnDef", "remarks"], ["mat-header-cell", "", "class", "w-25", 4, "matHeaderCellDef"], ["mat-header-row", "", 4, "matHeaderRowDef", "matHeaderRowDefSticky"], ["mat-row", "", 4, "matRowDef", "matRowDefColumns"], ["mat-footer-row", "", 4, "matFooterRowDef", "matFooterRowDefSticky"], ["showFirstLastButtons", "", 3, "pageSizeOptions"], ["mat-header-cell", "", 1, "w-10"], ["mat-cell", ""], ["mat-icon-button", "", "color", "primary", "focusable", "false", 3, "click"], [1, "fa", "fa-pencil", "mat-icon"], [1, "fa", "fa-trash", "mat-icon"], ["mat-footer-cell", ""], ["mat-header-cell", "", 1, "w-4"], ["mat-footer-cell", "", 3, "ngStyle"], ["mat-header-cell", "", 1, "w-15"], ["mat-header-cell", "", 1, "w-7"], ["mat-cell", "", 3, "ngClass"], ["mat-footer-cell", "", 3, "ngClass"], ["mat-header-cell", "", 1, "w-6"], ["mat-header-cell", "", 1, "w-25"], ["mat-header-row", ""], ["mat-row", ""], ["mat-footer-row", ""]], template: function CashEntryItemListComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "h1", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "TOTAL DEBIT : ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "a", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "h1");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "TODAY'S TRANSACTIONS");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](13, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](14, CashEntryItemListComponent_div_14_Template, 2, 0, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](15, CashEntryItemListComponent_div_15_Template, 47, 8, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.totalDebit.totalDebit);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.cashEntryDisplayItems || ctx.cashEntryDisplayItems.length == 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.cashEntryDisplayItems && ctx.cashEntryDisplayItems.length > 0);
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_8__["RouterLinkWithHref"], _angular_common__WEBPACK_IMPORTED_MODULE_9__["NgIf"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatTable"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatColumnDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatHeaderCellDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatCellDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatFooterCellDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatHeaderRowDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatRowDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatFooterRowDef"], _angular_material_paginator__WEBPACK_IMPORTED_MODULE_3__["MatPaginator"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatHeaderCell"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatCell"], _angular_material_button__WEBPACK_IMPORTED_MODULE_10__["MatButton"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatFooterCell"], _angular_common__WEBPACK_IMPORTED_MODULE_9__["NgStyle"], _angular_common__WEBPACK_IMPORTED_MODULE_9__["NgClass"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatHeaderRow"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatRow"], _angular_material_table__WEBPACK_IMPORTED_MODULE_2__["MatFooterRow"]], pipes: [_helpers_currency_formatter_pipe__WEBPACK_IMPORTED_MODULE_11__["CurrencyFormatterPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_9__["CurrencyPipe"]], styles: ["@font-face {\n  font-family: \"Nunito\";\n  font-style: normal;\n  font-weight: 400;\n  src: url(\"/assets/fonts/Nunito/nunito-v12-latin-regular.eot\");\n  src: local(\"Nunito Regular\"), local(\"Nunito-Regular\"), url(\"/assets/fonts/Nunito/nunito-v12-latin-regular.eot?#iefix\") format(\"embedded-opentype\"), url(\"/assets/fonts/Nunito/nunito-v12-latin-regular.woff2\") format(\"woff2\"), url(\"/assets/fonts/Nunito/nunito-v12-latin-regular.woff\") format(\"woff\"), url(\"/assets/fonts/Nunito/nunito-v12-latin-regular.ttf\") format(\"truetype\"), url(\"/assets/fonts/Nunito/nunito-v12-latin-regular.svg#Nunito\") format(\"svg\");\n}\n\n@font-face {\n  font-family: \"Nunito\";\n  font-style: normal;\n  font-weight: 700;\n  src: url(\"/assets/fonts/Nunito/nunito-v12-latin-700.eot\");\n  src: local(\"Nunito Bold\"), local(\"Nunito-Bold\"), url(\"/assets/fonts/Nunito/nunito-v12-latin-700.eot?#iefix\") format(\"embedded-opentype\"), url(\"/assets/fonts/Nunito/nunito-v12-latin-700.woff2\") format(\"woff2\"), url(\"/assets/fonts/Nunito/nunito-v12-latin-700.woff\") format(\"woff\"), url(\"/assets/fonts/Nunito/nunito-v12-latin-700.ttf\") format(\"truetype\"), url(\"/assets/fonts/Nunito/nunito-v12-latin-700.svg#Nunito\") format(\"svg\");\n}\n\n@font-face {\n  font-family: \"Lato\";\n  font-style: normal;\n  font-weight: 300;\n  src: url(\"/assets/fonts/Lato/lato-v16-latin-300.eot\");\n  src: local(\"Lato Light\"), local(\"Lato-Light\"), url(\"/assets/fonts/Lato/lato-v16-latin-300.eot?#iefix\") format(\"embedded-opentype\"), url(\"/assets/fonts/Lato/lato-v16-latin-300.woff2\") format(\"woff2\"), url(\"/assets/fonts/Lato/lato-v16-latin-300.woff\") format(\"woff\"), url(\"/assets/fonts/Lato/lato-v16-latin-300.ttf\") format(\"truetype\"), url(\"/assets/fonts/Lato/lato-v16-latin-300.svg#Lato\") format(\"svg\");\n}\n\n@font-face {\n  font-family: \"Lato\";\n  font-style: normal;\n  font-weight: 900;\n  src: url(\"/assets/fonts/Lato/lato-v16-latin-900.eot\");\n  src: local(\"Lato Black\"), local(\"Lato-Black\"), url(\"/assets/fonts/Lato/lato-v16-latin-900.eot?#iefix\") format(\"embedded-opentype\"), url(\"/assets/fonts/Lato/lato-v16-latin-900.woff2\") format(\"woff2\"), url(\"/assets/fonts/Lato/lato-v16-latin-900.woff\") format(\"woff\"), url(\"/assets/fonts/Lato/lato-v16-latin-900.ttf\") format(\"truetype\"), url(\"/assets/fonts/Lato/lato-v16-latin-900.svg#Lato\") format(\"svg\");\n}\n.budget-items-section[_ngcontent-%COMP%] {\n  display: flex;\n  padding: 5px;\n  justify-content: center;\n  align-items: center;\n}\n.budget-items-section[_ngcontent-%COMP%]   .budget-items-container[_ngcontent-%COMP%] {\n  display: flex;\n  height: 100%;\n  width: 100%;\n}\n.budget-items-section[_ngcontent-%COMP%]   .budget-items-container[_ngcontent-%COMP%]   .income-column[_ngcontent-%COMP%], .budget-items-section[_ngcontent-%COMP%]   .budget-items-container[_ngcontent-%COMP%]   .expenses-column[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  flex-basis: 0;\n  flex-grow: 1;\n}\n.budget-items-section[_ngcontent-%COMP%]   .budget-items-container[_ngcontent-%COMP%]   .income-column[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%], .budget-items-section[_ngcontent-%COMP%]   .budget-items-container[_ngcontent-%COMP%]   .expenses-column[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n  font-family: \"Lato\";\n  font-size: 24px;\n  font-weight: 900;\n  text-transform: uppercase;\n}\n.budget-items-section[_ngcontent-%COMP%]   .budget-items-container[_ngcontent-%COMP%]   .income-column[_ngcontent-%COMP%]   .budget-items[_ngcontent-%COMP%], .budget-items-section[_ngcontent-%COMP%]   .budget-items-container[_ngcontent-%COMP%]   .expenses-column[_ngcontent-%COMP%]   .budget-items[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  margin-top: 10px;\n}\n.budget-items-section[_ngcontent-%COMP%]   .budget-items-container[_ngcontent-%COMP%]   .income-column[_ngcontent-%COMP%] {\n  margin-right: 5px;\n}\n.budget-items-section[_ngcontent-%COMP%]   .budget-items-container[_ngcontent-%COMP%]   .income-column[_ngcontent-%COMP%]   .headerSection[_ngcontent-%COMP%] {\n  justify-content: center;\n  align-items: center;\n  text-align: center;\n}\n.budget-items-section[_ngcontent-%COMP%]   .budget-items-container[_ngcontent-%COMP%]   .income-column[_ngcontent-%COMP%]   .headerSection[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n  color: #00cc86;\n}\n.budget-items[_ngcontent-%COMP%]   .mat-elevation-z8[_ngcontent-%COMP%] {\n  height: 300px;\n  overflow: auto;\n}\n.budget-items[_ngcontent-%COMP%]   .mat-elevation-z8[_ngcontent-%COMP%]   table[_ngcontent-%COMP%] {\n  width: 100%;\n}\n.budget-items[_ngcontent-%COMP%]   .mat-elevation-z8[_ngcontent-%COMP%]   tr.mat-footer-row[_ngcontent-%COMP%] {\n  font-weight: bold;\n}\n.budget-items[_ngcontent-%COMP%]   .mat-elevation-z8[_ngcontent-%COMP%]   .mat-table-sticky[_ngcontent-%COMP%] {\n  border-top: 1px solid #e0e0e0;\n}\n.w-0[_ngcontent-%COMP%] {\n  width: 0%;\n}\n.w-1[_ngcontent-%COMP%] {\n  width: 1%;\n}\n.w-2[_ngcontent-%COMP%] {\n  width: 2%;\n}\n.w-3[_ngcontent-%COMP%] {\n  width: 3%;\n}\n.w-4[_ngcontent-%COMP%] {\n  width: 4%;\n}\n.w-5[_ngcontent-%COMP%] {\n  width: 5%;\n}\n.w-6[_ngcontent-%COMP%] {\n  width: 6%;\n}\n.w-7[_ngcontent-%COMP%] {\n  width: 7%;\n}\n.w-8[_ngcontent-%COMP%] {\n  width: 8%;\n}\n.w-9[_ngcontent-%COMP%] {\n  width: 9%;\n}\n.w-10[_ngcontent-%COMP%] {\n  width: 10%;\n}\n.w-11[_ngcontent-%COMP%] {\n  width: 11%;\n}\n.w-12[_ngcontent-%COMP%] {\n  width: 12%;\n}\n.w-13[_ngcontent-%COMP%] {\n  width: 13%;\n}\n.w-14[_ngcontent-%COMP%] {\n  width: 14%;\n}\n.w-15[_ngcontent-%COMP%] {\n  width: 15%;\n}\n.w-16[_ngcontent-%COMP%] {\n  width: 16%;\n}\n.w-17[_ngcontent-%COMP%] {\n  width: 17%;\n}\n.w-18[_ngcontent-%COMP%] {\n  width: 18%;\n}\n.w-19[_ngcontent-%COMP%] {\n  width: 19%;\n}\n.w-20[_ngcontent-%COMP%] {\n  width: 20%;\n}\n.w-21[_ngcontent-%COMP%] {\n  width: 21%;\n}\n.w-22[_ngcontent-%COMP%] {\n  width: 22%;\n}\n.w-23[_ngcontent-%COMP%] {\n  width: 23%;\n}\n.w-24[_ngcontent-%COMP%] {\n  width: 24%;\n}\n.w-25[_ngcontent-%COMP%] {\n  width: 25%;\n}\n.w-26[_ngcontent-%COMP%] {\n  width: 26%;\n}\n.w-27[_ngcontent-%COMP%] {\n  width: 27%;\n}\n.w-28[_ngcontent-%COMP%] {\n  width: 28%;\n}\n.w-29[_ngcontent-%COMP%] {\n  width: 29%;\n}\n.w-30[_ngcontent-%COMP%] {\n  width: 30%;\n}\n.w-31[_ngcontent-%COMP%] {\n  width: 31%;\n}\n.w-32[_ngcontent-%COMP%] {\n  width: 32%;\n}\n.w-33[_ngcontent-%COMP%] {\n  width: 33%;\n}\n.w-34[_ngcontent-%COMP%] {\n  width: 34%;\n}\n.w-35[_ngcontent-%COMP%] {\n  width: 35%;\n}\n.w-36[_ngcontent-%COMP%] {\n  width: 36%;\n}\n.w-37[_ngcontent-%COMP%] {\n  width: 37%;\n}\n.w-38[_ngcontent-%COMP%] {\n  width: 38%;\n}\n.w-39[_ngcontent-%COMP%] {\n  width: 39%;\n}\n.w-40[_ngcontent-%COMP%] {\n  width: 40%;\n}\n.w-41[_ngcontent-%COMP%] {\n  width: 41%;\n}\n.w-42[_ngcontent-%COMP%] {\n  width: 42%;\n}\n.w-43[_ngcontent-%COMP%] {\n  width: 43%;\n}\n.w-44[_ngcontent-%COMP%] {\n  width: 44%;\n}\n.w-45[_ngcontent-%COMP%] {\n  width: 45%;\n}\n.w-46[_ngcontent-%COMP%] {\n  width: 46%;\n}\n.w-47[_ngcontent-%COMP%] {\n  width: 47%;\n}\n.w-48[_ngcontent-%COMP%] {\n  width: 48%;\n}\n.w-49[_ngcontent-%COMP%] {\n  width: 49%;\n}\n.w-50[_ngcontent-%COMP%] {\n  width: 50%;\n}\n.w-51[_ngcontent-%COMP%] {\n  width: 51%;\n}\n.w-52[_ngcontent-%COMP%] {\n  width: 52%;\n}\n.w-53[_ngcontent-%COMP%] {\n  width: 53%;\n}\n.w-54[_ngcontent-%COMP%] {\n  width: 54%;\n}\n.w-55[_ngcontent-%COMP%] {\n  width: 55%;\n}\n.w-56[_ngcontent-%COMP%] {\n  width: 56%;\n}\n.w-57[_ngcontent-%COMP%] {\n  width: 57%;\n}\n.w-58[_ngcontent-%COMP%] {\n  width: 58%;\n}\n.w-59[_ngcontent-%COMP%] {\n  width: 59%;\n}\n.w-60[_ngcontent-%COMP%] {\n  width: 60%;\n}\n.w-61[_ngcontent-%COMP%] {\n  width: 61%;\n}\n.w-62[_ngcontent-%COMP%] {\n  width: 62%;\n}\n.w-63[_ngcontent-%COMP%] {\n  width: 63%;\n}\n.w-64[_ngcontent-%COMP%] {\n  width: 64%;\n}\n.w-65[_ngcontent-%COMP%] {\n  width: 65%;\n}\n.w-66[_ngcontent-%COMP%] {\n  width: 66%;\n}\n.w-67[_ngcontent-%COMP%] {\n  width: 67%;\n}\n.w-68[_ngcontent-%COMP%] {\n  width: 68%;\n}\n.w-69[_ngcontent-%COMP%] {\n  width: 69%;\n}\n.w-70[_ngcontent-%COMP%] {\n  width: 70%;\n}\n.w-71[_ngcontent-%COMP%] {\n  width: 71%;\n}\n.w-72[_ngcontent-%COMP%] {\n  width: 72%;\n}\n.w-73[_ngcontent-%COMP%] {\n  width: 73%;\n}\n.w-74[_ngcontent-%COMP%] {\n  width: 74%;\n}\n.w-75[_ngcontent-%COMP%] {\n  width: 75%;\n}\n.w-76[_ngcontent-%COMP%] {\n  width: 76%;\n}\n.w-77[_ngcontent-%COMP%] {\n  width: 77%;\n}\n.w-78[_ngcontent-%COMP%] {\n  width: 78%;\n}\n.w-79[_ngcontent-%COMP%] {\n  width: 79%;\n}\n.w-80[_ngcontent-%COMP%] {\n  width: 80%;\n}\n.w-81[_ngcontent-%COMP%] {\n  width: 81%;\n}\n.w-82[_ngcontent-%COMP%] {\n  width: 82%;\n}\n.w-83[_ngcontent-%COMP%] {\n  width: 83%;\n}\n.w-84[_ngcontent-%COMP%] {\n  width: 84%;\n}\n.w-85[_ngcontent-%COMP%] {\n  width: 85%;\n}\n.w-86[_ngcontent-%COMP%] {\n  width: 86%;\n}\n.w-87[_ngcontent-%COMP%] {\n  width: 87%;\n}\n.w-88[_ngcontent-%COMP%] {\n  width: 88%;\n}\n.w-89[_ngcontent-%COMP%] {\n  width: 89%;\n}\n.w-90[_ngcontent-%COMP%] {\n  width: 90%;\n}\n.w-91[_ngcontent-%COMP%] {\n  width: 91%;\n}\n.w-92[_ngcontent-%COMP%] {\n  width: 92%;\n}\n.w-93[_ngcontent-%COMP%] {\n  width: 93%;\n}\n.w-94[_ngcontent-%COMP%] {\n  width: 94%;\n}\n.w-95[_ngcontent-%COMP%] {\n  width: 95%;\n}\n.w-96[_ngcontent-%COMP%] {\n  width: 96%;\n}\n.w-97[_ngcontent-%COMP%] {\n  width: 97%;\n}\n.w-98[_ngcontent-%COMP%] {\n  width: 98%;\n}\n.w-99[_ngcontent-%COMP%] {\n  width: 99%;\n}\n.w-100[_ngcontent-%COMP%] {\n  width: 100%;\n}\n.red[_ngcontent-%COMP%] {\n  color: red;\n}\n.green[_ngcontent-%COMP%] {\n  color: green;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUGFnZXMvT3BlcmF0b3IvY2FzaC1lbnRyeS1pdGVtLWxpc3QvQzpcXERldmVsb3BtZW50XFxTYXR0aVxcRmluYW5jZVRyYWNrZXIvc3JjXFxtYWluLXN0eWxlcy5zY3NzIiwic3JjL2FwcC9QYWdlcy9PcGVyYXRvci9jYXNoLWVudHJ5LWl0ZW0tbGlzdC9jYXNoLWVudHJ5LWl0ZW0tbGlzdC5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvUGFnZXMvT3BlcmF0b3IvY2FzaC1lbnRyeS1pdGVtLWxpc3QvQzpcXERldmVsb3BtZW50XFxTYXR0aVxcRmluYW5jZVRyYWNrZXIvc3JjXFxhcHBcXFBhZ2VzXFxPcGVyYXRvclxcY2FzaC1lbnRyeS1pdGVtLWxpc3RcXGNhc2gtZW50cnktaXRlbS1saXN0LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUlBLDJCQUFBO0FBQ0E7RUFDRSxxQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSw2REFBQTtFQUNBLG9jQUFBO0FDSEY7QURVQSx1QkFBQTtBQUNBO0VBQ0UscUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EseURBQUE7RUFDQSwwYUFBQTtBQ1JGO0FEZ0JBLHFCQUFBO0FBQ0E7RUFDRSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxxREFBQTtFQUNBLGtaQUFBO0FDZEY7QURxQkEscUJBQUE7QUFDQTtFQUNFLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLHFEQUFBO0VBQ0Esa1pBQUE7QUNuQkY7QUM3QkE7RUFDSSxhQUFBO0VBQ0EsWUFBQTtFQUdBLHVCQUFBO0VBQ0EsbUJBQUE7QUQ2Qko7QUMzQkk7RUFDSSxhQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUQ2QlI7QUMzQlE7O0VBRUksYUFBQTtFQUNBLHNCQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7QUQ2Qlo7QUMzQlk7O0VBQ0ksbUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5QkFBQTtBRDhCaEI7QUMzQlk7O0VBQ0ksYUFBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7QUQ4QmhCO0FDMUJRO0VBQ0ksaUJBQUE7QUQ0Qlo7QUMxQlk7RUFDSSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUQ0QmhCO0FDMUJnQjtFQUNJLGNGa0JaO0FDVVI7QUNwQkk7RUFDSSxhQUFBO0VBQ0EsY0FBQTtBRHVCUjtBQ3JCUTtFQUNJLFdBQUE7QUR1Qlo7QUNwQlE7RUFDSSxpQkFBQTtBRHNCWjtBQ25CUTtFQUNJLDZCQUFBO0FEcUJaO0FDVEk7RUFDSSxTQUFBO0FEWVI7QUNiSTtFQUNJLFNBQUE7QURnQlI7QUNqQkk7RUFDSSxTQUFBO0FEb0JSO0FDckJJO0VBQ0ksU0FBQTtBRHdCUjtBQ3pCSTtFQUNJLFNBQUE7QUQ0QlI7QUM3Qkk7RUFDSSxTQUFBO0FEZ0NSO0FDakNJO0VBQ0ksU0FBQTtBRG9DUjtBQ3JDSTtFQUNJLFNBQUE7QUR3Q1I7QUN6Q0k7RUFDSSxTQUFBO0FENENSO0FDN0NJO0VBQ0ksU0FBQTtBRGdEUjtBQ2pESTtFQUNJLFVBQUE7QURvRFI7QUNyREk7RUFDSSxVQUFBO0FEd0RSO0FDekRJO0VBQ0ksVUFBQTtBRDREUjtBQzdESTtFQUNJLFVBQUE7QURnRVI7QUNqRUk7RUFDSSxVQUFBO0FEb0VSO0FDckVJO0VBQ0ksVUFBQTtBRHdFUjtBQ3pFSTtFQUNJLFVBQUE7QUQ0RVI7QUM3RUk7RUFDSSxVQUFBO0FEZ0ZSO0FDakZJO0VBQ0ksVUFBQTtBRG9GUjtBQ3JGSTtFQUNJLFVBQUE7QUR3RlI7QUN6Rkk7RUFDSSxVQUFBO0FENEZSO0FDN0ZJO0VBQ0ksVUFBQTtBRGdHUjtBQ2pHSTtFQUNJLFVBQUE7QURvR1I7QUNyR0k7RUFDSSxVQUFBO0FEd0dSO0FDekdJO0VBQ0ksVUFBQTtBRDRHUjtBQzdHSTtFQUNJLFVBQUE7QURnSFI7QUNqSEk7RUFDSSxVQUFBO0FEb0hSO0FDckhJO0VBQ0ksVUFBQTtBRHdIUjtBQ3pISTtFQUNJLFVBQUE7QUQ0SFI7QUM3SEk7RUFDSSxVQUFBO0FEZ0lSO0FDaklJO0VBQ0ksVUFBQTtBRG9JUjtBQ3JJSTtFQUNJLFVBQUE7QUR3SVI7QUN6SUk7RUFDSSxVQUFBO0FENElSO0FDN0lJO0VBQ0ksVUFBQTtBRGdKUjtBQ2pKSTtFQUNJLFVBQUE7QURvSlI7QUNySkk7RUFDSSxVQUFBO0FEd0pSO0FDekpJO0VBQ0ksVUFBQTtBRDRKUjtBQzdKSTtFQUNJLFVBQUE7QURnS1I7QUNqS0k7RUFDSSxVQUFBO0FEb0tSO0FDcktJO0VBQ0ksVUFBQTtBRHdLUjtBQ3pLSTtFQUNJLFVBQUE7QUQ0S1I7QUM3S0k7RUFDSSxVQUFBO0FEZ0xSO0FDakxJO0VBQ0ksVUFBQTtBRG9MUjtBQ3JMSTtFQUNJLFVBQUE7QUR3TFI7QUN6TEk7RUFDSSxVQUFBO0FENExSO0FDN0xJO0VBQ0ksVUFBQTtBRGdNUjtBQ2pNSTtFQUNJLFVBQUE7QURvTVI7QUNyTUk7RUFDSSxVQUFBO0FEd01SO0FDek1JO0VBQ0ksVUFBQTtBRDRNUjtBQzdNSTtFQUNJLFVBQUE7QURnTlI7QUNqTkk7RUFDSSxVQUFBO0FEb05SO0FDck5JO0VBQ0ksVUFBQTtBRHdOUjtBQ3pOSTtFQUNJLFVBQUE7QUQ0TlI7QUM3Tkk7RUFDSSxVQUFBO0FEZ09SO0FDak9JO0VBQ0ksVUFBQTtBRG9PUjtBQ3JPSTtFQUNJLFVBQUE7QUR3T1I7QUN6T0k7RUFDSSxVQUFBO0FENE9SO0FDN09JO0VBQ0ksVUFBQTtBRGdQUjtBQ2pQSTtFQUNJLFVBQUE7QURvUFI7QUNyUEk7RUFDSSxVQUFBO0FEd1BSO0FDelBJO0VBQ0ksVUFBQTtBRDRQUjtBQzdQSTtFQUNJLFVBQUE7QURnUVI7QUNqUUk7RUFDSSxVQUFBO0FEb1FSO0FDclFJO0VBQ0ksVUFBQTtBRHdRUjtBQ3pRSTtFQUNJLFVBQUE7QUQ0UVI7QUM3UUk7RUFDSSxVQUFBO0FEZ1JSO0FDalJJO0VBQ0ksVUFBQTtBRG9SUjtBQ3JSSTtFQUNJLFVBQUE7QUR3UlI7QUN6Ukk7RUFDSSxVQUFBO0FENFJSO0FDN1JJO0VBQ0ksVUFBQTtBRGdTUjtBQ2pTSTtFQUNJLFVBQUE7QURvU1I7QUNyU0k7RUFDSSxVQUFBO0FEd1NSO0FDelNJO0VBQ0ksVUFBQTtBRDRTUjtBQzdTSTtFQUNJLFVBQUE7QURnVFI7QUNqVEk7RUFDSSxVQUFBO0FEb1RSO0FDclRJO0VBQ0ksVUFBQTtBRHdUUjtBQ3pUSTtFQUNJLFVBQUE7QUQ0VFI7QUM3VEk7RUFDSSxVQUFBO0FEZ1VSO0FDalVJO0VBQ0ksVUFBQTtBRG9VUjtBQ3JVSTtFQUNJLFVBQUE7QUR3VVI7QUN6VUk7RUFDSSxVQUFBO0FENFVSO0FDN1VJO0VBQ0ksVUFBQTtBRGdWUjtBQ2pWSTtFQUNJLFVBQUE7QURvVlI7QUNyVkk7RUFDSSxVQUFBO0FEd1ZSO0FDelZJO0VBQ0ksVUFBQTtBRDRWUjtBQzdWSTtFQUNJLFVBQUE7QURnV1I7QUNqV0k7RUFDSSxVQUFBO0FEb1dSO0FDcldJO0VBQ0ksVUFBQTtBRHdXUjtBQ3pXSTtFQUNJLFVBQUE7QUQ0V1I7QUM3V0k7RUFDSSxVQUFBO0FEZ1hSO0FDalhJO0VBQ0ksVUFBQTtBRG9YUjtBQ3JYSTtFQUNJLFVBQUE7QUR3WFI7QUN6WEk7RUFDSSxVQUFBO0FENFhSO0FDN1hJO0VBQ0ksVUFBQTtBRGdZUjtBQ2pZSTtFQUNJLFVBQUE7QURvWVI7QUNyWUk7RUFDSSxVQUFBO0FEd1lSO0FDellJO0VBQ0ksVUFBQTtBRDRZUjtBQzdZSTtFQUNJLFVBQUE7QURnWlI7QUNqWkk7RUFDSSxVQUFBO0FEb1pSO0FDclpJO0VBQ0ksVUFBQTtBRHdaUjtBQ3paSTtFQUNJLFdBQUE7QUQ0WlI7QUN0WkE7RUFDSSxVQUFBO0FEeVpKO0FDdlpBO0VBQ0ksWUFBQTtBRDBaSiIsImZpbGUiOiJzcmMvYXBwL1BhZ2VzL09wZXJhdG9yL2Nhc2gtZW50cnktaXRlbS1saXN0L2Nhc2gtZW50cnktaXRlbS1saXN0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gZGVmaW5pbmcgdGhlIGdsb2JhbCBzdHlsZXMgYW5kIGNoYW5naW5nIHZhcmlhYmxlc1xyXG5cclxuQGNoYXJzZXQgXCJ1dGYtOFwiO1xyXG5cclxuLyogbnVuaXRvLXJlZ3VsYXIgLSBsYXRpbiAqL1xyXG5AZm9udC1mYWNlIHtcclxuICBmb250LWZhbWlseTogXCJOdW5pdG9cIjtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICBzcmM6IHVybChcIi9hc3NldHMvZm9udHMvTnVuaXRvL251bml0by12MTItbGF0aW4tcmVndWxhci5lb3RcIik7XHJcbiAgc3JjOiBsb2NhbChcIk51bml0byBSZWd1bGFyXCIpLCBsb2NhbChcIk51bml0by1SZWd1bGFyXCIpLFxyXG4gICAgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi1yZWd1bGFyLmVvdD8jaWVmaXhcIikgZm9ybWF0KFwiZW1iZWRkZWQtb3BlbnR5cGVcIiksXHJcbiAgICB1cmwoXCIvYXNzZXRzL2ZvbnRzL051bml0by9udW5pdG8tdjEyLWxhdGluLXJlZ3VsYXIud29mZjJcIikgZm9ybWF0KFwid29mZjJcIiksXHJcbiAgICB1cmwoXCIvYXNzZXRzL2ZvbnRzL051bml0by9udW5pdG8tdjEyLWxhdGluLXJlZ3VsYXIud29mZlwiKSBmb3JtYXQoXCJ3b2ZmXCIpLFxyXG4gICAgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi1yZWd1bGFyLnR0ZlwiKSBmb3JtYXQoXCJ0cnVldHlwZVwiKSxcclxuICAgIHVybChcIi9hc3NldHMvZm9udHMvTnVuaXRvL251bml0by12MTItbGF0aW4tcmVndWxhci5zdmcjTnVuaXRvXCIpIGZvcm1hdChcInN2Z1wiKTtcclxufVxyXG4vKiBudW5pdG8tNzAwIC0gbGF0aW4gKi9cclxuQGZvbnQtZmFjZSB7XHJcbiAgZm9udC1mYW1pbHk6IFwiTnVuaXRvXCI7XHJcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgc3JjOiB1cmwoXCIvYXNzZXRzL2ZvbnRzL051bml0by9udW5pdG8tdjEyLWxhdGluLTcwMC5lb3RcIik7XHJcbiAgc3JjOiBsb2NhbChcIk51bml0byBCb2xkXCIpLCBsb2NhbChcIk51bml0by1Cb2xkXCIpLFxyXG4gICAgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi03MDAuZW90PyNpZWZpeFwiKSBmb3JtYXQoXCJlbWJlZGRlZC1vcGVudHlwZVwiKSxcclxuICAgIHVybChcIi9hc3NldHMvZm9udHMvTnVuaXRvL251bml0by12MTItbGF0aW4tNzAwLndvZmYyXCIpIGZvcm1hdChcIndvZmYyXCIpLFxyXG4gICAgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi03MDAud29mZlwiKSBmb3JtYXQoXCJ3b2ZmXCIpLFxyXG4gICAgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi03MDAudHRmXCIpIGZvcm1hdChcInRydWV0eXBlXCIpLFxyXG4gICAgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi03MDAuc3ZnI051bml0b1wiKSBmb3JtYXQoXCJzdmdcIik7XHJcbn1cclxuXHJcbi8qIGxhdG8tMzAwIC0gbGF0aW4gKi9cclxuQGZvbnQtZmFjZSB7XHJcbiAgZm9udC1mYW1pbHk6IFwiTGF0b1wiO1xyXG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICBmb250LXdlaWdodDogMzAwO1xyXG4gIHNyYzogdXJsKFwiL2Fzc2V0cy9mb250cy9MYXRvL2xhdG8tdjE2LWxhdGluLTMwMC5lb3RcIik7XHJcbiAgc3JjOiBsb2NhbChcIkxhdG8gTGlnaHRcIiksIGxvY2FsKFwiTGF0by1MaWdodFwiKSxcclxuICAgIHVybChcIi9hc3NldHMvZm9udHMvTGF0by9sYXRvLXYxNi1sYXRpbi0zMDAuZW90PyNpZWZpeFwiKSBmb3JtYXQoXCJlbWJlZGRlZC1vcGVudHlwZVwiKSxcclxuICAgIHVybChcIi9hc3NldHMvZm9udHMvTGF0by9sYXRvLXYxNi1sYXRpbi0zMDAud29mZjJcIikgZm9ybWF0KFwid29mZjJcIiksXHJcbiAgICB1cmwoXCIvYXNzZXRzL2ZvbnRzL0xhdG8vbGF0by12MTYtbGF0aW4tMzAwLndvZmZcIikgZm9ybWF0KFwid29mZlwiKSxcclxuICAgIHVybChcIi9hc3NldHMvZm9udHMvTGF0by9sYXRvLXYxNi1sYXRpbi0zMDAudHRmXCIpIGZvcm1hdChcInRydWV0eXBlXCIpLFxyXG4gICAgdXJsKFwiL2Fzc2V0cy9mb250cy9MYXRvL2xhdG8tdjE2LWxhdGluLTMwMC5zdmcjTGF0b1wiKSBmb3JtYXQoXCJzdmdcIik7XHJcbn1cclxuLyogbGF0by05MDAgLSBsYXRpbiAqL1xyXG5AZm9udC1mYWNlIHtcclxuICBmb250LWZhbWlseTogXCJMYXRvXCI7XHJcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gIGZvbnQtd2VpZ2h0OiA5MDA7XHJcbiAgc3JjOiB1cmwoXCIvYXNzZXRzL2ZvbnRzL0xhdG8vbGF0by12MTYtbGF0aW4tOTAwLmVvdFwiKTtcclxuICBzcmM6IGxvY2FsKFwiTGF0byBCbGFja1wiKSwgbG9jYWwoXCJMYXRvLUJsYWNrXCIpLFxyXG4gICAgdXJsKFwiL2Fzc2V0cy9mb250cy9MYXRvL2xhdG8tdjE2LWxhdGluLTkwMC5lb3Q/I2llZml4XCIpIGZvcm1hdChcImVtYmVkZGVkLW9wZW50eXBlXCIpLFxyXG4gICAgdXJsKFwiL2Fzc2V0cy9mb250cy9MYXRvL2xhdG8tdjE2LWxhdGluLTkwMC53b2ZmMlwiKSBmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuICAgIHVybChcIi9hc3NldHMvZm9udHMvTGF0by9sYXRvLXYxNi1sYXRpbi05MDAud29mZlwiKSBmb3JtYXQoXCJ3b2ZmXCIpLFxyXG4gICAgdXJsKFwiL2Fzc2V0cy9mb250cy9MYXRvL2xhdG8tdjE2LWxhdGluLTkwMC50dGZcIikgZm9ybWF0KFwidHJ1ZXR5cGVcIiksXHJcbiAgICB1cmwoXCIvYXNzZXRzL2ZvbnRzL0xhdG8vbGF0by12MTYtbGF0aW4tOTAwLnN2ZyNMYXRvXCIpIGZvcm1hdChcInN2Z1wiKTtcclxufVxyXG5cclxuLy8gU2V0IHlvdXIgYnJhbmQgY29sb3JzXHJcbiRwdXJwbGU6IHJnYigxNTksIDEwNCwgMjM1KTtcclxuJGxpZ2h0LWdyZXk6ICNmNWY1ZjU7XHJcbiRkYXJrOiByZ2IoMjIsIDI4LCA0MSk7XHJcblxyXG4kZ3JlZW46ICMwMGNjODY7XHJcbiRsaWdodC1ncmVlbjogI2JhZmFjZDtcclxuXHJcbiRyZWQ6ICNkYzM5MDA7XHJcbiRsaWdodC1yZWQ6ICNmZmU1ZTM7XHJcblxyXG4vLyBVcGRhdGUgQnVsbWEncyBnbG9iYWwgdmFyaWFibGVzXHJcbiRmYW1pbHktc2Fucy1zZXJpZjogXCJOdW5pdG9cIiwgc2Fucy1zZXJpZjtcclxuXHJcbiRwcmltYXJ5OiAkcHVycGxlO1xyXG4kbGluazogJHB1cnBsZTtcclxuXHJcbi8vIFVwZGF0ZSBzb21lIG9mIEJ1bG1hJ3MgY29tcG9uZW50IHZhcmlhYmxlc1xyXG4kYm9keS1iYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuJGNvbnRyb2wtYm9yZGVyLXdpZHRoOiAycHg7XHJcbiRpbnB1dC1ib3JkZXItY29sb3I6IHRyYW5zcGVyYW50O1xyXG4kaW5wdXQtYmFja2dyb3VuZC1jb2xvcjogJGxpZ2h0LWdyZXk7XHJcbiRpbnB1dC1zaGFkb3c6IG5vbmU7XHJcbiIsIi8qIG51bml0by1yZWd1bGFyIC0gbGF0aW4gKi9cbkBmb250LWZhY2Uge1xuICBmb250LWZhbWlseTogXCJOdW5pdG9cIjtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBmb250LXdlaWdodDogNDAwO1xuICBzcmM6IHVybChcIi9hc3NldHMvZm9udHMvTnVuaXRvL251bml0by12MTItbGF0aW4tcmVndWxhci5lb3RcIik7XG4gIHNyYzogbG9jYWwoXCJOdW5pdG8gUmVndWxhclwiKSwgbG9jYWwoXCJOdW5pdG8tUmVndWxhclwiKSwgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi1yZWd1bGFyLmVvdD8jaWVmaXhcIikgZm9ybWF0KFwiZW1iZWRkZWQtb3BlbnR5cGVcIiksIHVybChcIi9hc3NldHMvZm9udHMvTnVuaXRvL251bml0by12MTItbGF0aW4tcmVndWxhci53b2ZmMlwiKSBmb3JtYXQoXCJ3b2ZmMlwiKSwgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi1yZWd1bGFyLndvZmZcIikgZm9ybWF0KFwid29mZlwiKSwgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi1yZWd1bGFyLnR0ZlwiKSBmb3JtYXQoXCJ0cnVldHlwZVwiKSwgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi1yZWd1bGFyLnN2ZyNOdW5pdG9cIikgZm9ybWF0KFwic3ZnXCIpO1xufVxuLyogbnVuaXRvLTcwMCAtIGxhdGluICovXG5AZm9udC1mYWNlIHtcbiAgZm9udC1mYW1pbHk6IFwiTnVuaXRvXCI7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgc3JjOiB1cmwoXCIvYXNzZXRzL2ZvbnRzL051bml0by9udW5pdG8tdjEyLWxhdGluLTcwMC5lb3RcIik7XG4gIHNyYzogbG9jYWwoXCJOdW5pdG8gQm9sZFwiKSwgbG9jYWwoXCJOdW5pdG8tQm9sZFwiKSwgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi03MDAuZW90PyNpZWZpeFwiKSBmb3JtYXQoXCJlbWJlZGRlZC1vcGVudHlwZVwiKSwgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi03MDAud29mZjJcIikgZm9ybWF0KFwid29mZjJcIiksIHVybChcIi9hc3NldHMvZm9udHMvTnVuaXRvL251bml0by12MTItbGF0aW4tNzAwLndvZmZcIikgZm9ybWF0KFwid29mZlwiKSwgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi03MDAudHRmXCIpIGZvcm1hdChcInRydWV0eXBlXCIpLCB1cmwoXCIvYXNzZXRzL2ZvbnRzL051bml0by9udW5pdG8tdjEyLWxhdGluLTcwMC5zdmcjTnVuaXRvXCIpIGZvcm1hdChcInN2Z1wiKTtcbn1cbi8qIGxhdG8tMzAwIC0gbGF0aW4gKi9cbkBmb250LWZhY2Uge1xuICBmb250LWZhbWlseTogXCJMYXRvXCI7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgc3JjOiB1cmwoXCIvYXNzZXRzL2ZvbnRzL0xhdG8vbGF0by12MTYtbGF0aW4tMzAwLmVvdFwiKTtcbiAgc3JjOiBsb2NhbChcIkxhdG8gTGlnaHRcIiksIGxvY2FsKFwiTGF0by1MaWdodFwiKSwgdXJsKFwiL2Fzc2V0cy9mb250cy9MYXRvL2xhdG8tdjE2LWxhdGluLTMwMC5lb3Q/I2llZml4XCIpIGZvcm1hdChcImVtYmVkZGVkLW9wZW50eXBlXCIpLCB1cmwoXCIvYXNzZXRzL2ZvbnRzL0xhdG8vbGF0by12MTYtbGF0aW4tMzAwLndvZmYyXCIpIGZvcm1hdChcIndvZmYyXCIpLCB1cmwoXCIvYXNzZXRzL2ZvbnRzL0xhdG8vbGF0by12MTYtbGF0aW4tMzAwLndvZmZcIikgZm9ybWF0KFwid29mZlwiKSwgdXJsKFwiL2Fzc2V0cy9mb250cy9MYXRvL2xhdG8tdjE2LWxhdGluLTMwMC50dGZcIikgZm9ybWF0KFwidHJ1ZXR5cGVcIiksIHVybChcIi9hc3NldHMvZm9udHMvTGF0by9sYXRvLXYxNi1sYXRpbi0zMDAuc3ZnI0xhdG9cIikgZm9ybWF0KFwic3ZnXCIpO1xufVxuLyogbGF0by05MDAgLSBsYXRpbiAqL1xuQGZvbnQtZmFjZSB7XG4gIGZvbnQtZmFtaWx5OiBcIkxhdG9cIjtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBmb250LXdlaWdodDogOTAwO1xuICBzcmM6IHVybChcIi9hc3NldHMvZm9udHMvTGF0by9sYXRvLXYxNi1sYXRpbi05MDAuZW90XCIpO1xuICBzcmM6IGxvY2FsKFwiTGF0byBCbGFja1wiKSwgbG9jYWwoXCJMYXRvLUJsYWNrXCIpLCB1cmwoXCIvYXNzZXRzL2ZvbnRzL0xhdG8vbGF0by12MTYtbGF0aW4tOTAwLmVvdD8jaWVmaXhcIikgZm9ybWF0KFwiZW1iZWRkZWQtb3BlbnR5cGVcIiksIHVybChcIi9hc3NldHMvZm9udHMvTGF0by9sYXRvLXYxNi1sYXRpbi05MDAud29mZjJcIikgZm9ybWF0KFwid29mZjJcIiksIHVybChcIi9hc3NldHMvZm9udHMvTGF0by9sYXRvLXYxNi1sYXRpbi05MDAud29mZlwiKSBmb3JtYXQoXCJ3b2ZmXCIpLCB1cmwoXCIvYXNzZXRzL2ZvbnRzL0xhdG8vbGF0by12MTYtbGF0aW4tOTAwLnR0ZlwiKSBmb3JtYXQoXCJ0cnVldHlwZVwiKSwgdXJsKFwiL2Fzc2V0cy9mb250cy9MYXRvL2xhdG8tdjE2LWxhdGluLTkwMC5zdmcjTGF0b1wiKSBmb3JtYXQoXCJzdmdcIik7XG59XG4uYnVkZ2V0LWl0ZW1zLXNlY3Rpb24ge1xuICBkaXNwbGF5OiBmbGV4O1xuICBwYWRkaW5nOiA1cHg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLmJ1ZGdldC1pdGVtcy1zZWN0aW9uIC5idWRnZXQtaXRlbXMtY29udGFpbmVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogMTAwJTtcbn1cbi5idWRnZXQtaXRlbXMtc2VjdGlvbiAuYnVkZ2V0LWl0ZW1zLWNvbnRhaW5lciAuaW5jb21lLWNvbHVtbixcbi5idWRnZXQtaXRlbXMtc2VjdGlvbiAuYnVkZ2V0LWl0ZW1zLWNvbnRhaW5lciAuZXhwZW5zZXMtY29sdW1uIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgZmxleC1iYXNpczogMDtcbiAgZmxleC1ncm93OiAxO1xufVxuLmJ1ZGdldC1pdGVtcy1zZWN0aW9uIC5idWRnZXQtaXRlbXMtY29udGFpbmVyIC5pbmNvbWUtY29sdW1uIGgxLFxuLmJ1ZGdldC1pdGVtcy1zZWN0aW9uIC5idWRnZXQtaXRlbXMtY29udGFpbmVyIC5leHBlbnNlcy1jb2x1bW4gaDEge1xuICBmb250LWZhbWlseTogXCJMYXRvXCI7XG4gIGZvbnQtc2l6ZTogMjRweDtcbiAgZm9udC13ZWlnaHQ6IDkwMDtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbn1cbi5idWRnZXQtaXRlbXMtc2VjdGlvbiAuYnVkZ2V0LWl0ZW1zLWNvbnRhaW5lciAuaW5jb21lLWNvbHVtbiAuYnVkZ2V0LWl0ZW1zLFxuLmJ1ZGdldC1pdGVtcy1zZWN0aW9uIC5idWRnZXQtaXRlbXMtY29udGFpbmVyIC5leHBlbnNlcy1jb2x1bW4gLmJ1ZGdldC1pdGVtcyB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG4uYnVkZ2V0LWl0ZW1zLXNlY3Rpb24gLmJ1ZGdldC1pdGVtcy1jb250YWluZXIgLmluY29tZS1jb2x1bW4ge1xuICBtYXJnaW4tcmlnaHQ6IDVweDtcbn1cbi5idWRnZXQtaXRlbXMtc2VjdGlvbiAuYnVkZ2V0LWl0ZW1zLWNvbnRhaW5lciAuaW5jb21lLWNvbHVtbiAuaGVhZGVyU2VjdGlvbiB7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4uYnVkZ2V0LWl0ZW1zLXNlY3Rpb24gLmJ1ZGdldC1pdGVtcy1jb250YWluZXIgLmluY29tZS1jb2x1bW4gLmhlYWRlclNlY3Rpb24gaDEge1xuICBjb2xvcjogIzAwY2M4Njtcbn1cblxuLmJ1ZGdldC1pdGVtcyAubWF0LWVsZXZhdGlvbi16OCB7XG4gIGhlaWdodDogMzAwcHg7XG4gIG92ZXJmbG93OiBhdXRvO1xufVxuLmJ1ZGdldC1pdGVtcyAubWF0LWVsZXZhdGlvbi16OCB0YWJsZSB7XG4gIHdpZHRoOiAxMDAlO1xufVxuLmJ1ZGdldC1pdGVtcyAubWF0LWVsZXZhdGlvbi16OCB0ci5tYXQtZm9vdGVyLXJvdyB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuLmJ1ZGdldC1pdGVtcyAubWF0LWVsZXZhdGlvbi16OCAubWF0LXRhYmxlLXN0aWNreSB7XG4gIGJvcmRlci10b3A6IDFweCBzb2xpZCAjZTBlMGUwO1xufVxuXG4udy0wIHtcbiAgd2lkdGg6IDAlO1xufVxuXG4udy0xIHtcbiAgd2lkdGg6IDElO1xufVxuXG4udy0yIHtcbiAgd2lkdGg6IDIlO1xufVxuXG4udy0zIHtcbiAgd2lkdGg6IDMlO1xufVxuXG4udy00IHtcbiAgd2lkdGg6IDQlO1xufVxuXG4udy01IHtcbiAgd2lkdGg6IDUlO1xufVxuXG4udy02IHtcbiAgd2lkdGg6IDYlO1xufVxuXG4udy03IHtcbiAgd2lkdGg6IDclO1xufVxuXG4udy04IHtcbiAgd2lkdGg6IDglO1xufVxuXG4udy05IHtcbiAgd2lkdGg6IDklO1xufVxuXG4udy0xMCB7XG4gIHdpZHRoOiAxMCU7XG59XG5cbi53LTExIHtcbiAgd2lkdGg6IDExJTtcbn1cblxuLnctMTIge1xuICB3aWR0aDogMTIlO1xufVxuXG4udy0xMyB7XG4gIHdpZHRoOiAxMyU7XG59XG5cbi53LTE0IHtcbiAgd2lkdGg6IDE0JTtcbn1cblxuLnctMTUge1xuICB3aWR0aDogMTUlO1xufVxuXG4udy0xNiB7XG4gIHdpZHRoOiAxNiU7XG59XG5cbi53LTE3IHtcbiAgd2lkdGg6IDE3JTtcbn1cblxuLnctMTgge1xuICB3aWR0aDogMTglO1xufVxuXG4udy0xOSB7XG4gIHdpZHRoOiAxOSU7XG59XG5cbi53LTIwIHtcbiAgd2lkdGg6IDIwJTtcbn1cblxuLnctMjEge1xuICB3aWR0aDogMjElO1xufVxuXG4udy0yMiB7XG4gIHdpZHRoOiAyMiU7XG59XG5cbi53LTIzIHtcbiAgd2lkdGg6IDIzJTtcbn1cblxuLnctMjQge1xuICB3aWR0aDogMjQlO1xufVxuXG4udy0yNSB7XG4gIHdpZHRoOiAyNSU7XG59XG5cbi53LTI2IHtcbiAgd2lkdGg6IDI2JTtcbn1cblxuLnctMjcge1xuICB3aWR0aDogMjclO1xufVxuXG4udy0yOCB7XG4gIHdpZHRoOiAyOCU7XG59XG5cbi53LTI5IHtcbiAgd2lkdGg6IDI5JTtcbn1cblxuLnctMzAge1xuICB3aWR0aDogMzAlO1xufVxuXG4udy0zMSB7XG4gIHdpZHRoOiAzMSU7XG59XG5cbi53LTMyIHtcbiAgd2lkdGg6IDMyJTtcbn1cblxuLnctMzMge1xuICB3aWR0aDogMzMlO1xufVxuXG4udy0zNCB7XG4gIHdpZHRoOiAzNCU7XG59XG5cbi53LTM1IHtcbiAgd2lkdGg6IDM1JTtcbn1cblxuLnctMzYge1xuICB3aWR0aDogMzYlO1xufVxuXG4udy0zNyB7XG4gIHdpZHRoOiAzNyU7XG59XG5cbi53LTM4IHtcbiAgd2lkdGg6IDM4JTtcbn1cblxuLnctMzkge1xuICB3aWR0aDogMzklO1xufVxuXG4udy00MCB7XG4gIHdpZHRoOiA0MCU7XG59XG5cbi53LTQxIHtcbiAgd2lkdGg6IDQxJTtcbn1cblxuLnctNDIge1xuICB3aWR0aDogNDIlO1xufVxuXG4udy00MyB7XG4gIHdpZHRoOiA0MyU7XG59XG5cbi53LTQ0IHtcbiAgd2lkdGg6IDQ0JTtcbn1cblxuLnctNDUge1xuICB3aWR0aDogNDUlO1xufVxuXG4udy00NiB7XG4gIHdpZHRoOiA0NiU7XG59XG5cbi53LTQ3IHtcbiAgd2lkdGg6IDQ3JTtcbn1cblxuLnctNDgge1xuICB3aWR0aDogNDglO1xufVxuXG4udy00OSB7XG4gIHdpZHRoOiA0OSU7XG59XG5cbi53LTUwIHtcbiAgd2lkdGg6IDUwJTtcbn1cblxuLnctNTEge1xuICB3aWR0aDogNTElO1xufVxuXG4udy01MiB7XG4gIHdpZHRoOiA1MiU7XG59XG5cbi53LTUzIHtcbiAgd2lkdGg6IDUzJTtcbn1cblxuLnctNTQge1xuICB3aWR0aDogNTQlO1xufVxuXG4udy01NSB7XG4gIHdpZHRoOiA1NSU7XG59XG5cbi53LTU2IHtcbiAgd2lkdGg6IDU2JTtcbn1cblxuLnctNTcge1xuICB3aWR0aDogNTclO1xufVxuXG4udy01OCB7XG4gIHdpZHRoOiA1OCU7XG59XG5cbi53LTU5IHtcbiAgd2lkdGg6IDU5JTtcbn1cblxuLnctNjAge1xuICB3aWR0aDogNjAlO1xufVxuXG4udy02MSB7XG4gIHdpZHRoOiA2MSU7XG59XG5cbi53LTYyIHtcbiAgd2lkdGg6IDYyJTtcbn1cblxuLnctNjMge1xuICB3aWR0aDogNjMlO1xufVxuXG4udy02NCB7XG4gIHdpZHRoOiA2NCU7XG59XG5cbi53LTY1IHtcbiAgd2lkdGg6IDY1JTtcbn1cblxuLnctNjYge1xuICB3aWR0aDogNjYlO1xufVxuXG4udy02NyB7XG4gIHdpZHRoOiA2NyU7XG59XG5cbi53LTY4IHtcbiAgd2lkdGg6IDY4JTtcbn1cblxuLnctNjkge1xuICB3aWR0aDogNjklO1xufVxuXG4udy03MCB7XG4gIHdpZHRoOiA3MCU7XG59XG5cbi53LTcxIHtcbiAgd2lkdGg6IDcxJTtcbn1cblxuLnctNzIge1xuICB3aWR0aDogNzIlO1xufVxuXG4udy03MyB7XG4gIHdpZHRoOiA3MyU7XG59XG5cbi53LTc0IHtcbiAgd2lkdGg6IDc0JTtcbn1cblxuLnctNzUge1xuICB3aWR0aDogNzUlO1xufVxuXG4udy03NiB7XG4gIHdpZHRoOiA3NiU7XG59XG5cbi53LTc3IHtcbiAgd2lkdGg6IDc3JTtcbn1cblxuLnctNzgge1xuICB3aWR0aDogNzglO1xufVxuXG4udy03OSB7XG4gIHdpZHRoOiA3OSU7XG59XG5cbi53LTgwIHtcbiAgd2lkdGg6IDgwJTtcbn1cblxuLnctODEge1xuICB3aWR0aDogODElO1xufVxuXG4udy04MiB7XG4gIHdpZHRoOiA4MiU7XG59XG5cbi53LTgzIHtcbiAgd2lkdGg6IDgzJTtcbn1cblxuLnctODQge1xuICB3aWR0aDogODQlO1xufVxuXG4udy04NSB7XG4gIHdpZHRoOiA4NSU7XG59XG5cbi53LTg2IHtcbiAgd2lkdGg6IDg2JTtcbn1cblxuLnctODcge1xuICB3aWR0aDogODclO1xufVxuXG4udy04OCB7XG4gIHdpZHRoOiA4OCU7XG59XG5cbi53LTg5IHtcbiAgd2lkdGg6IDg5JTtcbn1cblxuLnctOTAge1xuICB3aWR0aDogOTAlO1xufVxuXG4udy05MSB7XG4gIHdpZHRoOiA5MSU7XG59XG5cbi53LTkyIHtcbiAgd2lkdGg6IDkyJTtcbn1cblxuLnctOTMge1xuICB3aWR0aDogOTMlO1xufVxuXG4udy05NCB7XG4gIHdpZHRoOiA5NCU7XG59XG5cbi53LTk1IHtcbiAgd2lkdGg6IDk1JTtcbn1cblxuLnctOTYge1xuICB3aWR0aDogOTYlO1xufVxuXG4udy05NyB7XG4gIHdpZHRoOiA5NyU7XG59XG5cbi53LTk4IHtcbiAgd2lkdGg6IDk4JTtcbn1cblxuLnctOTkge1xuICB3aWR0aDogOTklO1xufVxuXG4udy0xMDAge1xuICB3aWR0aDogMTAwJTtcbn1cblxuLnJlZCB7XG4gIGNvbG9yOiByZWQ7XG59XG5cbi5ncmVlbiB7XG4gIGNvbG9yOiBncmVlbjtcbn0iLCJAaW1wb3J0IFwiLi4vLi4vLi4vLi4vbWFpbi1zdHlsZXMuc2Nzc1wiO1xyXG5cclxuLmJ1ZGdldC1pdGVtcy1zZWN0aW9uIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBwYWRkaW5nOiA1cHg7XHJcblxyXG4gICAgLy9Ib3Jpem9udGFsbHkgYW5kIFZlcnRpY2FsbHkgY2VudGVyXHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblxyXG4gICAgLmJ1ZGdldC1pdGVtcy1jb250YWluZXIge1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG5cclxuICAgICAgICAuaW5jb21lLWNvbHVtbixcclxuICAgICAgICAuZXhwZW5zZXMtY29sdW1uIHtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgICAgICAgICAgZmxleC1iYXNpczogMDsgLy9mb3IgdGhlIGNvbHVtbnMgdG8gYmUgdGhlIHNhbWUgc2l6ZSwgcmVnYXJkbGVzcyBvZiB0aGUgY29udGVudFxyXG4gICAgICAgICAgICBmbGV4LWdyb3c6IDE7XHJcblxyXG4gICAgICAgICAgICBoMSB7XHJcbiAgICAgICAgICAgICAgICBmb250LWZhbWlseTogXCJMYXRvXCI7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDogOTAwO1xyXG4gICAgICAgICAgICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLmJ1ZGdldC1pdGVtcyB7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5pbmNvbWUtY29sdW1uIHtcclxuICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiA1cHg7XHJcblxyXG4gICAgICAgICAgICAuaGVhZGVyU2VjdGlvbiB7XHJcbiAgICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblxyXG4gICAgICAgICAgICAgICAgaDEge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAkZ3JlZW47XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbi5idWRnZXQtaXRlbXMge1xyXG4gICAgLm1hdC1lbGV2YXRpb24tejgge1xyXG4gICAgICAgIGhlaWdodDogMzAwcHg7XHJcbiAgICAgICAgb3ZlcmZsb3c6IGF1dG87XHJcblxyXG4gICAgICAgIHRhYmxlIHtcclxuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0ci5tYXQtZm9vdGVyLXJvdyB7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLm1hdC10YWJsZS1zdGlja3kge1xyXG4gICAgICAgICAgICBib3JkZXItdG9wOiAxcHggc29saWQgI2UwZTBlMDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbkBtaXhpbiBkeW53aWR0aHMoJG1heHNpemUpIHtcclxuICAgIEBmb3IgJGkgZnJvbSAwIHRocm91Z2ggJG1heHNpemUge1xyXG4gICAgICAgIEBpbmNsdWRlIHdpZHRoLWNsYXNzKCRpKTtcclxuICAgIH1cclxufVxyXG5cclxuQG1peGluIHdpZHRoLWNsYXNzKCRzaXplKSB7XHJcbiAgICAudy0jeyRzaXplfSB7XHJcbiAgICAgICAgd2lkdGg6ICRzaXplICogMSU7XHJcbiAgICB9XHJcbn1cclxuXHJcbkBpbmNsdWRlIGR5bndpZHRocygxMDApO1xyXG5cclxuLnJlZCB7XHJcbiAgICBjb2xvcjogcmVkO1xyXG59XHJcbi5ncmVlbiB7XHJcbiAgICBjb2xvcjogZ3JlZW47XHJcbn1cclxuXHJcbi8vIHRoLm1hdC1oZWFkZXItY2VsbCxcclxuLy8gdGQubWF0LWNlbGwsXHJcbi8vIHRkLm1hdC1mb290ZXItY2VsbCB7XHJcbi8vICAgICBib3JkZXI6IDAuMXB4O1xyXG4vLyAgICAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcclxuLy8gICAgIGJvcmRlci1jb2xvcjogcmdiYSgwLCAwLCAwLCAwLjEyKTtcclxuLy8gfVxyXG4iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CashEntryItemListComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-cash-entry-item-list',
                templateUrl: './cash-entry-item-list.component.html',
                styleUrls: ['./cash-entry-item-list.component.scss']
            }]
    }], function () { return [{ type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__["MatDialog"] }, { type: src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_7__["AlertService"] }]; }, { cashEntryDisplayItems: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], totalDebit: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], deleteBudgetItem: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], update: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], paginator: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
            args: [_angular_material_paginator__WEBPACK_IMPORTED_MODULE_3__["MatPaginator"], { static: false }]
        }] }); })();


/***/ }),

/***/ "./src/app/Pages/Operator/cash-entry/cash-entry.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/Pages/Operator/cash-entry/cash-entry.component.ts ***!
  \*******************************************************************/
/*! exports provided: CashEntryComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CashEntryComponent", function() { return CashEntryComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_Models__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/Models */ "./src/app/Models/index.ts");
/* harmony import */ var src_app_app_route_animation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/app-route-animation */ "./src/app/app-route-animation.ts");
/* harmony import */ var src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/Services/Alert/alert.service */ "./src/app/Services/Alert/alert.service.ts");
/* harmony import */ var src_app_Services_CashEntry_cash_entry_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/Services/CashEntry/cash-entry.service */ "./src/app/Services/CashEntry/cash-entry.service.ts");
/* harmony import */ var src_app_Services_common_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/Services/common/user.service */ "./src/app/Services/common/user.service.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var src_app_Services_common_servicetype_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/Services/common/servicetype.service */ "./src/app/Services/common/servicetype.service.ts");
/* harmony import */ var src_app_Services_common_client_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/Services/common/client.service */ "./src/app/Services/common/client.service.ts");
/* harmony import */ var _cash_entry_add_item_cash_entry_add_item_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../cash-entry-add-item/cash-entry-add-item.component */ "./src/app/Pages/Operator/cash-entry-add-item/cash-entry-add-item.component.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _cash_entry_item_list_cash_entry_item_list_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../cash-entry-item-list/cash-entry-item-list.component */ "./src/app/Pages/Operator/cash-entry-item-list/cash-entry-item-list.component.ts");













function CashEntryComponent_div_5_Template(rf, ctx) { if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "app-cash-entry-item-list", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("deleteBudgetItem", function CashEntryComponent_div_5_Template_app_cash_entry_item_list_deleteBudgetItem_1_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r3); const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r2.deleteItem($event); })("update", function CashEntryComponent_div_5_Template_app_cash_entry_item_list_update_1_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r3); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r4.update($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("totalDebit", ctx_r1.totalDebit)("cashEntryDisplayItems", ctx_r1.cashEntryDisplayItems);
} }
class CashEntryComponent {
    constructor(alertService, cashEntryService, userService, sanitizer, servicetypeService, clientService) {
        this.alertService = alertService;
        this.cashEntryService = cashEntryService;
        this.userService = userService;
        this.sanitizer = sanitizer;
        this.servicetypeService = servicetypeService;
        this.clientService = clientService;
    }
    ngOnDestroy() {
        if (this.totalDebitSubscription)
            this.totalDebitSubscription.unsubscribe();
        if (this.totalDebitSubscription)
            this.totalDebitSubscription.unsubscribe();
        if (this.getCashEntryItemsSubscription)
            this.getCashEntryItemsSubscription.unsubscribe();
        if (this.getUsersSubscription)
            this.getUsersSubscription.unsubscribe();
        if (this.getServiceTypesSubscription)
            this.getServiceTypesSubscription.unsubscribe();
        if (this.addItemSubscription)
            this.addItemSubscription.unsubscribe();
        if (this.deleteItemSubscription)
            this.deleteItemSubscription.unsubscribe();
        if (this.getClientsSubscription)
            this.getClientsSubscription.unsubscribe();
        if (this.updateSubscription)
            this.updateSubscription.unsubscribe();
    }
    ngOnInit() {
        this.getCashEntryItems();
        // this.GetUsers();
        // this.GetServiceTypes();
        // this.GetClients();
        this.calculateTotalDebit();
    }
    calculateTotalDebit() {
        this.totalDebitSubscription = this.cashEntryService.getTotalDebit()
            .subscribe(totalDebit => {
            this.totalDebit = totalDebit;
        });
    }
    getCashEntryItems() {
        this.getCashEntryItemsSubscription = this.cashEntryService.getCashEntryItems()
            .subscribe(data => {
            this.cashEntryDisplayItems = data;
        }, error => {
            this.alertService.error("An Error occurred during the Cah Entry Items fetching process");
            console.log(error);
        });
    }
    GetUsers() {
        this.getUsersSubscription = this.userService.getUsers()
            .subscribe(data => {
            this.users = data.usersFromRepo.map(item => {
                return new src_app_Models__WEBPACK_IMPORTED_MODULE_1__["User"](item.userId, item.username, "", item.firstName, item.lastName, this.sanitizer.bypassSecurityTrustUrl(`${this.userService.apiUrl}/Resources/Images/` + item.photo));
            });
        });
    }
    GetServiceTypes() {
        this.getServiceTypesSubscription = this.servicetypeService.getServiceTypes()
            .subscribe(data => {
            this.serviceTypes = data.serviceTypesFromRepo.map(item => {
                return new src_app_Models__WEBPACK_IMPORTED_MODULE_1__["ServiceType"](item.sid, item.sType, item.sTypeDesc);
            });
        });
    }
    GetClients(fetchFromServer = false) {
        this.getClientsSubscription = this.clientService.getClients(fetchFromServer)
            .subscribe(data => { this.clients = null; });
    }
    addItem(newItem) {
        newItem.sNo = 0;
        this.addItemSubscription = this.cashEntryService.createCashEntryItem(newItem)
            .subscribe(data => {
            this.alertService.success("Cash Entry has been added successfully!!");
            this.cashEntryDisplayItems = data;
            this.GetClients(true);
        }, error => {
            this.alertService.error("Unable to add new Cash Entry!");
            console.log(error);
        });
    }
    deleteItem(cashEntryItem) {
        this.deleteItemSubscription = this.cashEntryService.deleteCashEntryItem(cashEntryItem)
            .subscribe(data => {
            this.alertService.success("Cash Entry has been deleted successfully!!");
            this.cashEntryDisplayItems = data;
            this.GetClients(true);
        }, error => {
            this.alertService.error("Unable to delete new Cash Entry!");
            console.log(error);
        });
    }
    update(cashEntryUpdateBO) {
        this.updateSubscription = this.cashEntryService.updateCashEntryItem(cashEntryUpdateBO.newObject)
            .subscribe(data => {
            this.alertService.success("Cash Entry has been updated successfully!!");
            this.cashEntryDisplayItems = data;
            this.GetClients(true);
        }, error => {
            this.alertService.error("Unable to Update new Cash Entry!");
            console.log(error);
        });
    }
}
CashEntryComponent.ɵfac = function CashEntryComponent_Factory(t) { return new (t || CashEntryComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_3__["AlertService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_CashEntry_cash_entry_service__WEBPACK_IMPORTED_MODULE_4__["CashEntryService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_common_user_service__WEBPACK_IMPORTED_MODULE_5__["UserService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__["DomSanitizer"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_common_servicetype_service__WEBPACK_IMPORTED_MODULE_7__["ServicetypeService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_common_client_service__WEBPACK_IMPORTED_MODULE_8__["ClientService"])); };
CashEntryComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: CashEntryComponent, selectors: [["app-cash-entry"]], decls: 6, vars: 2, consts: [[1, "add-item-section"], [1, "add-item-container"], [1, "customComponent"], [2, "padding", "60px", 3, "clients", "formSubmit"], [2, "margin", "0px"], ["class", "customComponent", 4, "ngIf"], [3, "totalDebit", "cashEntryDisplayItems", "deleteBudgetItem", "update"]], template: function CashEntryComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "app-cash-entry-add-item", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("formSubmit", function CashEntryComponent_Template_app_cash_entry_add_item_formSubmit_3_listener($event) { return ctx.addItem($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "hr", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, CashEntryComponent_div_5_Template, 2, 2, "div", 5);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("clients", ctx.clients);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.cashEntryDisplayItems);
    } }, directives: [_cash_entry_add_item_cash_entry_add_item_component__WEBPACK_IMPORTED_MODULE_9__["CashEntryAddItemComponent"], _angular_common__WEBPACK_IMPORTED_MODULE_10__["NgIf"], _cash_entry_item_list_cash_entry_item_list_component__WEBPACK_IMPORTED_MODULE_11__["CashEntryItemListComponent"]], styles: ["@font-face {\n  font-family: \"Nunito\";\n  font-style: normal;\n  font-weight: 400;\n  src: url(\"/assets/fonts/Nunito/nunito-v12-latin-regular.eot\");\n  src: local(\"Nunito Regular\"), local(\"Nunito-Regular\"), url(\"/assets/fonts/Nunito/nunito-v12-latin-regular.eot?#iefix\") format(\"embedded-opentype\"), url(\"/assets/fonts/Nunito/nunito-v12-latin-regular.woff2\") format(\"woff2\"), url(\"/assets/fonts/Nunito/nunito-v12-latin-regular.woff\") format(\"woff\"), url(\"/assets/fonts/Nunito/nunito-v12-latin-regular.ttf\") format(\"truetype\"), url(\"/assets/fonts/Nunito/nunito-v12-latin-regular.svg#Nunito\") format(\"svg\");\n}\n\n@font-face {\n  font-family: \"Nunito\";\n  font-style: normal;\n  font-weight: 700;\n  src: url(\"/assets/fonts/Nunito/nunito-v12-latin-700.eot\");\n  src: local(\"Nunito Bold\"), local(\"Nunito-Bold\"), url(\"/assets/fonts/Nunito/nunito-v12-latin-700.eot?#iefix\") format(\"embedded-opentype\"), url(\"/assets/fonts/Nunito/nunito-v12-latin-700.woff2\") format(\"woff2\"), url(\"/assets/fonts/Nunito/nunito-v12-latin-700.woff\") format(\"woff\"), url(\"/assets/fonts/Nunito/nunito-v12-latin-700.ttf\") format(\"truetype\"), url(\"/assets/fonts/Nunito/nunito-v12-latin-700.svg#Nunito\") format(\"svg\");\n}\n\n@font-face {\n  font-family: \"Lato\";\n  font-style: normal;\n  font-weight: 300;\n  src: url(\"/assets/fonts/Lato/lato-v16-latin-300.eot\");\n  src: local(\"Lato Light\"), local(\"Lato-Light\"), url(\"/assets/fonts/Lato/lato-v16-latin-300.eot?#iefix\") format(\"embedded-opentype\"), url(\"/assets/fonts/Lato/lato-v16-latin-300.woff2\") format(\"woff2\"), url(\"/assets/fonts/Lato/lato-v16-latin-300.woff\") format(\"woff\"), url(\"/assets/fonts/Lato/lato-v16-latin-300.ttf\") format(\"truetype\"), url(\"/assets/fonts/Lato/lato-v16-latin-300.svg#Lato\") format(\"svg\");\n}\n\n@font-face {\n  font-family: \"Lato\";\n  font-style: normal;\n  font-weight: 900;\n  src: url(\"/assets/fonts/Lato/lato-v16-latin-900.eot\");\n  src: local(\"Lato Black\"), local(\"Lato-Black\"), url(\"/assets/fonts/Lato/lato-v16-latin-900.eot?#iefix\") format(\"embedded-opentype\"), url(\"/assets/fonts/Lato/lato-v16-latin-900.woff2\") format(\"woff2\"), url(\"/assets/fonts/Lato/lato-v16-latin-900.woff\") format(\"woff\"), url(\"/assets/fonts/Lato/lato-v16-latin-900.ttf\") format(\"truetype\"), url(\"/assets/fonts/Lato/lato-v16-latin-900.svg#Lato\") format(\"svg\");\n}\n.top-bar[_ngcontent-%COMP%] {\n  display: flex;\n  width: 100%;\n  height: 68px;\n  background: linear-gradient(75deg, #d6b4f7, #adcbe7);\n  justify-content: center;\n  align-items: center;\n}\n.top-bar[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n  font-family: \"Lato\";\n  font-size: 18px;\n  letter-spacing: 1px;\n  font-weight: 900;\n  text-transform: uppercase;\n  color: #161c29;\n}\n.total-budget-section[_ngcontent-%COMP%] {\n  display: flex;\n  height: 100px;\n  background: #161c29;\n  justify-content: center;\n  align-items: center;\n}\n.total-budget-section[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  font-family: \"Lato\";\n  font-weight: 300;\n  font-size: 58px;\n  color: white;\n}\n.total-budget-section[_ngcontent-%COMP%]   h2.green[_ngcontent-%COMP%] {\n  color: #0affab;\n}\n.total-budget-section[_ngcontent-%COMP%]   h2.red[_ngcontent-%COMP%] {\n  color: #ff551a;\n}\n.add-item-section[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n.add-item-section[_ngcontent-%COMP%]   .add-item-container[_ngcontent-%COMP%] {\n  width: 85%;\n}\ncustom-select[_ngcontent-%COMP%] {\n  display: block;\n  width: 500px;\n}\n.customComponent[_ngcontent-%COMP%] {\n  position: relative;\n  -webkit-animation: myAnimation 2s;\n          animation: myAnimation 2s;\n}\n@-webkit-keyframes myAnimation {\n  0% {\n    left: -100%;\n    top: 0px;\n  }\n  100% {\n    left: 0px;\n    top: 0px;\n  }\n}\n@keyframes myAnimation {\n  0% {\n    left: -100%;\n    top: 0px;\n  }\n  100% {\n    left: 0px;\n    top: 0px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUGFnZXMvT3BlcmF0b3IvY2FzaC1lbnRyeS9DOlxcRGV2ZWxvcG1lbnRcXFNhdHRpXFxGaW5hbmNlVHJhY2tlci9zcmNcXG1haW4tc3R5bGVzLnNjc3MiLCJzcmMvYXBwL1BhZ2VzL09wZXJhdG9yL2Nhc2gtZW50cnkvY2FzaC1lbnRyeS5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvUGFnZXMvT3BlcmF0b3IvY2FzaC1lbnRyeS9DOlxcRGV2ZWxvcG1lbnRcXFNhdHRpXFxGaW5hbmNlVHJhY2tlci9zcmNcXGFwcFxcUGFnZXNcXE9wZXJhdG9yXFxjYXNoLWVudHJ5XFxjYXNoLWVudHJ5LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUlBLDJCQUFBO0FBQ0E7RUFDRSxxQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSw2REFBQTtFQUNBLG9jQUFBO0FDSEY7QURVQSx1QkFBQTtBQUNBO0VBQ0UscUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EseURBQUE7RUFDQSwwYUFBQTtBQ1JGO0FEZ0JBLHFCQUFBO0FBQ0E7RUFDRSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxxREFBQTtFQUNBLGtaQUFBO0FDZEY7QURxQkEscUJBQUE7QUFDQTtFQUNFLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLHFEQUFBO0VBQ0Esa1pBQUE7QUNuQkY7QUM3QkE7RUFDSSxhQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxvREFBQTtFQUdBLHVCQUFBO0VBQ0EsbUJBQUE7QUQ2Qko7QUMzQkk7RUFDSSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EseUJBQUE7RUFDQSxjRjJDRDtBQ2RQO0FDekJBO0VBQ0ksYUFBQTtFQUNBLGFBQUE7RUFDQSxtQkZvQ0c7RUVqQ0gsdUJBQUE7RUFDQSxtQkFBQTtBRDBCSjtBQ3hCSTtFQUNJLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtBRDBCUjtBQ3hCUTtFQUNJLGNBQUE7QUQwQlo7QUN2QlE7RUFDSSxjQUFBO0FEeUJaO0FDcEJBO0VBQ0ksYUFBQTtFQUdBLHVCQUFBO0VBQ0EsbUJBQUE7QURxQko7QUNuQkk7RUFDSSxVQUFBO0FEcUJSO0FDakJBO0VBQ0ksY0FBQTtFQUNBLFlBQUE7QURvQko7QUNqQkE7RUFDSSxrQkFBQTtFQUNBLGlDQUFBO1VBQUEseUJBQUE7QURvQko7QUNqQkE7RUFDSTtJQUNJLFdBQUE7SUFDQSxRQUFBO0VEb0JOO0VDbEJFO0lBQ0ksU0FBQTtJQUNBLFFBQUE7RURvQk47QUFDRjtBQzVCQTtFQUNJO0lBQ0ksV0FBQTtJQUNBLFFBQUE7RURvQk47RUNsQkU7SUFDSSxTQUFBO0lBQ0EsUUFBQTtFRG9CTjtBQUNGIiwiZmlsZSI6InNyYy9hcHAvUGFnZXMvT3BlcmF0b3IvY2FzaC1lbnRyeS9jYXNoLWVudHJ5LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gZGVmaW5pbmcgdGhlIGdsb2JhbCBzdHlsZXMgYW5kIGNoYW5naW5nIHZhcmlhYmxlc1xyXG5cclxuQGNoYXJzZXQgXCJ1dGYtOFwiO1xyXG5cclxuLyogbnVuaXRvLXJlZ3VsYXIgLSBsYXRpbiAqL1xyXG5AZm9udC1mYWNlIHtcclxuICBmb250LWZhbWlseTogXCJOdW5pdG9cIjtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICBzcmM6IHVybChcIi9hc3NldHMvZm9udHMvTnVuaXRvL251bml0by12MTItbGF0aW4tcmVndWxhci5lb3RcIik7XHJcbiAgc3JjOiBsb2NhbChcIk51bml0byBSZWd1bGFyXCIpLCBsb2NhbChcIk51bml0by1SZWd1bGFyXCIpLFxyXG4gICAgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi1yZWd1bGFyLmVvdD8jaWVmaXhcIikgZm9ybWF0KFwiZW1iZWRkZWQtb3BlbnR5cGVcIiksXHJcbiAgICB1cmwoXCIvYXNzZXRzL2ZvbnRzL051bml0by9udW5pdG8tdjEyLWxhdGluLXJlZ3VsYXIud29mZjJcIikgZm9ybWF0KFwid29mZjJcIiksXHJcbiAgICB1cmwoXCIvYXNzZXRzL2ZvbnRzL051bml0by9udW5pdG8tdjEyLWxhdGluLXJlZ3VsYXIud29mZlwiKSBmb3JtYXQoXCJ3b2ZmXCIpLFxyXG4gICAgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi1yZWd1bGFyLnR0ZlwiKSBmb3JtYXQoXCJ0cnVldHlwZVwiKSxcclxuICAgIHVybChcIi9hc3NldHMvZm9udHMvTnVuaXRvL251bml0by12MTItbGF0aW4tcmVndWxhci5zdmcjTnVuaXRvXCIpIGZvcm1hdChcInN2Z1wiKTtcclxufVxyXG4vKiBudW5pdG8tNzAwIC0gbGF0aW4gKi9cclxuQGZvbnQtZmFjZSB7XHJcbiAgZm9udC1mYW1pbHk6IFwiTnVuaXRvXCI7XHJcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgc3JjOiB1cmwoXCIvYXNzZXRzL2ZvbnRzL051bml0by9udW5pdG8tdjEyLWxhdGluLTcwMC5lb3RcIik7XHJcbiAgc3JjOiBsb2NhbChcIk51bml0byBCb2xkXCIpLCBsb2NhbChcIk51bml0by1Cb2xkXCIpLFxyXG4gICAgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi03MDAuZW90PyNpZWZpeFwiKSBmb3JtYXQoXCJlbWJlZGRlZC1vcGVudHlwZVwiKSxcclxuICAgIHVybChcIi9hc3NldHMvZm9udHMvTnVuaXRvL251bml0by12MTItbGF0aW4tNzAwLndvZmYyXCIpIGZvcm1hdChcIndvZmYyXCIpLFxyXG4gICAgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi03MDAud29mZlwiKSBmb3JtYXQoXCJ3b2ZmXCIpLFxyXG4gICAgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi03MDAudHRmXCIpIGZvcm1hdChcInRydWV0eXBlXCIpLFxyXG4gICAgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi03MDAuc3ZnI051bml0b1wiKSBmb3JtYXQoXCJzdmdcIik7XHJcbn1cclxuXHJcbi8qIGxhdG8tMzAwIC0gbGF0aW4gKi9cclxuQGZvbnQtZmFjZSB7XHJcbiAgZm9udC1mYW1pbHk6IFwiTGF0b1wiO1xyXG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICBmb250LXdlaWdodDogMzAwO1xyXG4gIHNyYzogdXJsKFwiL2Fzc2V0cy9mb250cy9MYXRvL2xhdG8tdjE2LWxhdGluLTMwMC5lb3RcIik7XHJcbiAgc3JjOiBsb2NhbChcIkxhdG8gTGlnaHRcIiksIGxvY2FsKFwiTGF0by1MaWdodFwiKSxcclxuICAgIHVybChcIi9hc3NldHMvZm9udHMvTGF0by9sYXRvLXYxNi1sYXRpbi0zMDAuZW90PyNpZWZpeFwiKSBmb3JtYXQoXCJlbWJlZGRlZC1vcGVudHlwZVwiKSxcclxuICAgIHVybChcIi9hc3NldHMvZm9udHMvTGF0by9sYXRvLXYxNi1sYXRpbi0zMDAud29mZjJcIikgZm9ybWF0KFwid29mZjJcIiksXHJcbiAgICB1cmwoXCIvYXNzZXRzL2ZvbnRzL0xhdG8vbGF0by12MTYtbGF0aW4tMzAwLndvZmZcIikgZm9ybWF0KFwid29mZlwiKSxcclxuICAgIHVybChcIi9hc3NldHMvZm9udHMvTGF0by9sYXRvLXYxNi1sYXRpbi0zMDAudHRmXCIpIGZvcm1hdChcInRydWV0eXBlXCIpLFxyXG4gICAgdXJsKFwiL2Fzc2V0cy9mb250cy9MYXRvL2xhdG8tdjE2LWxhdGluLTMwMC5zdmcjTGF0b1wiKSBmb3JtYXQoXCJzdmdcIik7XHJcbn1cclxuLyogbGF0by05MDAgLSBsYXRpbiAqL1xyXG5AZm9udC1mYWNlIHtcclxuICBmb250LWZhbWlseTogXCJMYXRvXCI7XHJcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gIGZvbnQtd2VpZ2h0OiA5MDA7XHJcbiAgc3JjOiB1cmwoXCIvYXNzZXRzL2ZvbnRzL0xhdG8vbGF0by12MTYtbGF0aW4tOTAwLmVvdFwiKTtcclxuICBzcmM6IGxvY2FsKFwiTGF0byBCbGFja1wiKSwgbG9jYWwoXCJMYXRvLUJsYWNrXCIpLFxyXG4gICAgdXJsKFwiL2Fzc2V0cy9mb250cy9MYXRvL2xhdG8tdjE2LWxhdGluLTkwMC5lb3Q/I2llZml4XCIpIGZvcm1hdChcImVtYmVkZGVkLW9wZW50eXBlXCIpLFxyXG4gICAgdXJsKFwiL2Fzc2V0cy9mb250cy9MYXRvL2xhdG8tdjE2LWxhdGluLTkwMC53b2ZmMlwiKSBmb3JtYXQoXCJ3b2ZmMlwiKSxcclxuICAgIHVybChcIi9hc3NldHMvZm9udHMvTGF0by9sYXRvLXYxNi1sYXRpbi05MDAud29mZlwiKSBmb3JtYXQoXCJ3b2ZmXCIpLFxyXG4gICAgdXJsKFwiL2Fzc2V0cy9mb250cy9MYXRvL2xhdG8tdjE2LWxhdGluLTkwMC50dGZcIikgZm9ybWF0KFwidHJ1ZXR5cGVcIiksXHJcbiAgICB1cmwoXCIvYXNzZXRzL2ZvbnRzL0xhdG8vbGF0by12MTYtbGF0aW4tOTAwLnN2ZyNMYXRvXCIpIGZvcm1hdChcInN2Z1wiKTtcclxufVxyXG5cclxuLy8gU2V0IHlvdXIgYnJhbmQgY29sb3JzXHJcbiRwdXJwbGU6IHJnYigxNTksIDEwNCwgMjM1KTtcclxuJGxpZ2h0LWdyZXk6ICNmNWY1ZjU7XHJcbiRkYXJrOiByZ2IoMjIsIDI4LCA0MSk7XHJcblxyXG4kZ3JlZW46ICMwMGNjODY7XHJcbiRsaWdodC1ncmVlbjogI2JhZmFjZDtcclxuXHJcbiRyZWQ6ICNkYzM5MDA7XHJcbiRsaWdodC1yZWQ6ICNmZmU1ZTM7XHJcblxyXG4vLyBVcGRhdGUgQnVsbWEncyBnbG9iYWwgdmFyaWFibGVzXHJcbiRmYW1pbHktc2Fucy1zZXJpZjogXCJOdW5pdG9cIiwgc2Fucy1zZXJpZjtcclxuXHJcbiRwcmltYXJ5OiAkcHVycGxlO1xyXG4kbGluazogJHB1cnBsZTtcclxuXHJcbi8vIFVwZGF0ZSBzb21lIG9mIEJ1bG1hJ3MgY29tcG9uZW50IHZhcmlhYmxlc1xyXG4kYm9keS1iYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuJGNvbnRyb2wtYm9yZGVyLXdpZHRoOiAycHg7XHJcbiRpbnB1dC1ib3JkZXItY29sb3I6IHRyYW5zcGVyYW50O1xyXG4kaW5wdXQtYmFja2dyb3VuZC1jb2xvcjogJGxpZ2h0LWdyZXk7XHJcbiRpbnB1dC1zaGFkb3c6IG5vbmU7XHJcbiIsIi8qIG51bml0by1yZWd1bGFyIC0gbGF0aW4gKi9cbkBmb250LWZhY2Uge1xuICBmb250LWZhbWlseTogXCJOdW5pdG9cIjtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBmb250LXdlaWdodDogNDAwO1xuICBzcmM6IHVybChcIi9hc3NldHMvZm9udHMvTnVuaXRvL251bml0by12MTItbGF0aW4tcmVndWxhci5lb3RcIik7XG4gIHNyYzogbG9jYWwoXCJOdW5pdG8gUmVndWxhclwiKSwgbG9jYWwoXCJOdW5pdG8tUmVndWxhclwiKSwgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi1yZWd1bGFyLmVvdD8jaWVmaXhcIikgZm9ybWF0KFwiZW1iZWRkZWQtb3BlbnR5cGVcIiksIHVybChcIi9hc3NldHMvZm9udHMvTnVuaXRvL251bml0by12MTItbGF0aW4tcmVndWxhci53b2ZmMlwiKSBmb3JtYXQoXCJ3b2ZmMlwiKSwgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi1yZWd1bGFyLndvZmZcIikgZm9ybWF0KFwid29mZlwiKSwgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi1yZWd1bGFyLnR0ZlwiKSBmb3JtYXQoXCJ0cnVldHlwZVwiKSwgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi1yZWd1bGFyLnN2ZyNOdW5pdG9cIikgZm9ybWF0KFwic3ZnXCIpO1xufVxuLyogbnVuaXRvLTcwMCAtIGxhdGluICovXG5AZm9udC1mYWNlIHtcbiAgZm9udC1mYW1pbHk6IFwiTnVuaXRvXCI7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgc3JjOiB1cmwoXCIvYXNzZXRzL2ZvbnRzL051bml0by9udW5pdG8tdjEyLWxhdGluLTcwMC5lb3RcIik7XG4gIHNyYzogbG9jYWwoXCJOdW5pdG8gQm9sZFwiKSwgbG9jYWwoXCJOdW5pdG8tQm9sZFwiKSwgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi03MDAuZW90PyNpZWZpeFwiKSBmb3JtYXQoXCJlbWJlZGRlZC1vcGVudHlwZVwiKSwgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi03MDAud29mZjJcIikgZm9ybWF0KFwid29mZjJcIiksIHVybChcIi9hc3NldHMvZm9udHMvTnVuaXRvL251bml0by12MTItbGF0aW4tNzAwLndvZmZcIikgZm9ybWF0KFwid29mZlwiKSwgdXJsKFwiL2Fzc2V0cy9mb250cy9OdW5pdG8vbnVuaXRvLXYxMi1sYXRpbi03MDAudHRmXCIpIGZvcm1hdChcInRydWV0eXBlXCIpLCB1cmwoXCIvYXNzZXRzL2ZvbnRzL051bml0by9udW5pdG8tdjEyLWxhdGluLTcwMC5zdmcjTnVuaXRvXCIpIGZvcm1hdChcInN2Z1wiKTtcbn1cbi8qIGxhdG8tMzAwIC0gbGF0aW4gKi9cbkBmb250LWZhY2Uge1xuICBmb250LWZhbWlseTogXCJMYXRvXCI7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgc3JjOiB1cmwoXCIvYXNzZXRzL2ZvbnRzL0xhdG8vbGF0by12MTYtbGF0aW4tMzAwLmVvdFwiKTtcbiAgc3JjOiBsb2NhbChcIkxhdG8gTGlnaHRcIiksIGxvY2FsKFwiTGF0by1MaWdodFwiKSwgdXJsKFwiL2Fzc2V0cy9mb250cy9MYXRvL2xhdG8tdjE2LWxhdGluLTMwMC5lb3Q/I2llZml4XCIpIGZvcm1hdChcImVtYmVkZGVkLW9wZW50eXBlXCIpLCB1cmwoXCIvYXNzZXRzL2ZvbnRzL0xhdG8vbGF0by12MTYtbGF0aW4tMzAwLndvZmYyXCIpIGZvcm1hdChcIndvZmYyXCIpLCB1cmwoXCIvYXNzZXRzL2ZvbnRzL0xhdG8vbGF0by12MTYtbGF0aW4tMzAwLndvZmZcIikgZm9ybWF0KFwid29mZlwiKSwgdXJsKFwiL2Fzc2V0cy9mb250cy9MYXRvL2xhdG8tdjE2LWxhdGluLTMwMC50dGZcIikgZm9ybWF0KFwidHJ1ZXR5cGVcIiksIHVybChcIi9hc3NldHMvZm9udHMvTGF0by9sYXRvLXYxNi1sYXRpbi0zMDAuc3ZnI0xhdG9cIikgZm9ybWF0KFwic3ZnXCIpO1xufVxuLyogbGF0by05MDAgLSBsYXRpbiAqL1xuQGZvbnQtZmFjZSB7XG4gIGZvbnQtZmFtaWx5OiBcIkxhdG9cIjtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBmb250LXdlaWdodDogOTAwO1xuICBzcmM6IHVybChcIi9hc3NldHMvZm9udHMvTGF0by9sYXRvLXYxNi1sYXRpbi05MDAuZW90XCIpO1xuICBzcmM6IGxvY2FsKFwiTGF0byBCbGFja1wiKSwgbG9jYWwoXCJMYXRvLUJsYWNrXCIpLCB1cmwoXCIvYXNzZXRzL2ZvbnRzL0xhdG8vbGF0by12MTYtbGF0aW4tOTAwLmVvdD8jaWVmaXhcIikgZm9ybWF0KFwiZW1iZWRkZWQtb3BlbnR5cGVcIiksIHVybChcIi9hc3NldHMvZm9udHMvTGF0by9sYXRvLXYxNi1sYXRpbi05MDAud29mZjJcIikgZm9ybWF0KFwid29mZjJcIiksIHVybChcIi9hc3NldHMvZm9udHMvTGF0by9sYXRvLXYxNi1sYXRpbi05MDAud29mZlwiKSBmb3JtYXQoXCJ3b2ZmXCIpLCB1cmwoXCIvYXNzZXRzL2ZvbnRzL0xhdG8vbGF0by12MTYtbGF0aW4tOTAwLnR0ZlwiKSBmb3JtYXQoXCJ0cnVldHlwZVwiKSwgdXJsKFwiL2Fzc2V0cy9mb250cy9MYXRvL2xhdG8tdjE2LWxhdGluLTkwMC5zdmcjTGF0b1wiKSBmb3JtYXQoXCJzdmdcIik7XG59XG4udG9wLWJhciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDY4cHg7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg3NWRlZywgI2Q2YjRmNywgI2FkY2JlNyk7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLnRvcC1iYXIgaDEge1xuICBmb250LWZhbWlseTogXCJMYXRvXCI7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgZm9udC13ZWlnaHQ6IDkwMDtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgY29sb3I6ICMxNjFjMjk7XG59XG5cbi50b3RhbC1idWRnZXQtc2VjdGlvbiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGhlaWdodDogMTAwcHg7XG4gIGJhY2tncm91bmQ6ICMxNjFjMjk7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLnRvdGFsLWJ1ZGdldC1zZWN0aW9uIGgyIHtcbiAgZm9udC1mYW1pbHk6IFwiTGF0b1wiO1xuICBmb250LXdlaWdodDogMzAwO1xuICBmb250LXNpemU6IDU4cHg7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cbi50b3RhbC1idWRnZXQtc2VjdGlvbiBoMi5ncmVlbiB7XG4gIGNvbG9yOiAjMGFmZmFiO1xufVxuLnRvdGFsLWJ1ZGdldC1zZWN0aW9uIGgyLnJlZCB7XG4gIGNvbG9yOiAjZmY1NTFhO1xufVxuXG4uYWRkLWl0ZW0tc2VjdGlvbiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLmFkZC1pdGVtLXNlY3Rpb24gLmFkZC1pdGVtLWNvbnRhaW5lciB7XG4gIHdpZHRoOiA4NSU7XG59XG5cbmN1c3RvbS1zZWxlY3Qge1xuICBkaXNwbGF5OiBibG9jaztcbiAgd2lkdGg6IDUwMHB4O1xufVxuXG4uY3VzdG9tQ29tcG9uZW50IHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBhbmltYXRpb246IG15QW5pbWF0aW9uIDJzO1xufVxuXG5Aa2V5ZnJhbWVzIG15QW5pbWF0aW9uIHtcbiAgMCUge1xuICAgIGxlZnQ6IC0xMDAlO1xuICAgIHRvcDogMHB4O1xuICB9XG4gIDEwMCUge1xuICAgIGxlZnQ6IDBweDtcbiAgICB0b3A6IDBweDtcbiAgfVxufSIsIkBpbXBvcnQgXCIuLi8uLi8uLi8uLi9tYWluLXN0eWxlcy5zY3NzXCI7XHJcblxyXG4udG9wLWJhciB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDY4cHg7XHJcbiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoNzVkZWcsIHJnYigyMTQsIDE4MCwgMjQ3KSwgcmdiKDE3MywgMjAzLCAyMzEpKTtcclxuXHJcbiAgICAvL0hvcml6b250YWxseSBhbmQgVmVydGljYWxseSBjZW50ZXJcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuXHJcbiAgICBoMSB7XHJcbiAgICAgICAgZm9udC1mYW1pbHk6IFwiTGF0b1wiO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgICAgICBsZXR0ZXItc3BhY2luZzogMXB4O1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA5MDA7XHJcbiAgICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgICAgICBjb2xvcjogJGRhcms7XHJcbiAgICB9XHJcbn1cclxuXHJcbi50b3RhbC1idWRnZXQtc2VjdGlvbiB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgaGVpZ2h0OiAxMDBweDtcclxuICAgIGJhY2tncm91bmQ6ICRkYXJrO1xyXG5cclxuICAgIC8vSG9yaXpvbnRhbGx5IGFuZCBWZXJ0aWNhbGx5IGNlbnRlclxyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG5cclxuICAgIGgyIHtcclxuICAgICAgICBmb250LWZhbWlseTogXCJMYXRvXCI7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDMwMDtcclxuICAgICAgICBmb250LXNpemU6IDU4cHg7XHJcbiAgICAgICAgY29sb3I6IHdoaXRlO1xyXG5cclxuICAgICAgICAmLmdyZWVuIHtcclxuICAgICAgICAgICAgY29sb3I6IGxpZ2h0ZW4oJGdyZWVuLCAxMiUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgJi5yZWQge1xyXG4gICAgICAgICAgICBjb2xvcjogbGlnaHRlbigkcmVkLCAxMiUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLmFkZC1pdGVtLXNlY3Rpb24ge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuXHJcbiAgICAvL0hvcml6b250YWxseSBhbmQgVmVydGljYWxseSBjZW50ZXJcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuXHJcbiAgICAuYWRkLWl0ZW0tY29udGFpbmVyIHtcclxuICAgICAgICB3aWR0aDogODUlO1xyXG4gICAgfVxyXG59XHJcblxyXG5jdXN0b20tc2VsZWN0IHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgd2lkdGg6IDUwMHB4O1xyXG59XHJcblxyXG4uY3VzdG9tQ29tcG9uZW50IHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGFuaW1hdGlvbjogbXlBbmltYXRpb24gMnM7XHJcbn1cclxuXHJcbkBrZXlmcmFtZXMgbXlBbmltYXRpb24ge1xyXG4gICAgMCUge1xyXG4gICAgICAgIGxlZnQ6IC0xMDAlO1xyXG4gICAgICAgIHRvcDogMHB4O1xyXG4gICAgfVxyXG4gICAgMTAwJSB7XHJcbiAgICAgICAgbGVmdDogMHB4O1xyXG4gICAgICAgIHRvcDogMHB4O1xyXG4gICAgfVxyXG59XHJcbiJdfQ== */"], data: { animation: [src_app_app_route_animation__WEBPACK_IMPORTED_MODULE_2__["slideInAnimationForComponents"]] } });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CashEntryComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-cash-entry',
                templateUrl: './cash-entry.component.html',
                styleUrls: ['./cash-entry.component.scss'],
                animations: [src_app_app_route_animation__WEBPACK_IMPORTED_MODULE_2__["slideInAnimationForComponents"]]
            }]
    }], function () { return [{ type: src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_3__["AlertService"] }, { type: src_app_Services_CashEntry_cash_entry_service__WEBPACK_IMPORTED_MODULE_4__["CashEntryService"] }, { type: src_app_Services_common_user_service__WEBPACK_IMPORTED_MODULE_5__["UserService"] }, { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__["DomSanitizer"] }, { type: src_app_Services_common_servicetype_service__WEBPACK_IMPORTED_MODULE_7__["ServicetypeService"] }, { type: src_app_Services_common_client_service__WEBPACK_IMPORTED_MODULE_8__["ClientService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/Pages/Reports/debit-report/debit-report.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/Pages/Reports/debit-report/debit-report.component.ts ***!
  \**********************************************************************/
/*! exports provided: DebitReportComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DebitReportComponent", function() { return DebitReportComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var src_app_helpers_TableUtil__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/_helpers/TableUtil */ "./src/app/_helpers/TableUtil.ts");
/* harmony import */ var src_app_app_route_animation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/app-route-animation */ "./src/app/app-route-animation.ts");
/* harmony import */ var src_app_Services_common_client_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/Services/common/client.service */ "./src/app/Services/common/client.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _Common_loading_spinner_loading_spinner_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../Common/loading-spinner/loading-spinner.component */ "./src/app/Pages/Common/loading-spinner/loading-spinner.component.ts");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/table */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/table.js");










function DebitReportComponent_div_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " No Transaction(s) are found for this filter ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function DebitReportComponent_div_5_Template(rf, ctx) { if (rf & 1) {
    const _r54 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "button", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DebitReportComponent_div_5_Template_button_click_2_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r54); const ctx_r53 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r53.exportTable(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Export Report to Excel");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function DebitReportComponent_div_6_ng_container_3_th_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const column_r58 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r59.getDisplayCol(column_r58), " ");
} }
function DebitReportComponent_div_6_ng_container_3_td_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r62 = ctx.$implicit;
    const column_r58 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r60 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r60.getDisplayVal(element_r62[column_r58], column_r58), " ");
} }
function DebitReportComponent_div_6_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0, 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, DebitReportComponent_div_6_ng_container_3_th_1_Template, 2, 1, "th", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, DebitReportComponent_div_6_ng_container_3_td_2_Template, 2, 1, "td", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const column_r58 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matColumnDef", column_r58);
} }
function DebitReportComponent_div_6_tr_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "tr", 19);
} }
function DebitReportComponent_div_6_tr_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "tr", 20);
} }
function DebitReportComponent_div_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "table", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, DebitReportComponent_div_6_ng_container_3_Template, 3, 1, "ng-container", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, DebitReportComponent_div_6_tr_4_Template, 1, 0, "tr", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, DebitReportComponent_div_6_tr_5_Template, 1, 0, "tr", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r52 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("dataSource", ctx_r52.reportData);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r52.displayedColumns);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matHeaderRowDef", ctx_r52.columnsToDisplay);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matRowDefColumns", ctx_r52.columnsToDisplay);
} }
const moment = moment__WEBPACK_IMPORTED_MODULE_1__;
class DebitReportComponent {
    constructor(clientService, currencyPipe) {
        this.clientService = clientService;
        this.currencyPipe = currencyPipe;
        this.state = 'start';
        this.displayedColumns = ['clientName', 'phone', 'village', 'balance'];
        this.columnsToDisplay = this.displayedColumns.slice(0);
        this.columnsToDisplayName = ['CUSTOMER', 'PHONE No.', 'VILLAGE', 'DEBIT'];
    }
    ;
    ngOnInit() {
        this.generateReport();
    }
    generateReport() {
        this.reportData = null;
        this.clientService.getClients(true)
            .subscribe(data => {
            this.reportData = data.clientsFromRepo.filter(c => c.clientName != 'OTHERS');
            this.reportData.sort((leftside, rightside) => {
                if (leftside.balance > rightside.balance)
                    return -1;
                if (leftside.balance < rightside.balance)
                    return 0;
                return 0;
            });
        });
    }
    exportTable() {
        src_app_helpers_TableUtil__WEBPACK_IMPORTED_MODULE_2__["TableUtil"].exportToExcel("DebitReport");
    }
    getDisplayCol(colname) {
        var index = -1;
        for (let i = 0; i < this.displayedColumns.length; i++) {
            if (this.displayedColumns[i] == colname) {
                index = i;
                break;
            }
        }
        if (index != -1)
            return this.columnsToDisplayName[index];
        else
            return colname;
    }
    getDisplayVal(val, colname) {
        if (colname == 'balance')
            return this.currencyPipe.transform(val, "INR");
        return val;
    }
}
DebitReportComponent.ɵfac = function DebitReportComponent_Factory(t) { return new (t || DebitReportComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_common_client_service__WEBPACK_IMPORTED_MODULE_4__["ClientService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_5__["CurrencyPipe"])); };
DebitReportComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: DebitReportComponent, selectors: [["app-debit-report"]], decls: 7, vars: 5, consts: [[1, "loader-overlay", 3, "hidden"], ["class", "h3", "style", "padding-left: 50px; color: red; justify-content: center; text-align: center;", 4, "ngIf"], ["class", "row d-flex justify-content-end pr-5", 4, "ngIf"], ["class", "row", 4, "ngIf"], [1, "h3", 2, "padding-left", "50px", "color", "red", "justify-content", "center", "text-align", "center"], [1, "row", "d-flex", "justify-content-end", "pr-5"], [1, "export-container"], ["mat-raised-button", "", "color", "primary", 3, "click"], [1, "row"], [1, "col", "d-flex", "justify-content-center"], ["mat-table", "", "id", "ReportTable", 1, "mat-elevation-z8", 3, "dataSource"], [3, "matColumnDef", 4, "ngFor", "ngForOf"], ["mat-header-row", "", 4, "matHeaderRowDef"], ["mat-row", "", 4, "matRowDef", "matRowDefColumns"], [3, "matColumnDef"], ["mat-header-cell", "", "style", "font-weight: 900;", 4, "matHeaderCellDef"], ["mat-cell", "", 4, "matCellDef"], ["mat-header-cell", "", 2, "font-weight", "900"], ["mat-cell", ""], ["mat-header-row", ""], ["mat-row", ""]], template: function DebitReportComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "app-loading-spinner");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, DebitReportComponent_div_4_Template, 2, 0, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, DebitReportComponent_div_5_Template, 4, 0, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, DebitReportComponent_div_6_Template, 6, 4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", ctx.reportData);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("@ComponentAnimation", ctx.state);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.reportData && ctx.reportData.length == 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.reportData && ctx.reportData.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.reportData && ctx.reportData.length > 0);
    } }, directives: [_Common_loading_spinner_loading_spinner_component__WEBPACK_IMPORTED_MODULE_6__["LoadingSpinnerComponent"], _angular_common__WEBPACK_IMPORTED_MODULE_5__["NgIf"], _angular_material_button__WEBPACK_IMPORTED_MODULE_7__["MatButton"], _angular_material_table__WEBPACK_IMPORTED_MODULE_8__["MatTable"], _angular_common__WEBPACK_IMPORTED_MODULE_5__["NgForOf"], _angular_material_table__WEBPACK_IMPORTED_MODULE_8__["MatHeaderRowDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_8__["MatRowDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_8__["MatColumnDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_8__["MatHeaderCellDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_8__["MatCellDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_8__["MatHeaderCell"], _angular_material_table__WEBPACK_IMPORTED_MODULE_8__["MatCell"], _angular_material_table__WEBPACK_IMPORTED_MODULE_8__["MatHeaderRow"], _angular_material_table__WEBPACK_IMPORTED_MODULE_8__["MatRow"]], styles: ["table[_ngcontent-%COMP%] {\n  width: 80%;\n}\n\nbutton[_ngcontent-%COMP%] {\n  margin: 16px 8px;\n}\n\n.red[_ngcontent-%COMP%] {\n  color: red;\n}\n\n.green[_ngcontent-%COMP%] {\n  color: green;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUGFnZXMvUmVwb3J0cy9kZWJpdC1yZXBvcnQvQzpcXERldmVsb3BtZW50XFxTYXR0aVxcRmluYW5jZVRyYWNrZXIvc3JjXFxhcHBcXFBhZ2VzXFxSZXBvcnRzXFxkZWJpdC1yZXBvcnRcXGRlYml0LXJlcG9ydC5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvUGFnZXMvUmVwb3J0cy9kZWJpdC1yZXBvcnQvZGViaXQtcmVwb3J0LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksVUFBQTtBQ0NKOztBREVBO0VBQ0ksZ0JBQUE7QUNDSjs7QURFQTtFQUNJLFVBQUE7QUNDSjs7QURFQTtFQUNJLFlBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL1BhZ2VzL1JlcG9ydHMvZGViaXQtcmVwb3J0L2RlYml0LXJlcG9ydC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbInRhYmxlIHtcclxuICAgIHdpZHRoOiA4MCU7XHJcbn1cclxuXHJcbmJ1dHRvbiB7XHJcbiAgICBtYXJnaW46IDE2cHggOHB4O1xyXG59XHJcblxyXG4ucmVkIHtcclxuICAgIGNvbG9yOiByZWQ7XHJcbn1cclxuXHJcbi5ncmVlbiB7XHJcbiAgICBjb2xvcjogZ3JlZW47XHJcbn1cclxuIiwidGFibGUge1xuICB3aWR0aDogODAlO1xufVxuXG5idXR0b24ge1xuICBtYXJnaW46IDE2cHggOHB4O1xufVxuXG4ucmVkIHtcbiAgY29sb3I6IHJlZDtcbn1cblxuLmdyZWVuIHtcbiAgY29sb3I6IGdyZWVuO1xufSJdfQ== */"], data: { animation: [src_app_app_route_animation__WEBPACK_IMPORTED_MODULE_3__["slideInAnimationForComponents"]] } });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](DebitReportComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-debit-report',
                templateUrl: './debit-report.component.html',
                styleUrls: ['./debit-report.component.scss'],
                animations: [src_app_app_route_animation__WEBPACK_IMPORTED_MODULE_3__["slideInAnimationForComponents"]]
            }]
    }], function () { return [{ type: src_app_Services_common_client_service__WEBPACK_IMPORTED_MODULE_4__["ClientService"] }, { type: _angular_common__WEBPACK_IMPORTED_MODULE_5__["CurrencyPipe"] }]; }, null); })();


/***/ }),

/***/ "./src/app/Pages/Reports/general-report/general-report.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/Pages/Reports/general-report/general-report.component.ts ***!
  \**************************************************************************/
/*! exports provided: GeneralReportComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GeneralReportComponent", function() { return GeneralReportComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_Models__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/Models */ "./src/app/Models/index.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var src_app_Models_Report_report_input_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/Models/Report/report-input.model */ "./src/app/Models/Report/report-input.model.ts");
/* harmony import */ var src_app_app_route_animation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/app-route-animation */ "./src/app/app-route-animation.ts");
/* harmony import */ var _helpers_TableUtil__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../_helpers/TableUtil */ "./src/app/_helpers/TableUtil.ts");
/* harmony import */ var src_app_Services_common_client_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/Services/common/client.service */ "./src/app/Services/common/client.service.ts");
/* harmony import */ var src_app_Services_common_user_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/Services/common/user.service */ "./src/app/Services/common/user.service.ts");
/* harmony import */ var src_app_Services_common_servicetype_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/Services/common/servicetype.service */ "./src/app/Services/common/servicetype.service.ts");
/* harmony import */ var src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/Services/Alert/alert.service */ "./src/app/Services/Alert/alert.service.ts");
/* harmony import */ var src_app_Services_Report_report_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/Services/Report/report.service */ "./src/app/Services/Report/report.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _Common_loading_spinner_loading_spinner_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../Common/loading-spinner/loading-spinner.component */ "./src/app/Pages/Common/loading-spinner/loading-spinner.component.ts");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/form-field.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/input.js");
/* harmony import */ var _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/material/datepicker */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/datepicker.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");
/* harmony import */ var _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/material/autocomplete */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/autocomplete.js");
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/material/core */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/material/table */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/table.js");
/* harmony import */ var _helpers_currency_formatter_pipe__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../../../_helpers/currency-formatter.pipe */ "./src/app/_helpers/currency-formatter.pipe.ts");


























const _c0 = function (a0, a1) { return { red: a0, green: a1 }; };
function GeneralReportComponent_div_5_mat_option_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-option", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "img", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "span", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "span", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "small", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, " | ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "small", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "span", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](19, "currencyFormatter");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](20, "currency");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const client_r15 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", client_r15.clientName);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", client_r15.photo, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](client_r15.clientName);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](client_r15.village);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](client_r15.phone);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](12, _c0, client_r15.balance > 0, client_r15.balance <= 0));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Balance - ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](19, 7, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](20, 9, client_r15.balance, "INR")), "");
} }
function GeneralReportComponent_div_5_Template(rf, ctx) { if (rf & 1) {
    const _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-form-field");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "input", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("focusout", function GeneralReportComponent_div_5_Template_input_focusout_2_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r17); const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r16.focusOutValidationFunction(ctx_r16.myControl, ctx_r16.clients); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "mat-autocomplete", 19, 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("optionSelected", function GeneralReportComponent_div_5_Template_mat_autocomplete_optionSelected_3_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r17); const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r18.onSelectClient($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, GeneralReportComponent_div_5_mat_option_5_Template, 21, 15, "mat-option", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](6, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](4);
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matAutocomplete", _r13)("formControl", ctx_r5.myControl);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("displayWith", ctx_r5.displayFn)("panelWidth", 400);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](6, 5, ctx_r5.filteredOptions));
} }
function GeneralReportComponent_div_9_mat_option_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-option", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const srvType_r21 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", srvType_r21.sType);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](srvType_r21.sType + " - " + srvType_r21.sTypeDesc);
} }
function GeneralReportComponent_div_9_Template(rf, ctx) { if (rf & 1) {
    const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-form-field", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "input", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("focusout", function GeneralReportComponent_div_9_Template_input_focusout_2_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r23); const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r22.focusOutValidationFunction(ctx_r22.myServiceType, ctx_r22.serviceTypes); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "mat-autocomplete", 19, 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("optionSelected", function GeneralReportComponent_div_9_Template_mat_autocomplete_optionSelected_3_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r23); const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r24.onSelectServiceType($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, GeneralReportComponent_div_9_mat_option_5_Template, 3, 2, "mat-option", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](6, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](4);
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matAutocomplete", _r19)("formControl", ctx_r6.myServiceType);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("displayWith", ctx_r6.displayFnServiveType)("panelWidth", 400);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](6, 5, ctx_r6.filteredServiceType));
} }
function GeneralReportComponent_div_13_mat_option_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-option", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "img", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const user_r27 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", user_r27.firstName + " " + user_r27.lastName);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", user_r27.photo, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](user_r27.firstName + " " + user_r27.lastName);
} }
function GeneralReportComponent_div_13_Template(rf, ctx) { if (rf & 1) {
    const _r29 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-form-field");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "input", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("focusout", function GeneralReportComponent_div_13_Template_input_focusout_2_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r29); const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r28.focusOutValidationFunction(ctx_r28.myCompOperator, ctx_r28.users); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "mat-autocomplete", 38, 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("optionSelected", function GeneralReportComponent_div_13_Template_mat_autocomplete_optionSelected_3_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r29); const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r30.onSelectCompOperator($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, GeneralReportComponent_div_13_mat_option_5_Template, 4, 3, "mat-option", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](6, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const _r25 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](4);
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matAutocomplete", _r25)("formControl", ctx_r7.myCompOperator);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("displayWith", ctx_r7.displayFnCompOperator);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](6, 4, ctx_r7.filteredCompOperator));
} }
function GeneralReportComponent_div_45_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " No Transaction(s) are found for this filter ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function GeneralReportComponent_div_46_Template(rf, ctx) { if (rf & 1) {
    const _r32 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "button", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function GeneralReportComponent_div_46_Template_button_click_2_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r32); const ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r31.exportTable(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Export Report to Excel");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function GeneralReportComponent_div_48_th_5_span_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " CUSTOMER - ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r38.clientName);
} }
function GeneralReportComponent_div_48_th_5_span_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " & COMPUTER OPERATOR - ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r39 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", ctx_r39.CompOperatorName, " ");
} }
function GeneralReportComponent_div_48_th_5_span_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " & SERVICE TYPE - ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r40.ServiceTypeName);
} }
function GeneralReportComponent_div_48_th_5_span_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " & DATE RANGE - ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r41 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r41.dateRangeFilter);
} }
function GeneralReportComponent_div_48_th_5_span_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "For all Filters");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function GeneralReportComponent_div_48_th_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " Report Generated for - ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, GeneralReportComponent_div_48_th_5_span_2_Template, 4, 1, "span", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, GeneralReportComponent_div_48_th_5_span_3_Template, 4, 1, "span", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, GeneralReportComponent_div_48_th_5_span_4_Template, 4, 1, "span", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, GeneralReportComponent_div_48_th_5_span_5_Template, 4, 1, "span", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, GeneralReportComponent_div_48_th_5_span_6_Template, 2, 0, "span", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("colSpan", ctx_r33.displayedColumns.length);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r33.clientName);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r33.CompOperatorName);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r33.ServiceTypeName);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r33.dateRangeFilter);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r33.clientName && !ctx_r33.CompOperatorName && !ctx_r33.ServiceTypeName && !ctx_r33.dateRangeFilter);
} }
function GeneralReportComponent_div_48_tr_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "tr", 56);
} }
function GeneralReportComponent_div_48_ng_container_7_th_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const column_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r44 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r44.getDisplayCol(column_r43), " ");
} }
function GeneralReportComponent_div_48_ng_container_7_td_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const element_r47 = ctx.$implicit;
    const column_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r45 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r45.getDisplayVal(element_r47[column_r43], column_r43), " ");
} }
function GeneralReportComponent_div_48_ng_container_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0, 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, GeneralReportComponent_div_48_ng_container_7_th_1_Template, 2, 1, "th", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, GeneralReportComponent_div_48_ng_container_7_td_2_Template, 2, 1, "td", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const column_r43 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matColumnDef", column_r43);
} }
function GeneralReportComponent_div_48_tr_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "tr", 62);
} }
function GeneralReportComponent_div_48_tr_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "tr", 63);
} }
const _c1 = function () { return ["filter-description"]; };
function GeneralReportComponent_div_48_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "table", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](4, 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, GeneralReportComponent_div_48_th_5_Template, 7, 6, "th", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, GeneralReportComponent_div_48_tr_6_Template, 1, 0, "tr", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, GeneralReportComponent_div_48_ng_container_7_Template, 3, 1, "ng-container", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, GeneralReportComponent_div_48_tr_8_Template, 1, 0, "tr", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](9, GeneralReportComponent_div_48_tr_9_Template, 1, 0, "tr", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("dataSource", ctx_r12.reportData);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matHeaderRowDef", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](5, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r12.displayedColumns);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matHeaderRowDef", ctx_r12.columnsToDisplay);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("matRowDefColumns", ctx_r12.columnsToDisplay);
} }
const moment = moment__WEBPACK_IMPORTED_MODULE_4__;
class GeneralReportComponent {
    constructor(clientService, userService, servicetypeService, alertService, reportService, currencyPipe, datePipe, sanitizer) {
        this.clientService = clientService;
        this.userService = userService;
        this.servicetypeService = servicetypeService;
        this.alertService = alertService;
        this.reportService = reportService;
        this.currencyPipe = currencyPipe;
        this.datePipe = datePipe;
        this.sanitizer = sanitizer;
        this.isFirstReportGenerated = false;
        this.clients = null;
        this.myControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]();
        this.myCompOperator = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]();
        this.state = 'start';
        this.displayedColumns = ['sNo', 'compOperarator', 'description',
            'serviceType', 'client', 'amount',
            'debitAmount', 'paidAmount', 'remarks',
            'createdDate', 'cumulativeSum'];
        this.columnsToDisplay = this.displayedColumns.slice();
        this.columnsToDisplayName = ['S.No.', 'COMPUTER OPERATOR', 'DESCRIPTION', 'SERVICE TYPE', 'CLIENT', 'CREDIT',
            'DEBIT', 'PAID', 'REMARKS', 'TRANSACTION DATE', 'CUMULATIVE BALANCE'];
        this.myServiceType = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]();
    }
    ngOnInit() {
        this.GetClients();
        this.GetUsers();
        this.GetServiceTypes();
    }
    _filterCompOperator(value) {
        const filterValue = value.toLowerCase();
        return this.users.filter(user => (user.firstName + " " + user.lastName).toLowerCase().includes(filterValue));
    }
    displayFnCompOperator(user) {
        return user ? user : undefined;
    }
    GetUsers() {
        this.userService.getUsers()
            .subscribe(data => {
            this.users = data.usersFromRepo.map(item => {
                return new src_app_Models__WEBPACK_IMPORTED_MODULE_1__["User"](item.userId, item.username, "", item.firstName, item.lastName, this.sanitizer.bypassSecurityTrustUrl(`${this.clientService.apiUrl}/Resources/Images/` + item.photo));
            });
            this.filteredCompOperator = this.myCompOperator.valueChanges.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["startWith"])(''), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(user => user ? this._filterCompOperator(user) : this.users.slice()));
        });
    }
    _filterServiceType(value) {
        const filterValue = value.toLowerCase();
        return this.serviceTypes.filter(serviceType => (serviceType.sType + " - " + serviceType.sTypeDesc).toLowerCase().includes(filterValue));
    }
    displayFnServiveType(serviceType) {
        return serviceType ? serviceType : undefined;
    }
    GetServiceTypes() {
        this.servicetypeService.getServiceTypes()
            .subscribe(data => {
            this.serviceTypes = data.serviceTypesFromRepo.map(item => {
                return new src_app_Models__WEBPACK_IMPORTED_MODULE_1__["ServiceType"](item.sid, item.sType, item.sTypeDesc);
            });
            this.filteredServiceType = this.myServiceType.valueChanges.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["startWith"])(''), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(serviceType => serviceType ? this._filterServiceType(serviceType) : this.serviceTypes.slice()));
        });
    }
    displayFn(client) {
        return client ? client : undefined;
    }
    _filter(value) {
        const filterValue = value.toLowerCase();
        return this.clients.filter(client => client.clientName.toLowerCase().includes(filterValue));
    }
    GetClients() {
        this.clientService.getClients()
            .subscribe(data => {
            this.clients = data.clientsFromRepo.map(item => {
                return new src_app_Models__WEBPACK_IMPORTED_MODULE_1__["Client"](item.id, item.clientName, item.phone, item.village, this.sanitizer.bypassSecurityTrustUrl(`${this.clientService.apiUrl}/Resources/Images/` + item.photo), item.balance);
            });
            this.filteredOptions = this.myControl.valueChanges.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["startWith"])(''), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(client => client ? this._filter(client) : this.clients.slice()));
        });
    }
    onSelectClient(event) {
        this.clientId = this.clients.find(u => u.clientName == event.option.value).id;
    }
    onSelectCompOperator(event) {
        this.compOperaratorId = this.users.find(u => u.firstName + " " + u.lastName == event.option.value).userId;
    }
    onSelectServiceType(event) {
        this.serviceTypeId = this.serviceTypes.find(u => u.sType == event.option.value).sid;
    }
    generateReport() {
        this.isFirstReportGenerated = true;
        this.reportData = null;
        if (this.myControl.value == "") {
            this.clientId = null;
            this.clientName = '';
        }
        else
            this.clientName = this.myControl.value;
        if (this.myServiceType.value == "") {
            this.serviceTypeId = null;
            this.ServiceTypeName = '';
        }
        else
            this.ServiceTypeName = this.myServiceType.value;
        if (this.myCompOperator.value == "") {
            this.compOperaratorId = null;
            this.CompOperatorName = '';
        }
        else
            this.CompOperatorName = this.myCompOperator.value;
        this.dateRangeFilter = '';
        if (this.fromDate && this.toDate)
            this.dateRangeFilter = moment(new Date(this.fromDate)).format('DD-MMM-YYYY') + ' - ' + moment(new Date(this.toDate)).format('DD-MMM-YYYY');
        this.displayedColumns =
            ['sNo', 'compOperarator', 'description',
                'serviceType', 'client', 'amount',
                'debitAmount', 'paidAmount', 'remarks',
                'createdDate', 'cumulativeSum'];
        this.columnsToDisplay = this.displayedColumns.slice();
        this.columnsToDisplayName = ['S.No.', 'COMPUTER OPERATOR', 'DESCRIPTION', 'SERVICE TYPE', 'CLIENT', 'CREDIT',
            'DEBIT', 'PAID', 'REMARKS', 'TRANSACTION DATE', 'CUMULATIVE BALANCE'];
        if (this.clientId) {
            this.displayedColumns.splice(this.displayedColumns.indexOf('client'), 1);
            this.columnsToDisplay.splice(this.columnsToDisplay.indexOf('client'), 1);
            this.columnsToDisplayName.splice(this.columnsToDisplayName.indexOf('CLIENT'), 1);
        }
        if (this.compOperaratorId) {
            this.displayedColumns.splice(this.displayedColumns.indexOf('compOperarator'), 1);
            this.columnsToDisplay.splice(this.columnsToDisplay.indexOf('compOperarator'), 1);
            this.columnsToDisplayName.splice(this.columnsToDisplayName.indexOf('COMPUTER OPERATOR'), 1);
        }
        if (this.serviceTypeId) {
            this.displayedColumns.splice(this.displayedColumns.indexOf('serviceType'), 1);
            this.columnsToDisplay.splice(this.columnsToDisplay.indexOf('serviceType'), 1);
            this.columnsToDisplayName.splice(this.columnsToDisplayName.indexOf('SERVICE TYPE'), 1);
        }
        var reportInput = new src_app_Models_Report_report_input_model__WEBPACK_IMPORTED_MODULE_5__["ReportInput"](this.clientId ? this.clientId : 0, this.compOperaratorId ? this.compOperaratorId : 0, this.serviceTypeId ? this.serviceTypeId : 0, this.fromDate ? moment(new Date(this.fromDate)).format('MM/DD/YYYY') : null, this.toDate ? moment(new Date(this.toDate)).format('MM/DD/YYYY') : null);
        this.reportService.generateReport(reportInput)
            .subscribe(data => {
            this.reportData = data;
            this.reportData.forEach(c => {
                c.createdDate = moment(new Date(c.createdDate)).format('DD-MMM-YYYY');
            });
        });
    }
    clearFilters() {
        this.isFirstReportGenerated = false;
        this.reportData = null;
        this.myControl.setValue("");
        this.myServiceType.setValue("");
        this.myCompOperator.setValue("");
        this.fromDate = null;
        this.toDate = null;
    }
    focusOutValidationFunction(ctrl, dataArray) {
        if (ctrl.value && ctrl.value != "")
            if (dataArray === this.users) {
                if (dataArray.filter(user => (user.firstName + " " + user.lastName).toLowerCase() === ctrl.value.toLowerCase()).length == 0) {
                    ctrl.setValue("");
                    this.compOperaratorId = null;
                }
            }
            else if (dataArray == this.serviceTypes) {
                if (dataArray.filter(serviceType => serviceType.sType.toLowerCase() === ctrl.value.toLowerCase()).length == 0) {
                    ctrl.setValue("");
                    this.serviceTypeId = null;
                }
            }
            else if (dataArray == this.clients) {
                if (dataArray.filter(client => client.clientName.toLowerCase() === ctrl.value.toLowerCase()).length == 0) {
                    ctrl.setValue("");
                    this.clientId = null;
                }
            }
    }
    exportTable() {
        _helpers_TableUtil__WEBPACK_IMPORTED_MODULE_7__["TableUtil"].exportToExcel("ReportTable");
    }
    getDisplayCol(colname) {
        var index = -1;
        for (let i = 0; i < this.displayedColumns.length; i++) {
            if (this.displayedColumns[i] == colname) {
                index = i;
                break;
            }
        }
        if (index != -1)
            return this.columnsToDisplayName[index];
        else
            return colname;
    }
    getDisplayVal(val, colname) {
        if (colname == 'amount' || colname == 'debitAmount' || colname == 'paidAmount' || colname == 'cumulativeSum')
            return this.currencyPipe.transform(val, "INR");
        if (colname == 'createdDate')
            return this.datePipe.transform(val, 'd-MMM-yyyy');
        return val;
    }
}
GeneralReportComponent.ɵfac = function GeneralReportComponent_Factory(t) { return new (t || GeneralReportComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_common_client_service__WEBPACK_IMPORTED_MODULE_8__["ClientService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_common_user_service__WEBPACK_IMPORTED_MODULE_9__["UserService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_common_servicetype_service__WEBPACK_IMPORTED_MODULE_10__["ServicetypeService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_11__["AlertService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_Report_report_service__WEBPACK_IMPORTED_MODULE_12__["ReportService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_13__["CurrencyPipe"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_13__["DatePipe"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_14__["DomSanitizer"])); };
GeneralReportComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: GeneralReportComponent, selectors: [["app-general-report"]], decls: 49, vars: 33, consts: [[1, "container"], [1, "row"], [1, "col", "loader-overlay", 3, "hidden"], [3, "diameter"], ["class", "col d-flex justify-content-center", 4, "ngIf"], [1, "col", "d-flex", "justify-content-center"], ["matInput", "", 3, "value"], ["matInput", "", "disabled", "", 3, "hidden", "matDatepicker", "ngModel", "ngModelChange"], ["matSuffix", "", 3, "for"], ["disabled", "false"], ["picker", ""], ["picker1", ""], ["mat-raised-button", "", "color", "primary", 3, "click"], [1, "loader-overlay", 3, "hidden"], ["class", "h3", "style", "padding-left: 50px; color: red; justify-content: center; text-align: center;", 4, "ngIf"], ["class", "row d-flex justify-content-end pr-5", 4, "ngIf"], [1, "m-2"], ["id", "divReport", 4, "ngIf"], ["type", "text", "name", "dropdownReportClient", "id", "dropdownReportClient", "matInput", "", "placeholder", "CUSTOMER", 3, "matAutocomplete", "formControl", "focusout"], [3, "displayWith", "panelWidth", "optionSelected"], ["auto", "matAutocomplete"], ["style", "margin-top: 10px;", 3, "value", 4, "ngFor", "ngForOf"], [2, "margin-top", "10px", 3, "value"], [1, "row", 2, "height", "50px"], [1, "col-3"], ["aria-hidden", "", "height", "50", "width", "50", 1, "example-option-img", "rounded-circle", 3, "src"], [1, "col", 2, "line-height", "15px"], [2, "font-family", "Lato", "text-transform", "uppercase", "color", "#00cc86", "font-weight", "bold"], [2, "font-size", "15px"], [1, "cssClientVillage", 2, "font-weight", "bold", "font-style", "italic"], [1, "cssClientPhone", 2, "font-weight", "bold", "font-style", "italic"], [2, "font-size", "13px", 3, "ngClass"], [1, "full-width-field"], ["type", "text", "name", "dropdownReportServiceType", "id", "dropdownReportServiceType", "matInput", "", "placeholder", "SERVICE TYPE", 3, "matAutocomplete", "formControl", "focusout"], ["ddlServiceType", "matAutocomplete"], ["style", "margin-top: 2px;", 3, "value", 4, "ngFor", "ngForOf"], [2, "margin-top", "2px", 3, "value"], ["type", "text", "name", "dropdownReportCompOperator", "id", "dropdownReportCompOperator", "matInput", "", "placeholder", "COMPUTER OPERATOR", 3, "matAutocomplete", "formControl", "focusout"], [3, "displayWith", "optionSelected"], ["ddlCO", "matAutocomplete"], [1, "h3", 2, "padding-left", "50px", "color", "red", "justify-content", "center", "text-align", "center"], [1, "row", "d-flex", "justify-content-end", "pr-5"], [1, "export-container"], ["id", "divReport"], [1, "col"], ["mat-table", "", "id", "ReportTable", 1, "mat-elevation-z8", 3, "dataSource"], ["matColumnDef", "filter-description"], ["mat-header-cell", "", 3, "colSpan", 4, "matHeaderCellDef"], ["mat-header-row", "", "class", "example-second-header-row", 4, "matHeaderRowDef"], [3, "matColumnDef", 4, "ngFor", "ngForOf"], ["mat-header-row", "", 4, "matHeaderRowDef"], ["mat-row", "", 4, "matRowDef", "matRowDefColumns"], ["mat-header-cell", "", 3, "colSpan"], [4, "ngIf"], ["class", "textStyled", 4, "ngIf"], [1, "textStyled"], ["mat-header-row", "", 1, "example-second-header-row"], [3, "matColumnDef"], ["mat-header-cell", "", 4, "matHeaderCellDef"], ["mat-cell", "", 4, "matCellDef"], ["mat-header-cell", ""], ["mat-cell", ""], ["mat-header-row", ""], ["mat-row", ""]], template: function GeneralReportComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "app-loading-spinner", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, GeneralReportComponent_div_5_Template, 7, 7, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "app-loading-spinner", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](9, GeneralReportComponent_div_9_Template, 7, 7, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](12, "app-loading-spinner", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](13, GeneralReportComponent_div_13_Template, 7, 6, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "mat-form-field");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "FROM DATE");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](19, "input", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](20, "date");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "input", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function GeneralReportComponent_Template_input_ngModelChange_21_listener($event) { return ctx.fromDate = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](22, "mat-datepicker-toggle", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](23, "mat-datepicker", 9, 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "mat-form-field");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](28, "TO DATE");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](29, "input", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](30, "date");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "input", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function GeneralReportComponent_Template_input_ngModelChange_31_listener($event) { return ctx.toDate = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](32, "mat-datepicker-toggle", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](33, "mat-datepicker", 9, 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function GeneralReportComponent_Template_button_click_36_listener() { return ctx.generateReport(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](37, "Generate Report");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function GeneralReportComponent_Template_button_click_39_listener() { return ctx.clearFilters(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](40, "Clear Filters");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](44, "app-loading-spinner");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](45, GeneralReportComponent_div_45_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](46, GeneralReportComponent_div_46_Template, 4, 0, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](47, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](48, GeneralReportComponent_div_48_Template, 10, 6, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](24);
        const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](34);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", ctx.clients);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("diameter", 30)("@ComponentAnimation", ctx.state);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.clients);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", ctx.serviceTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("diameter", 30)("@ComponentAnimation", ctx.state);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.serviceTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", ctx.users);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("diameter", 30)("@ComponentAnimation", ctx.state);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.users);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](20, 27, ctx.fromDate, "d/M/yyyy"));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", true)("matDatepicker", _r8)("ngModel", ctx.fromDate);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("for", _r8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](30, 30, ctx.toDate, "d/M/yyyy"));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", true)("matDatepicker", _r9)("ngModel", ctx.toDate);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("for", _r9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", ctx.reportData || !ctx.isFirstReportGenerated);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("@ComponentAnimation", ctx.state);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.reportData && ctx.reportData.length == 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.reportData && ctx.reportData.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.reportData && ctx.reportData.length > 0);
    } }, directives: [_Common_loading_spinner_loading_spinner_component__WEBPACK_IMPORTED_MODULE_15__["LoadingSpinnerComponent"], _angular_common__WEBPACK_IMPORTED_MODULE_13__["NgIf"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_16__["MatFormField"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_16__["MatLabel"], _angular_material_input__WEBPACK_IMPORTED_MODULE_17__["MatInput"], _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_18__["MatDatepickerInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgModel"], _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_18__["MatDatepickerToggle"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_16__["MatSuffix"], _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_18__["MatDatepicker"], _angular_material_button__WEBPACK_IMPORTED_MODULE_19__["MatButton"], _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_20__["MatAutocompleteTrigger"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControlDirective"], _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_20__["MatAutocomplete"], _angular_common__WEBPACK_IMPORTED_MODULE_13__["NgForOf"], _angular_material_core__WEBPACK_IMPORTED_MODULE_21__["MatOption"], _angular_common__WEBPACK_IMPORTED_MODULE_13__["NgClass"], _angular_material_table__WEBPACK_IMPORTED_MODULE_22__["MatTable"], _angular_material_table__WEBPACK_IMPORTED_MODULE_22__["MatColumnDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_22__["MatHeaderCellDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_22__["MatHeaderRowDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_22__["MatRowDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_22__["MatHeaderCell"], _angular_material_table__WEBPACK_IMPORTED_MODULE_22__["MatHeaderRow"], _angular_material_table__WEBPACK_IMPORTED_MODULE_22__["MatCellDef"], _angular_material_table__WEBPACK_IMPORTED_MODULE_22__["MatCell"], _angular_material_table__WEBPACK_IMPORTED_MODULE_22__["MatRow"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_13__["DatePipe"], _angular_common__WEBPACK_IMPORTED_MODULE_13__["AsyncPipe"], _helpers_currency_formatter_pipe__WEBPACK_IMPORTED_MODULE_23__["CurrencyFormatterPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_13__["CurrencyPipe"]], styles: ["table[_ngcontent-%COMP%] {\n  width: 100%;\n}\n\nbutton[_ngcontent-%COMP%] {\n  margin: 16px 8px;\n}\n\n.red[_ngcontent-%COMP%] {\n  color: red;\n}\n\n.green[_ngcontent-%COMP%] {\n  color: green;\n}\n\n.textStyled[_ngcontent-%COMP%] {\n  font-weight: 900;\n  font-style: italic;\n  color: red;\n  text-align: center;\n}\n\nth.mat-header-cell[_ngcontent-%COMP%], td.mat-cell[_ngcontent-%COMP%] {\n  padding: 10px;\n  border: 1px dotted lavender;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUGFnZXMvUmVwb3J0cy9nZW5lcmFsLXJlcG9ydC9DOlxcRGV2ZWxvcG1lbnRcXFNhdHRpXFxGaW5hbmNlVHJhY2tlci9zcmNcXGFwcFxcUGFnZXNcXFJlcG9ydHNcXGdlbmVyYWwtcmVwb3J0XFxnZW5lcmFsLXJlcG9ydC5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvUGFnZXMvUmVwb3J0cy9nZW5lcmFsLXJlcG9ydC9nZW5lcmFsLXJlcG9ydC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQUE7QUNDRjs7QURFQTtFQUNFLGdCQUFBO0FDQ0Y7O0FERUE7RUFDRSxVQUFBO0FDQ0Y7O0FERUE7RUFDRSxZQUFBO0FDQ0Y7O0FERUE7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0FDQ0Y7O0FERUE7O0VBRUUsYUFBQTtFQUNBLDJCQUFBO0FDQ0YiLCJmaWxlIjoic3JjL2FwcC9QYWdlcy9SZXBvcnRzL2dlbmVyYWwtcmVwb3J0L2dlbmVyYWwtcmVwb3J0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsidGFibGUge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG5idXR0b24ge1xyXG4gIG1hcmdpbjogMTZweCA4cHg7XHJcbn1cclxuXHJcbi5yZWQge1xyXG4gIGNvbG9yOiByZWQ7XHJcbn1cclxuXHJcbi5ncmVlbiB7XHJcbiAgY29sb3I6IGdyZWVuO1xyXG59XHJcblxyXG4udGV4dFN0eWxlZCB7XHJcbiAgZm9udC13ZWlnaHQ6IDkwMDtcclxuICBmb250LXN0eWxlOiBpdGFsaWM7XHJcbiAgY29sb3I6IHJlZDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbnRoLm1hdC1oZWFkZXItY2VsbCxcclxudGQubWF0LWNlbGwge1xyXG4gIHBhZGRpbmc6IDEwcHg7XHJcbiAgYm9yZGVyOiAxcHggZG90dGVkIGxhdmVuZGVyO1xyXG59XHJcbiIsInRhYmxlIHtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbmJ1dHRvbiB7XG4gIG1hcmdpbjogMTZweCA4cHg7XG59XG5cbi5yZWQge1xuICBjb2xvcjogcmVkO1xufVxuXG4uZ3JlZW4ge1xuICBjb2xvcjogZ3JlZW47XG59XG5cbi50ZXh0U3R5bGVkIHtcbiAgZm9udC13ZWlnaHQ6IDkwMDtcbiAgZm9udC1zdHlsZTogaXRhbGljO1xuICBjb2xvcjogcmVkO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbnRoLm1hdC1oZWFkZXItY2VsbCxcbnRkLm1hdC1jZWxsIHtcbiAgcGFkZGluZzogMTBweDtcbiAgYm9yZGVyOiAxcHggZG90dGVkIGxhdmVuZGVyO1xufSJdfQ== */"], data: { animation: [src_app_app_route_animation__WEBPACK_IMPORTED_MODULE_6__["slideInAnimationForComponents"]] } });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](GeneralReportComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-general-report',
                templateUrl: './general-report.component.html',
                styleUrls: ['./general-report.component.scss'],
                animations: [src_app_app_route_animation__WEBPACK_IMPORTED_MODULE_6__["slideInAnimationForComponents"]]
            }]
    }], function () { return [{ type: src_app_Services_common_client_service__WEBPACK_IMPORTED_MODULE_8__["ClientService"] }, { type: src_app_Services_common_user_service__WEBPACK_IMPORTED_MODULE_9__["UserService"] }, { type: src_app_Services_common_servicetype_service__WEBPACK_IMPORTED_MODULE_10__["ServicetypeService"] }, { type: src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_11__["AlertService"] }, { type: src_app_Services_Report_report_service__WEBPACK_IMPORTED_MODULE_12__["ReportService"] }, { type: _angular_common__WEBPACK_IMPORTED_MODULE_13__["CurrencyPipe"] }, { type: _angular_common__WEBPACK_IMPORTED_MODULE_13__["DatePipe"] }, { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_14__["DomSanitizer"] }]; }, null); })();


/***/ }),

/***/ "./src/app/Services/Alert/alert.service.ts":
/*!*************************************************!*\
  !*** ./src/app/Services/Alert/alert.service.ts ***!
  \*************************************************/
/*! exports provided: AlertService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AlertService", function() { return AlertService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");





class AlertService {
    constructor(router) {
        this.router = router;
        this.subject = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
        this.keepAfterRouteChange = false;
        this.showTime = 3000;
    }
    ngOnInit() {
        this.router.events.subscribe(event => {
            if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_2__["NavigationStart"]) {
                if (this.keepAfterRouteChange) {
                    this.keepAfterRouteChange = false;
                }
                else {
                    this.clear();
                }
            }
        });
    }
    getAlert() {
        return this.subject.asObservable();
    }
    success(message, keepAfterRouteChange = false, showTime = this.showTime) {
        this.keepAfterRouteChange = keepAfterRouteChange;
        this.subject.next({ type: 'success', text: message, showTime: showTime });
    }
    error(message, keepAfterRouteChange = false, showTime = this.showTime) {
        this.keepAfterRouteChange = keepAfterRouteChange;
        this.subject.next({ type: 'error', text: message, showTime: showTime });
    }
    info(message, keepAfterRouteChange = false, showTime = this.showTime) {
        this.keepAfterRouteChange = keepAfterRouteChange;
        this.subject.next({ type: 'info', text: message, showTime: showTime });
    }
    clear() {
        this.subject.next();
    }
}
AlertService.ɵfac = function AlertService_Factory(t) { return new (t || AlertService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"])); };
AlertService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: AlertService, factory: AlertService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AlertService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }]; }, null); })();


/***/ }),

/***/ "./src/app/Services/Auth/authentication.service.ts":
/*!*********************************************************!*\
  !*** ./src/app/Services/Auth/authentication.service.ts ***!
  \*********************************************************/
/*! exports provided: AuthenticationService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthenticationService", function() { return AuthenticationService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _servicesConfig__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../servicesConfig */ "./src/app/Services/servicesConfig.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");







class AuthenticationService {
    constructor(http) {
        this.http = http;
        this.apiUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].apiUrl;
        this.subjectUserObject = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
    }
    sendUserObject(userObject) {
        this.subjectUserObject.next(userObject);
    }
    clearUserObject() {
        this.subjectUserObject.next();
    }
    getUserObject() {
        return this.subjectUserObject.asObservable();
    }
    get currentUserObject() {
        if (this._currentUserObject == null) {
            this._currentUserObject = JSON.parse(localStorage.getItem("LoggedInUser"));
        }
        return this._currentUserObject;
    }
    set currentUserObject(v) {
        this._currentUserObject = v;
    }
    get userToken() {
        if (this.isNullOrEmpty(this._userToken)) {
            this._userToken = JSON.parse(localStorage.getItem("LoggedInUser"));
        }
        return this._userToken;
    }
    set userToken(v) {
        this._userToken = v;
    }
    login(model) {
        return this.http.post(`${this.apiUrl}/Auth/Login`, model, _servicesConfig__WEBPACK_IMPORTED_MODULE_4__["httpOptions"])
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((response) => {
            const user = response;
            if (user) {
                localStorage.setItem('currentUserToken', user.tokenString);
                localStorage.setItem('LoggedInUser', JSON.stringify(user.userFromRepo));
                this.sendUserObject(this.currentUserObject);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["catchError"])(this.handleError));
    }
    handleError(error) {
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["throwError"])(error);
    }
    register(model) {
        return this.http.post(`${this.apiUrl}/Auth/register`, model, _servicesConfig__WEBPACK_IMPORTED_MODULE_4__["httpOptions"]);
    }
    isNullOrEmpty(value) {
        return value == null || value === "";
    }
    logout() {
        this.currentUserObject = null;
        localStorage.removeItem('LoggedInUser');
        this.userToken = "";
        localStorage.removeItem('currentUserToken');
    }
}
AuthenticationService.ɵfac = function AuthenticationService_Factory(t) { return new (t || AuthenticationService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"])); };
AuthenticationService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: AuthenticationService, factory: AuthenticationService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AuthenticationService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"] }]; }, null); })();


/***/ }),

/***/ "./src/app/Services/CashEntry/cash-entry.service.ts":
/*!**********************************************************!*\
  !*** ./src/app/Services/CashEntry/cash-entry.service.ts ***!
  \**********************************************************/
/*! exports provided: CashEntryService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CashEntryService", function() { return CashEntryService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var _servicesConfig__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../servicesConfig */ "./src/app/Services/servicesConfig.ts");








class CashEntryService {
    constructor(http) {
        this.http = http;
        this.apiUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl;
        this.subject = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"]();
    }
    getTotalDebit() {
        return this.subject.asObservable();
    }
    createCashEntryItem(cashEntryItem) {
        const fd = new FormData();
        fd.append("cashEntryJSON", JSON.stringify(cashEntryItem));
        const req = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpRequest"]('POST', `${this.apiUrl}/CashEntry/create`, fd, {
            // headers: headers,
            reportProgress: true
        });
        return this.http.request(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(event => {
            switch (event.type) {
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpEventType"].UploadProgress:
                    break;
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpEventType"].Response:
                    {
                        this.totalDebit = event.body.cashEntryResult.result.Key;
                        this.subject.next({ totalDebit: this.totalDebit });
                        return event.body.cashEntryResult.result.Value;
                    }
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(message => { }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["last"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])((error) => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(`Client has not been created`);
        }));
    }
    getCashEntryItems() {
        return this.http.get(`${this.apiUrl}/CashEntry/getcashentries`, _servicesConfig__WEBPACK_IMPORTED_MODULE_5__["httpOptions"])
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])((response) => {
            this.totalDebit = response.totalDebit;
            this.subject.next({ totalDebit: this.totalDebit });
            return response.cashEntriesFromRepo;
        }));
    }
    updateCashEntryItem(cashEntryItem) {
        const fd = new FormData();
        fd.append("cashEntryJSON", JSON.stringify(cashEntryItem));
        const req = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpRequest"]('POST', `${this.apiUrl}/CashEntry/update`, fd, {
            // headers: headers,
            reportProgress: true
        });
        return this.http.request(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(event => {
            switch (event.type) {
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpEventType"].UploadProgress:
                    break;
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpEventType"].Response:
                    {
                        this.totalDebit = event.body.cashEntryResult.result.Key;
                        this.subject.next({ totalDebit: this.totalDebit });
                        return event.body.cashEntryResult.result.Value;
                    }
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(message => { }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["last"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])((error) => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(`Client has not been created`);
        }));
    }
    deleteCashEntryItem(cashEntryItem) {
        const fd = new FormData();
        fd.append("cashEntryJSON", JSON.stringify(cashEntryItem));
        const req = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpRequest"]('POST', `${this.apiUrl}/CashEntry/delete`, fd, {
            // headers: headers,
            reportProgress: true
        });
        return this.http.request(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(event => {
            switch (event.type) {
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpEventType"].UploadProgress:
                    break;
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpEventType"].Response:
                    {
                        this.totalDebit = event.body.cashEntryResult.result.Key;
                        this.subject.next({ totalDebit: this.totalDebit });
                        return event.body.cashEntryResult.result.Value;
                    }
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(message => { }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["last"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])((error) => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(`Client has not been created`);
        }));
    }
}
CashEntryService.ɵfac = function CashEntryService_Factory(t) { return new (t || CashEntryService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"])); };
CashEntryService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: CashEntryService, factory: CashEntryService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CashEntryService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }]; }, null); })();


/***/ }),

/***/ "./src/app/Services/Report/report.service.ts":
/*!***************************************************!*\
  !*** ./src/app/Services/Report/report.service.ts ***!
  \***************************************************/
/*! exports provided: ReportService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReportService", function() { return ReportService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");







class ReportService {
    constructor(http) {
        this.http = http;
        this.apiUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].apiUrl;
    }
    generateReport(reportInput) {
        debugger;
        const fd = new FormData();
        fd.append("reportInputJSON", JSON.stringify(reportInput));
        const req = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpRequest"]('POST', `${this.apiUrl}/Report/GenerateReport`, fd, {
            // headers: headers,
            reportProgress: true
        });
        return this.http.request(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(event => {
            switch (event.type) {
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpEventType"].UploadProgress:
                    break;
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpEventType"].Response:
                    {
                        return event.body.report;
                    }
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(message => { }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["last"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])((error) => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(`There is a problem during the report Generation`);
        }));
    }
    getEventMessage(event) {
        switch (event.type) {
            case _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpEventType"].Sent:
                return ``;
            case _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpEventType"].UploadProgress:
                return `File `;
            case _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpEventType"].Response:
                return event.body.reportData.result.Value;
            default:
                return `File `;
        }
    }
    showProgress(message) {
        console.log(message);
    }
    handleError(err) {
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(err);
    }
}
ReportService.ɵfac = function ReportService_Factory(t) { return new (t || ReportService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"])); };
ReportService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: ReportService, factory: ReportService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ReportService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }]; }, null); })();


/***/ }),

/***/ "./src/app/Services/common/client.service.ts":
/*!***************************************************!*\
  !*** ./src/app/Services/common/client.service.ts ***!
  \***************************************************/
/*! exports provided: ClientService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientService", function() { return ClientService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _servicesConfig__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../servicesConfig */ "./src/app/Services/servicesConfig.ts");
/* harmony import */ var _Alert_alert_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Alert/alert.service */ "./src/app/Services/Alert/alert.service.ts");









class ClientService {
    constructor(http, alertService) {
        this.http = http;
        this.alertService = alertService;
        this.apiUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].apiUrl;
        this.dropdownText = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
    }
    getClients(fetchFromServer = false) {
        var currentTime = new Date();
        if (this.lastFetchedFromServer) {
            var lastFetchedBefore = Math.abs(this.lastFetchedFromServer.getTime() - currentTime.getTime());
        }
        else {
            this.lastFetchedFromServer = new Date();
        }
        if (fetchFromServer ||
            !this.localClients ||
            lastFetchedBefore > src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].lastFetchedBefore) {
            return this.http
                .get(`${this.apiUrl}/Client/getclients`, _servicesConfig__WEBPACK_IMPORTED_MODULE_5__["httpOptions"])
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((response) => {
                this.localClients = response;
                this.lastFetchedFromServer = new Date();
                return response;
            }));
        }
        else {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(this.localClients);
        }
    }
    filter(value) {
        const filterValue = value.toLowerCase();
        if (this.data && this.data["clientsFromRepo"]) {
            return this.data["clientsFromRepo"].filter((item) => item.clientName.toLowerCase().includes(filterValue));
        }
    }
    getClient(clientName) {
        return this.http
            .get(`${this.apiUrl}/Client/getclients?ClientName=` + clientName, _servicesConfig__WEBPACK_IMPORTED_MODULE_5__["httpOptions"])
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((response) => {
            return response;
        }));
    }
    createClient(client, photoBase64String, file) {
        const fd = new FormData();
        fd.append("clientJSON", JSON.stringify(client));
        if (photoBase64String != "")
            fd.append("base64String", photoBase64String);
        if (file != null)
            fd.append("fileFromFolder", file.data);
        const req = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpRequest"]("POST", `${this.apiUrl}/Client/create`, fd, {
            // headers: headers,
            reportProgress: true,
        });
        return this.http.request(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((event) => {
            switch (event.type) {
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpEventType"].UploadProgress:
                    break;
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpEventType"].Response:
                    return event;
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["tap"])((message) => { }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["last"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["catchError"])((error) => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(`Client has not been created`);
        }));
    }
    deleteClient(client) {
        const fd = new FormData();
        fd.append("clientJSON", JSON.stringify(client));
        const req = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpRequest"]("POST", `${this.apiUrl}/Client/delete`, fd, {
            // headers: headers,
            reportProgress: true,
        });
        return this.http.request(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((event) => {
            debugger;
            switch (event.type) {
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpEventType"].UploadProgress:
                    break;
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpEventType"].Response:
                    return event.body.clientsFromRepo;
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["tap"])((message) => { }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["last"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["catchError"])((error) => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(`Client has not been updated`);
        }));
    }
    updateClient(client, photoBase64String, file) {
        const fd = new FormData();
        fd.append("clientJSON", JSON.stringify(client));
        if (photoBase64String != "")
            fd.append("base64String", photoBase64String);
        if (file != null)
            fd.append("fileFromFolder", file.data);
        const req = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpRequest"]("POST", `${this.apiUrl}/Client/update`, fd, {
            // headers: headers,
            reportProgress: true,
        });
        return this.http.request(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((event) => {
            debugger;
            switch (event.type) {
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpEventType"].UploadProgress:
                    break;
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpEventType"].Response:
                    return event.body.clientsFromRepo;
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["tap"])((message) => { }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["last"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["catchError"])((error) => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(`Client has not been updated`);
        }));
    }
}
ClientService.ɵfac = function ClientService_Factory(t) { return new (t || ClientService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_Alert_alert_service__WEBPACK_IMPORTED_MODULE_6__["AlertService"])); };
ClientService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: ClientService, factory: ClientService.ɵfac, providedIn: "root" });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ClientService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: "root",
            }]
    }], function () { return [{ type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }, { type: _Alert_alert_service__WEBPACK_IMPORTED_MODULE_6__["AlertService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/Services/common/servicetype.service.ts":
/*!********************************************************!*\
  !*** ./src/app/Services/common/servicetype.service.ts ***!
  \********************************************************/
/*! exports provided: ServicetypeService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServicetypeService", function() { return ServicetypeService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _servicesConfig__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../servicesConfig */ "./src/app/Services/servicesConfig.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");







class ServicetypeService {
    constructor(http) {
        this.http = http;
        this.apiUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].apiUrl;
    }
    getServiceTypes(fetchFromServer = false) {
        var currentTime = new Date();
        if (this.lastFetchedFromServer) {
            var lastFetchedBefore = Math.abs(this.lastFetchedFromServer.getTime() - currentTime.getTime());
        }
        else {
            this.lastFetchedFromServer = new Date();
        }
        if (fetchFromServer || !this.localServiceTypes || lastFetchedBefore > src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].lastFetchedBefore) {
            const httpOptions = {
                headers: _servicesConfig__WEBPACK_IMPORTED_MODULE_4__["headers"]
            };
            return this.http.get(`${this.apiUrl}/ServiceType/getservicetypes`, httpOptions)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((response) => {
                this.localServiceTypes = response;
                return response;
            }));
        }
        else {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])(this.localServiceTypes);
        }
    }
    createServiceType(serviceType) {
        return this.http.post(`${this.apiUrl}/ServiceType/Create`, serviceType, _servicesConfig__WEBPACK_IMPORTED_MODULE_4__["httpOptions"])
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((response) => {
            return response;
        }));
    }
}
ServicetypeService.ɵfac = function ServicetypeService_Factory(t) { return new (t || ServicetypeService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"])); };
ServicetypeService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: ServicetypeService, factory: ServicetypeService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ServicetypeService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"] }]; }, null); })();


/***/ }),

/***/ "./src/app/Services/common/transaction-type.service.ts":
/*!*************************************************************!*\
  !*** ./src/app/Services/common/transaction-type.service.ts ***!
  \*************************************************************/
/*! exports provided: TransactionTypeService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TransactionTypeService", function() { return TransactionTypeService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _servicesConfig__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../servicesConfig */ "./src/app/Services/servicesConfig.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");







class TransactionTypeService {
    constructor(http) {
        this.http = http;
        this.apiUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].apiUrl;
    }
    getTransactionTypes(fetchFromServer = false) {
        var currentTime = new Date();
        if (this.lastFetchedFromServer) {
            var lastFetchedBefore = Math.abs(this.lastFetchedFromServer.getTime() - currentTime.getTime());
        }
        else {
            this.lastFetchedFromServer = new Date();
        }
        if (fetchFromServer || !this.localTransactionTypes || lastFetchedBefore > src_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].lastFetchedBefore) {
            return this.http.get(`${this.apiUrl}/TransactionType/gettransactiontypes`, _servicesConfig__WEBPACK_IMPORTED_MODULE_4__["httpOptions"])
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])((response) => {
                this.localTransactionTypes = response;
                return response;
            }));
        }
        else {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(this.localTransactionTypes);
        }
    }
    createTransactionType(transcationType) {
        return this.http.post(`${this.apiUrl}/TransactionType/Create`, transcationType, _servicesConfig__WEBPACK_IMPORTED_MODULE_4__["httpOptions"])
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])((response) => {
            return response;
        }));
    }
}
TransactionTypeService.ɵfac = function TransactionTypeService_Factory(t) { return new (t || TransactionTypeService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"])); };
TransactionTypeService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: TransactionTypeService, factory: TransactionTypeService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](TransactionTypeService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"] }]; }, null); })();


/***/ }),

/***/ "./src/app/Services/common/user.service.ts":
/*!*************************************************!*\
  !*** ./src/app/Services/common/user.service.ts ***!
  \*************************************************/
/*! exports provided: UserService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserService", function() { return UserService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _servicesConfig__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../servicesConfig */ "./src/app/Services/servicesConfig.ts");








class UserService {
    constructor(http) {
        this.http = http;
        this.apiUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].apiUrl;
    }
    getUsers(fetchFromServer = false) {
        var currentTime = new Date();
        if (this.lastFetchedFromServer) {
            var lastFetchedBefore = Math.abs(this.lastFetchedFromServer.getTime() - currentTime.getTime());
        }
        else {
            this.lastFetchedFromServer = new Date();
        }
        if (fetchFromServer || !this.localUsers || lastFetchedBefore > src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].lastFetchedBefore) {
            return this.http.get(`${this.apiUrl}/User/getusers`, _servicesConfig__WEBPACK_IMPORTED_MODULE_5__["httpOptions"])
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((response) => {
                this.localUsers = response;
                return response;
            }));
        }
        else {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(this.localUsers);
        }
    }
    filter(value) {
        const filterValue = value.toLowerCase();
        if (this.data && this.data['uersFromRepo']) {
            return this.data['usersFromRepo'].filter((item) => item.username.toLowerCase().includes(filterValue));
        }
    }
    getUser(userName) {
        return this.http.get(`${this.apiUrl}/User/getusers?username=` + userName, _servicesConfig__WEBPACK_IMPORTED_MODULE_5__["httpOptions"])
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((response) => {
            return response;
        }));
    }
    deleteUser(user) {
        const fd = new FormData();
        fd.append("userJSON", JSON.stringify(user));
        const req = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpRequest"]('POST', `${this.apiUrl}/User/delete`, fd, {
            // headers: headers,
            reportProgress: true
        });
        return this.http.request(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(event => {
            debugger;
            switch (event.type) {
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpEventType"].UploadProgress:
                    break;
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpEventType"].Response:
                    return event.body.usersFromRepo;
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["tap"])(message => { }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["last"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["catchError"])((error) => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(`User has not been updated`);
        }));
    }
    updateUser(user) {
        const fd = new FormData();
        fd.append("userJSON", JSON.stringify(user));
        const req = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpRequest"]('POST', `${this.apiUrl}/User/update`, fd, {
            // headers: headers,
            reportProgress: true
        });
        return this.http.request(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(event => {
            debugger;
            switch (event.type) {
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpEventType"].UploadProgress:
                    break;
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpEventType"].Response:
                    return event.body.usersFromRepo;
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["tap"])(message => { }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["last"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["catchError"])((error) => {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(`User has not been updated`);
        }));
    }
}
UserService.ɵfac = function UserService_Factory(t) { return new (t || UserService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"])); };
UserService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: UserService, factory: UserService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](UserService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }]; }, null); })();


/***/ }),

/***/ "./src/app/Services/servicesConfig.ts":
/*!********************************************!*\
  !*** ./src/app/Services/servicesConfig.ts ***!
  \********************************************/
/*! exports provided: headers, httpOptions */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "headers", function() { return headers; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "httpOptions", function() { return httpOptions; });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");

const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpHeaders"]()
    .set('Content-Type', 'application/json')
    .set('Accept', 'application/json')
    .set('Access-Control-Allow-Origin', '*')
    .set('Access-Control-Allow-Headers', 'x-auth, content-type');
const httpOptions = {
    headers: headers
};


/***/ }),

/***/ "./src/app/_helpers/TableUtil.ts":
/*!***************************************!*\
  !*** ./src/app/_helpers/TableUtil.ts ***!
  \***************************************/
/*! exports provided: TableUtil */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TableUtil", function() { return TableUtil; });
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! xlsx */ "./node_modules/xlsx/xlsx.js");
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_0__);

class TableUtil {
    static exportToExcel(tableId, name) {
        let timeSpan = new Date().toISOString();
        let prefix = name || "ExportResult";
        let fileName = `${prefix}-${timeSpan}`;
        let targetTableElm = document.getElementById(tableId);
        let wb = xlsx__WEBPACK_IMPORTED_MODULE_0__["utils"].table_to_book(targetTableElm, { sheet: prefix });
        xlsx__WEBPACK_IMPORTED_MODULE_0__["writeFile"](wb, `${fileName}.xlsx`);
    }
}


/***/ }),

/***/ "./src/app/_helpers/alert/alert.component.ts":
/*!***************************************************!*\
  !*** ./src/app/_helpers/alert/alert.component.ts ***!
  \***************************************************/
/*! exports provided: AlertComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AlertComponent", function() { return AlertComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/Services/Alert/alert.service */ "./src/app/Services/Alert/alert.service.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");





function AlertComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r270 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", ctx_r270.message.cssClass);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("innerHTML", ctx_r270.text, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeHtml"]);
} }
class AlertComponent {
    constructor(alertService, sanitize) {
        this.alertService = alertService;
        this.sanitize = sanitize;
    }
    ngOnInit() {
        this.subscription = this.alertService.getAlert()
            .subscribe(message => {
            switch (message && message.type) {
                case 'success':
                    message.cssClass = 'alert alert-success';
                    this.messageType = 'success';
                    break;
                case 'error':
                    message.cssClass = 'alert alert-danger';
                    this.messageType = 'error';
                    break;
                case 'info':
                    message.cssClass = 'alert alert-info';
                    this.messageType = 'info';
                    break;
            }
            this.message = message;
            this.text = this.sanitize.bypassSecurityTrustHtml(message.text);
            setTimeout(() => {
                this.message = "";
            }, message.showTime);
        });
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
}
AlertComponent.ɵfac = function AlertComponent_Factory(t) { return new (t || AlertComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_1__["AlertService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["DomSanitizer"])); };
AlertComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AlertComponent, selectors: [["app-alert"]], decls: 1, vars: 1, consts: [["class", "alert-window", 3, "ngClass", 4, "ngIf"], [1, "alert-window", 3, "ngClass"], [3, "innerHTML"]], template: function AlertComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, AlertComponent_div_0_Template, 2, 2, "div", 0);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.message);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["NgClass"]], styles: [".alert-window[_ngcontent-%COMP%] {\n  position: fixed;\n  overflow: hidden;\n  box-sizing: border-box;\n  display: flex;\n  flex-wrap: nowrap;\n  z-index: 9999;\n  bottom: 20px;\n  right: 20px;\n  -webkit-animation-name: ease-in;\n          animation-name: ease-in;\n  -webkit-animation-duration: 1s;\n          animation-duration: 1s;\n  -webkit-animation-timing-function: linear;\n          animation-timing-function: linear;\n}\n\n@-webkit-keyframes ease-in {\n  0% {\n    right: 0px;\n  }\n  100% {\n    right: 20px;\n  }\n}\n\n@keyframes ease-in {\n  0% {\n    right: 0px;\n  }\n  100% {\n    right: 20px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvX2hlbHBlcnMvYWxlcnQvQzpcXERldmVsb3BtZW50XFxTYXR0aVxcRmluYW5jZVRyYWNrZXIvc3JjXFxhcHBcXF9oZWxwZXJzXFxhbGVydFxcYWxlcnQuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL19oZWxwZXJzL2FsZXJ0L2FsZXJ0LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0VBQ0Esc0JBQUE7RUFFQSxhQUFBO0VBRUEsaUJBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSwrQkFBQTtVQUFBLHVCQUFBO0VBQ0EsOEJBQUE7VUFBQSxzQkFBQTtFQUNBLHlDQUFBO1VBQUEsaUNBQUE7QUNDSjs7QURFQTtFQUNJO0lBQ0ksVUFBQTtFQ0NOO0VEQ0U7SUFDSSxXQUFBO0VDQ047QUFDRjs7QURQQTtFQUNJO0lBQ0ksVUFBQTtFQ0NOO0VEQ0U7SUFDSSxXQUFBO0VDQ047QUFDRiIsImZpbGUiOiJzcmMvYXBwL19oZWxwZXJzL2FsZXJ0L2FsZXJ0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmFsZXJ0LXdpbmRvdyB7XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgIGRpc3BsYXk6IC1tcy1mbGV4Ym94O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIC1tcy1mbGV4LXdyYXA6IG5vd3JhcDtcclxuICAgIGZsZXgtd3JhcDogbm93cmFwO1xyXG4gICAgei1pbmRleDogOTk5OTtcclxuICAgIGJvdHRvbTogMjBweDtcclxuICAgIHJpZ2h0OiAyMHB4O1xyXG4gICAgYW5pbWF0aW9uLW5hbWU6IGVhc2UtaW47XHJcbiAgICBhbmltYXRpb24tZHVyYXRpb246IDFzO1xyXG4gICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogbGluZWFyO1xyXG59XHJcblxyXG5Aa2V5ZnJhbWVzIGVhc2UtaW4ge1xyXG4gICAgMCUge1xyXG4gICAgICAgIHJpZ2h0OiAwcHg7XHJcbiAgICB9XHJcbiAgICAxMDAlIHtcclxuICAgICAgICByaWdodDogMjBweDtcclxuICAgIH1cclxufVxyXG4iLCIuYWxlcnQtd2luZG93IHtcbiAgcG9zaXRpb246IGZpeGVkO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBkaXNwbGF5OiAtbXMtZmxleGJveDtcbiAgZGlzcGxheTogZmxleDtcbiAgLW1zLWZsZXgtd3JhcDogbm93cmFwO1xuICBmbGV4LXdyYXA6IG5vd3JhcDtcbiAgei1pbmRleDogOTk5OTtcbiAgYm90dG9tOiAyMHB4O1xuICByaWdodDogMjBweDtcbiAgYW5pbWF0aW9uLW5hbWU6IGVhc2UtaW47XG4gIGFuaW1hdGlvbi1kdXJhdGlvbjogMXM7XG4gIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGxpbmVhcjtcbn1cblxuQGtleWZyYW1lcyBlYXNlLWluIHtcbiAgMCUge1xuICAgIHJpZ2h0OiAwcHg7XG4gIH1cbiAgMTAwJSB7XG4gICAgcmlnaHQ6IDIwcHg7XG4gIH1cbn0iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AlertComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-alert',
                templateUrl: './alert.component.html',
                styleUrls: ['./alert.component.scss']
            }]
    }], function () { return [{ type: src_app_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_1__["AlertService"] }, { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["DomSanitizer"] }]; }, null); })();


/***/ }),

/***/ "./src/app/_helpers/auth.guard.ts":
/*!****************************************!*\
  !*** ./src/app/_helpers/auth.guard.ts ***!
  \****************************************/
/*! exports provided: AuthGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuard", function() { return AuthGuard; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _Services_Auth_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Services/Auth/authentication.service */ "./src/app/Services/Auth/authentication.service.ts");




class AuthGuard {
    constructor(router, authenticationService) {
        this.router = router;
        this.authenticationService = authenticationService;
    }
    canActivate(route, state) {
        if (this.authenticationService.currentUserObject) {
            return true;
        }
        // not logged in so redirect to login page with the return url
        this.router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
        return true;
    }
}
AuthGuard.ɵfac = function AuthGuard_Factory(t) { return new (t || AuthGuard)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_Services_Auth_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"])); };
AuthGuard.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: AuthGuard, factory: AuthGuard.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AuthGuard, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{ providedIn: 'root' }]
    }], function () { return [{ type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }, { type: _Services_Auth_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/_helpers/currency-formatter.pipe.ts":
/*!*****************************************************!*\
  !*** ./src/app/_helpers/currency-formatter.pipe.ts ***!
  \*****************************************************/
/*! exports provided: CurrencyFormatterPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CurrencyFormatterPipe", function() { return CurrencyFormatterPipe; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


class CurrencyFormatterPipe {
    transform(value) {
        return value ? value.charAt(0) === '-' ? '(' + value.substring(1, value.length) + ')' : value : value;
    }
}
CurrencyFormatterPipe.ɵfac = function CurrencyFormatterPipe_Factory(t) { return new (t || CurrencyFormatterPipe)(); };
CurrencyFormatterPipe.ɵpipe = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefinePipe"]({ name: "currencyFormatter", type: CurrencyFormatterPipe, pure: true });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CurrencyFormatterPipe, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Pipe"],
        args: [{
                name: 'currencyFormatter'
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/app-route-animation.ts":
/*!****************************************!*\
  !*** ./src/app/app-route-animation.ts ***!
  \****************************************/
/*! exports provided: slideInAnimationForComponents, slideInAnimation */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "slideInAnimationForComponents", function() { return slideInAnimationForComponents; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "slideInAnimation", function() { return slideInAnimation; });
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/animations */ "./node_modules/@angular/animations/__ivy_ngcc__/fesm2015/animations.js");

const slideInAnimationForComponents = Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["trigger"])('ComponentAnimation', [
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["state"])('stop', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({
        transform: 'translateX(100%)',
        opacity: '1'
    })),
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["state"])('start', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({
        transform: 'translateX(0)',
        opacity: '1'
    })),
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["transition"])('* <=> *', [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["animate"])('1s ease-out', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ left: '100%' }))])
]);
const slideInAnimation = Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["trigger"])('routeAnimations', [
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["transition"])('Contact => *', [
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["query"])(':enter, :leave', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ position: 'fixed', width: '100%' }), { optional: true }),
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["group"])([
            Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["query"])(':enter', [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ transform: 'translateX(-100%)' }),
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["animate"])('0.5s ease-in-out', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ transform: 'translateX(0%)' }))
            ], { optional: true }),
            Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["query"])(':leave', [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ transform: 'translateX(0%)' }),
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["animate"])('0.5s ease-in-out', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ transform: 'translateX(100%)' }))
            ], { optional: true }),
        ])
    ]),
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["transition"])('Home => *', [
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["query"])(':enter, :leave', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ position: 'fixed', width: '100%' }), { optional: true }),
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["group"])([
            Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["query"])(':enter', [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ transform: 'translateX(100%)' }),
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["animate"])('0.5s ease-in-out', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ transform: 'translateX(0%)' }))
            ], { optional: true }),
            Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["query"])(':leave', [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ transform: 'translateX(0%)' }),
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["animate"])('0.5s ease-in-out', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ transform: 'translateX(-100%)' }))
            ], { optional: true }),
        ])
    ]),
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["transition"])('Report => Contact', [
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["query"])(':enter, :leave', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ position: 'fixed', width: '100%' }), { optional: true }),
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["group"])([
            Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["query"])(':enter', [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ transform: 'translateX(100%)' }),
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["animate"])('0.5s ease-in-out', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ transform: 'translateX(0%)' }))
            ], { optional: true }),
            Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["query"])(':leave', [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ transform: 'translateX(0%)' }),
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["animate"])('0.5s ease-in-out', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ transform: 'translateX(-100%)' }))
            ], { optional: true }),
        ])
    ]),
    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["transition"])('Report => Home', [
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["query"])(':enter, :leave', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ position: 'fixed', width: '100%' }), { optional: true }),
        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["group"])([
            Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["query"])(':enter', [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ transform: 'translateX(-100%)' }),
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["animate"])('0.5s ease-in-out', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ transform: 'translateX(0%)' }))
            ], { optional: true }),
            Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["query"])(':leave', [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ transform: 'translateX(0%)' }),
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["animate"])('0.5s ease-in-out', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_0__["style"])({ transform: 'translateX(100%)' }))
            ], { optional: true }),
        ])
    ]),
]);


/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _Pages_Common_login_login_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Pages/Common/login/login.component */ "./src/app/Pages/Common/login/login.component.ts");
/* harmony import */ var _Pages_Operator_cash_entry_cash_entry_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Pages/Operator/cash-entry/cash-entry.component */ "./src/app/Pages/Operator/cash-entry/cash-entry.component.ts");
/* harmony import */ var _helpers_auth_guard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./_helpers/auth.guard */ "./src/app/_helpers/auth.guard.ts");
/* harmony import */ var _Pages_Reports_general_report_general_report_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Pages/Reports/general-report/general-report.component */ "./src/app/Pages/Reports/general-report/general-report.component.ts");
/* harmony import */ var _Pages_Reports_debit_report_debit_report_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Pages/Reports/debit-report/debit-report.component */ "./src/app/Pages/Reports/debit-report/debit-report.component.ts");
/* harmony import */ var _Pages_Admin__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Pages/Admin */ "./src/app/Pages/Admin/index.ts");










const routes = [
    { path: "Report", component: _Pages_Reports_general_report_general_report_component__WEBPACK_IMPORTED_MODULE_5__["GeneralReportComponent"], data: { animation: "Report" }, canActivate: [_helpers_auth_guard__WEBPACK_IMPORTED_MODULE_4__["AuthGuard"]] },
    { path: "CashEntry", component: _Pages_Operator_cash_entry_cash_entry_component__WEBPACK_IMPORTED_MODULE_3__["CashEntryComponent"], data: { animation: "About" }, canActivate: [_helpers_auth_guard__WEBPACK_IMPORTED_MODULE_4__["AuthGuard"]] },
    { path: "login", component: _Pages_Common_login_login_component__WEBPACK_IMPORTED_MODULE_2__["LoginComponent"], data: { animation: "Contact" } },
    { path: "DebitReport", component: _Pages_Reports_debit_report_debit_report_component__WEBPACK_IMPORTED_MODULE_6__["DebitReportComponent"], data: { animation: "Contact" } },
    { path: "CompOperator", component: _Pages_Admin__WEBPACK_IMPORTED_MODULE_7__["EditComputerOperatorComponent"], data: { animation: "Contact" }, canActivate: [_helpers_auth_guard__WEBPACK_IMPORTED_MODULE_4__["AuthGuard"]] },
    { path: "Client", component: _Pages_Admin__WEBPACK_IMPORTED_MODULE_7__["EditClientComponent"], data: { animation: "Contact" }, canActivate: [_helpers_auth_guard__WEBPACK_IMPORTED_MODULE_4__["AuthGuard"]] },
    { path: "ServiceType", component: _Pages_Admin__WEBPACK_IMPORTED_MODULE_7__["EditServiceTypeComponent"], data: { animation: "Contact" }, canActivate: [_helpers_auth_guard__WEBPACK_IMPORTED_MODULE_4__["AuthGuard"]] },
    { path: "TransactionType", component: _Pages_Admin__WEBPACK_IMPORTED_MODULE_7__["EditTransactionTypeComponent"], data: { animation: "Contact" }, canActivate: [_helpers_auth_guard__WEBPACK_IMPORTED_MODULE_4__["AuthGuard"]] },
    { path: "", component: _Pages_Operator_cash_entry_cash_entry_component__WEBPACK_IMPORTED_MODULE_3__["CashEntryComponent"], data: { animation: "Home" }, canActivate: [_helpers_auth_guard__WEBPACK_IMPORTED_MODULE_4__["AuthGuard"]] },
    { path: "**", redirectTo: "" },
];
class AppRoutingModule {
}
AppRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: AppRoutingModule });
AppRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ factory: function AppRoutingModule_Factory(t) { return new (t || AppRoutingModule)(); }, imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
        _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](AppRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]] }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppRoutingModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
                exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]],
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _app_route_animation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-route-animation */ "./src/app/app-route-animation.ts");
/* harmony import */ var _Services_Auth_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Services/Auth/authentication.service */ "./src/app/Services/Auth/authentication.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Services/Alert/alert.service */ "./src/app/Services/Alert/alert.service.ts");
/* harmony import */ var _Services_common_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Services/common/user.service */ "./src/app/Services/common/user.service.ts");
/* harmony import */ var _Services_common_client_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Services/common/client.service */ "./src/app/Services/common/client.service.ts");
/* harmony import */ var _Services_common_transaction_type_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Services/common/transaction-type.service */ "./src/app/Services/common/transaction-type.service.ts");
/* harmony import */ var _Services_common_servicetype_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./Services/common/servicetype.service */ "./src/app/Services/common/servicetype.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _Pages_Common_loading_spinner_loading_spinner_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./Pages/Common/loading-spinner/loading-spinner.component */ "./src/app/Pages/Common/loading-spinner/loading-spinner.component.ts");
/* harmony import */ var _helpers_alert_alert_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./_helpers/alert/alert.component */ "./src/app/_helpers/alert/alert.component.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/__ivy_ngcc__/fesm2015/ng-bootstrap.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");















function AppComponent_nav_0_Template(rf, ctx) { if (rf & 1) {
    const _r169 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "nav", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "a", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "My Finance Manager");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "ul", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "li", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "a", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "Cash Entry");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "li", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "a", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "General Report");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "li", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "a", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, " Manage Master Data ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "a", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "COMPUTER OPERARATORS");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](17, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "a", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, "CUSTOMERS");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](20, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "a", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "SERVICE TYPES");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](23, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "a", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, "TRANSACTION TYPES");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "form", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "button", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AppComponent_nav_0_Template_button_click_27_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r169); const ctx_r168 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r168.updateDataFromServer(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](28, "Update Dropdown Data");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "a", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "button", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AppComponent_nav_0_Template_button_click_31_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r169); const ctx_r170 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r170.Logout(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](32, "Logout");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r166 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](30);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" Welcome ", ctx_r166.LoggedInUserName, " ");
} }
class AppComponent {
    constructor(authenticationService, router, alertService, userService, clientService, transactionTypeService, serviceTypeService) {
        this.authenticationService = authenticationService;
        this.router = router;
        this.alertService = alertService;
        this.userService = userService;
        this.clientService = clientService;
        this.transactionTypeService = transactionTypeService;
        this.serviceTypeService = serviceTypeService;
        this.title = 'FinanceTracker';
        this.isDropDownBeingUpdated = false;
        this.state = 'start';
    }
    ngOnInit() {
        if (this.authenticationService.currentUserObject)
            this.LoggedInUserName = this.authenticationService.currentUserObject.firstName + " " + this.authenticationService.currentUserObject.lastName;
        this.userObjectSubscription = this.authenticationService.getUserObject()
            .subscribe(userObject => {
            if (userObject)
                this.LoggedInUserName = userObject.firstName + " " + userObject.lastName;
            else
                this.LoggedInUserName = null;
        });
    }
    Logout() {
        this.authenticationService.logout();
        this.router.navigate(['/'], { skipLocationChange: true });
        this.authenticationService.clearUserObject();
        this.alertService.success("Logged Out successfully");
    }
    ngOnDestroy() {
        this.userObjectSubscription.unsubscribe();
        this.clientServiceSubscription.unsubscribe();
        this.userServiceSubscription.unsubscribe();
        this.transactionTypeServiceSubscription.unsubscribe();
        this.serviceTypeServiceSubscription.unsubscribe();
    }
    updateDataFromServer() {
        this.isDropDownBeingUpdated = true;
        var count = 0;
        this.clientServiceSubscription = this.clientService.getClients(true)
            .subscribe(data => {
            count++;
            if (count > 3)
                this.isDropDownBeingUpdated = false;
            console.log(data);
        });
        this.userServiceSubscription = this.userService.getUsers(true)
            .subscribe(data => {
            count++;
            if (count > 3)
                this.isDropDownBeingUpdated = false;
            console.log(data);
        });
        this.transactionTypeServiceSubscription = this.transactionTypeService.getTransactionTypes(true)
            .subscribe(data => {
            count++;
            if (count > 3)
                this.isDropDownBeingUpdated = false;
            console.log(data);
        });
        this.serviceTypeServiceSubscription = this.serviceTypeService.getServiceTypes(true)
            .subscribe(data => {
            count++;
            if (count > 3)
                this.isDropDownBeingUpdated = false;
            console.log(data);
        });
    }
}
AppComponent.ɵfac = function AppComponent_Factory(t) { return new (t || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_Services_Auth_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_4__["AlertService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_Services_common_user_service__WEBPACK_IMPORTED_MODULE_5__["UserService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_Services_common_client_service__WEBPACK_IMPORTED_MODULE_6__["ClientService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_Services_common_transaction_type_service__WEBPACK_IMPORTED_MODULE_7__["TransactionTypeService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_Services_common_servicetype_service__WEBPACK_IMPORTED_MODULE_8__["ServicetypeService"])); };
AppComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AppComponent, selectors: [["app-root"]], decls: 10, vars: 5, consts: [["class", "navbar navbar-expand-lg navbar-light bg-light", 4, "ngIf"], [1, "loader-overlay", 3, "hidden"], [3, "hidden"], ["o", "outlet"], [1, "navbar", "navbar-expand-lg", "navbar-light", "bg-light"], ["href", "#", 1, "navbar-brand"], ["id", "navbarSupportedContent", 1, "collapse", "navbar-collapse"], [1, "navbar-nav", "mr-auto"], [1, "nav-item", "active"], ["routerLink", "/CashEntry", "skipLocationChange", "", 1, "nav-link"], [1, "nav-item"], ["routerLink", "/Report", "skipLocationChange", "", 1, "nav-link"], [1, "nav-item", "dropdown"], ["id", "navbarDropdown", "role", "button", "data-toggle", "dropdown", "aria-haspopup", "true", "aria-expanded", "false", 1, "nav-link", "dropdown-toggle"], ["aria-labelledby", "navbarDropdown", 1, "dropdown-menu"], ["routerLink", "/CompOperator", 1, "nav-link", "dropdown-item"], [1, "dropdown-divider"], ["routerLink", "/Client", 1, "nav-link", "dropdown-item"], ["routerLink", "/ServiceType", 1, "nav-link", "dropdown-item"], ["routerLink", "/TransactionType", 1, "nav-link", "dropdown-item"], [1, "form-inline", "my-2", "my-lg-0"], ["type", "button", 1, "btn", "btn-outline-success", "mr-3", 3, "click"], [1, "nav-link"], ["type", "submit", 1, "btn", "btn-outline-success", "my-2", "my-sm-0", 3, "click"]], template: function AppComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, AppComponent_nav_0_Template, 33, 1, "nav", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "app-loading-spinner");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "app-alert");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "router-outlet", null, 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        const _r167 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.LoggedInUserName);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", !ctx.isDropDownBeingUpdated);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("@ComponentAnimation", ctx.state);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", ctx.isDropDownBeingUpdated);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("@routeAnimations", _r167 && _r167.activatedRouteData && _r167.activatedRouteData["animation"]);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_9__["NgIf"], _Pages_Common_loading_spinner_loading_spinner_component__WEBPACK_IMPORTED_MODULE_10__["LoadingSpinnerComponent"], _helpers_alert_alert_component__WEBPACK_IMPORTED_MODULE_11__["AlertComponent"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterOutlet"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_12__["NgbNavbar"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterLinkWithHref"], _angular_forms__WEBPACK_IMPORTED_MODULE_13__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_13__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_13__["NgForm"]], styles: [".dark-overlay[_ngcontent-%COMP%] {\n  background-color: rgba(0, 0, 0, 0.7);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvQzpcXERldmVsb3BtZW50XFxTYXR0aVxcRmluYW5jZVRyYWNrZXIvc3JjXFxhcHBcXGFwcC5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksb0NBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5kYXJrLW92ZXJsYXkge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgwLCAwLCAwLCAwLjcpO1xyXG59XHJcbiIsIi5kYXJrLW92ZXJsYXkge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNyk7XG59Il19 */"], data: { animation: [_app_route_animation__WEBPACK_IMPORTED_MODULE_1__["slideInAnimation"], _app_route_animation__WEBPACK_IMPORTED_MODULE_1__["slideInAnimationForComponents"]] } });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-root',
                templateUrl: './app.component.html',
                styleUrls: ['./app.component.scss'],
                animations: [_app_route_animation__WEBPACK_IMPORTED_MODULE_1__["slideInAnimation"], _app_route_animation__WEBPACK_IMPORTED_MODULE_1__["slideInAnimationForComponents"]]
            }]
    }], function () { return [{ type: _Services_Auth_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"] }, { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }, { type: _Services_Alert_alert_service__WEBPACK_IMPORTED_MODULE_4__["AlertService"] }, { type: _Services_common_user_service__WEBPACK_IMPORTED_MODULE_5__["UserService"] }, { type: _Services_common_client_service__WEBPACK_IMPORTED_MODULE_6__["ClientService"] }, { type: _Services_common_transaction_type_service__WEBPACK_IMPORTED_MODULE_7__["TransactionTypeService"] }, { type: _Services_common_servicetype_service__WEBPACK_IMPORTED_MODULE_8__["ServicetypeService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _Pages_Common_login_login_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Pages/Common/login/login.component */ "./src/app/Pages/Common/login/login.component.ts");
/* harmony import */ var _Pages_Operator_cash_entry_cash_entry_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Pages/Operator/cash-entry/cash-entry.component */ "./src/app/Pages/Operator/cash-entry/cash-entry.component.ts");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/dialog.js");
/* harmony import */ var _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/autocomplete */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/autocomplete.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/input.js");
/* harmony import */ var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/checkbox */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/checkbox.js");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/icon */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/icon.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/material/progress-spinner */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/progress-spinner.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");
/* harmony import */ var _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/material/button-toggle */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button-toggle.js");
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material/table */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/table.js");
/* harmony import */ var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/material/paginator */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/paginator.js");
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/material/core */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/material/datepicker */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/datepicker.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/__ivy_ngcc__/fesm2015/ng-bootstrap.js");
/* harmony import */ var _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/cdk/overlay */ "./node_modules/@angular/cdk/__ivy_ngcc__/fesm2015/overlay.js");
/* harmony import */ var _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/cdk/portal */ "./node_modules/@angular/cdk/__ivy_ngcc__/fesm2015/portal.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _Pages_Operator_cash_entry_item_list_cash_entry_item_list_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./Pages/Operator/cash-entry-item-list/cash-entry-item-list.component */ "./src/app/Pages/Operator/cash-entry-item-list/cash-entry-item-list.component.ts");
/* harmony import */ var _Pages_Operator_cash_entry_add_item_cash_entry_add_item_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./Pages/Operator/cash-entry-add-item/cash-entry-add-item.component */ "./src/app/Pages/Operator/cash-entry-add-item/cash-entry-add-item.component.ts");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/animations.js");
/* harmony import */ var _Pages_Common_PopUps_add_new_client_add_new_client_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./Pages/Common/PopUps/add-new-client/add-new-client.component */ "./src/app/Pages/Common/PopUps/add-new-client/add-new-client.component.ts");
/* harmony import */ var _Pages_Common_PopUps_add_new_service_type_add_new_service_type_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./Pages/Common/PopUps/add-new-service-type/add-new-service-type.component */ "./src/app/Pages/Common/PopUps/add-new-service-type/add-new-service-type.component.ts");
/* harmony import */ var _Pages_Common_PopUps_cash_entry_edit_item_cash_entry_edit_item_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./Pages/Common/PopUps/cash-entry-edit-item/cash-entry-edit-item.component */ "./src/app/Pages/Common/PopUps/cash-entry-edit-item/cash-entry-edit-item.component.ts");
/* harmony import */ var _Pages_Common_loading_spinner_loading_spinner_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./Pages/Common/loading-spinner/loading-spinner.component */ "./src/app/Pages/Common/loading-spinner/loading-spinner.component.ts");
/* harmony import */ var _helpers_currency_formatter_pipe__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./_helpers/currency-formatter.pipe */ "./src/app/_helpers/currency-formatter.pipe.ts");
/* harmony import */ var _helpers_alert_alert_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./_helpers/alert/alert.component */ "./src/app/_helpers/alert/alert.component.ts");
/* harmony import */ var _Pages_Common_PopUps_add_new_transaction_type_add_new_transaction_type_component__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./Pages/Common/PopUps/add-new-transaction-type/add-new-transaction-type.component */ "./src/app/Pages/Common/PopUps/add-new-transaction-type/add-new-transaction-type.component.ts");
/* harmony import */ var _Pages_Reports_general_report_general_report_component__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./Pages/Reports/general-report/general-report.component */ "./src/app/Pages/Reports/general-report/general-report.component.ts");
/* harmony import */ var _Pages_Reports_debit_report_debit_report_component__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./Pages/Reports/debit-report/debit-report.component */ "./src/app/Pages/Reports/debit-report/debit-report.component.ts");
/* harmony import */ var _Pages_Admin__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./Pages/Admin */ "./src/app/Pages/Admin/index.ts");
/* harmony import */ var _Pages_Admin_Create_create_computer_operator_create_computer_operator_component__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./Pages/Admin/Create/create-computer-operator/create-computer-operator.component */ "./src/app/Pages/Admin/Create/create-computer-operator/create-computer-operator.component.ts");
/* harmony import */ var _Pages_Admin_Create_create_client_create_client_component__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ./Pages/Admin/Create/create-client/create-client.component */ "./src/app/Pages/Admin/Create/create-client/create-client.component.ts");
/* harmony import */ var _Pages_Admin_Create_create_service_type_create_service_type_component__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ./Pages/Admin/Create/create-service-type/create-service-type.component */ "./src/app/Pages/Admin/Create/create-service-type/create-service-type.component.ts");
/* harmony import */ var _Pages_Admin_Create_create_transaction_type_create_transaction_type_component__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ./Pages/Admin/Create/create-transaction-type/create-transaction-type.component */ "./src/app/Pages/Admin/Create/create-transaction-type/create-transaction-type.component.ts");










































class AppModule {
}
AppModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: AppModule, bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]] });
AppModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ factory: function AppModule_Factory(t) { return new (t || AppModule)(); }, providers: [_angular_common__WEBPACK_IMPORTED_MODULE_12__["DatePipe"], _angular_common__WEBPACK_IMPORTED_MODULE_12__["CurrencyPipe"], _helpers_currency_formatter_pipe__WEBPACK_IMPORTED_MODULE_31__["CurrencyFormatterPipe"]], imports: [[
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_26__["BrowserAnimationsModule"],
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
            _app_routing_module__WEBPACK_IMPORTED_MODULE_3__["AppRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_23__["HttpClientModule"],
            _angular_material_dialog__WEBPACK_IMPORTED_MODULE_7__["MatDialogModule"],
            _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_8__["MatAutocompleteModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_12__["CommonModule"],
            _angular_material_icon__WEBPACK_IMPORTED_MODULE_11__["MatIconModule"],
            _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_13__["MatProgressSpinnerModule"],
            _angular_material_button__WEBPACK_IMPORTED_MODULE_14__["MatButtonModule"],
            _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_15__["MatButtonToggleModule"],
            _angular_material_table__WEBPACK_IMPORTED_MODULE_16__["MatTableModule"],
            _angular_material_paginator__WEBPACK_IMPORTED_MODULE_17__["MatPaginatorModule"],
            _angular_material_input__WEBPACK_IMPORTED_MODULE_9__["MatInputModule"],
            _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_10__["MatCheckboxModule"],
            _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_19__["MatDatepickerModule"],
            _angular_material_core__WEBPACK_IMPORTED_MODULE_18__["MatNativeDateModule"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_20__["NgbModule"],
            _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_22__["PortalModule"],
            _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_21__["OverlayModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](AppModule, { declarations: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"],
        _Pages_Common_login_login_component__WEBPACK_IMPORTED_MODULE_5__["LoginComponent"],
        _Pages_Operator_cash_entry_cash_entry_component__WEBPACK_IMPORTED_MODULE_6__["CashEntryComponent"],
        _Pages_Operator_cash_entry_item_list_cash_entry_item_list_component__WEBPACK_IMPORTED_MODULE_24__["CashEntryItemListComponent"],
        _Pages_Operator_cash_entry_add_item_cash_entry_add_item_component__WEBPACK_IMPORTED_MODULE_25__["CashEntryAddItemComponent"],
        _Pages_Common_PopUps_add_new_client_add_new_client_component__WEBPACK_IMPORTED_MODULE_27__["AddNewClientComponent"],
        _Pages_Common_PopUps_add_new_service_type_add_new_service_type_component__WEBPACK_IMPORTED_MODULE_28__["AddNewServiceTypeComponent"],
        _Pages_Common_PopUps_cash_entry_edit_item_cash_entry_edit_item_component__WEBPACK_IMPORTED_MODULE_29__["CashEntryEditItemComponent"],
        _Pages_Common_loading_spinner_loading_spinner_component__WEBPACK_IMPORTED_MODULE_30__["LoadingSpinnerComponent"],
        _helpers_currency_formatter_pipe__WEBPACK_IMPORTED_MODULE_31__["CurrencyFormatterPipe"],
        _helpers_alert_alert_component__WEBPACK_IMPORTED_MODULE_32__["AlertComponent"],
        _Pages_Common_PopUps_add_new_transaction_type_add_new_transaction_type_component__WEBPACK_IMPORTED_MODULE_33__["AddNewTransactionTypeComponent"],
        _Pages_Reports_general_report_general_report_component__WEBPACK_IMPORTED_MODULE_34__["GeneralReportComponent"],
        _Pages_Reports_debit_report_debit_report_component__WEBPACK_IMPORTED_MODULE_35__["DebitReportComponent"],
        _Pages_Admin__WEBPACK_IMPORTED_MODULE_36__["EditComputerOperatorComponent"],
        _Pages_Admin__WEBPACK_IMPORTED_MODULE_36__["EditTransactionTypeComponent"],
        _Pages_Admin__WEBPACK_IMPORTED_MODULE_36__["EditClientComponent"],
        _Pages_Admin__WEBPACK_IMPORTED_MODULE_36__["EditServiceTypeComponent"],
        _Pages_Admin_Create_create_computer_operator_create_computer_operator_component__WEBPACK_IMPORTED_MODULE_37__["CreateComputerOperatorComponent"],
        _Pages_Admin_Create_create_client_create_client_component__WEBPACK_IMPORTED_MODULE_38__["CreateClientComponent"],
        _Pages_Admin_Create_create_service_type_create_service_type_component__WEBPACK_IMPORTED_MODULE_39__["CreateServiceTypeComponent"],
        _Pages_Admin_Create_create_transaction_type_create_transaction_type_component__WEBPACK_IMPORTED_MODULE_40__["CreateTransactionTypeComponent"]], imports: [_angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_26__["BrowserAnimationsModule"],
        _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
        _app_routing_module__WEBPACK_IMPORTED_MODULE_3__["AppRoutingModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"],
        _angular_common_http__WEBPACK_IMPORTED_MODULE_23__["HttpClientModule"],
        _angular_material_dialog__WEBPACK_IMPORTED_MODULE_7__["MatDialogModule"],
        _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_8__["MatAutocompleteModule"],
        _angular_common__WEBPACK_IMPORTED_MODULE_12__["CommonModule"],
        _angular_material_icon__WEBPACK_IMPORTED_MODULE_11__["MatIconModule"],
        _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_13__["MatProgressSpinnerModule"],
        _angular_material_button__WEBPACK_IMPORTED_MODULE_14__["MatButtonModule"],
        _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_15__["MatButtonToggleModule"],
        _angular_material_table__WEBPACK_IMPORTED_MODULE_16__["MatTableModule"],
        _angular_material_paginator__WEBPACK_IMPORTED_MODULE_17__["MatPaginatorModule"],
        _angular_material_input__WEBPACK_IMPORTED_MODULE_9__["MatInputModule"],
        _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_10__["MatCheckboxModule"],
        _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_19__["MatDatepickerModule"],
        _angular_material_core__WEBPACK_IMPORTED_MODULE_18__["MatNativeDateModule"],
        _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_20__["NgbModule"],
        _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_22__["PortalModule"],
        _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_21__["OverlayModule"]] }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](AppModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"],
        args: [{
                declarations: [
                    _app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"],
                    _Pages_Common_login_login_component__WEBPACK_IMPORTED_MODULE_5__["LoginComponent"],
                    _Pages_Operator_cash_entry_cash_entry_component__WEBPACK_IMPORTED_MODULE_6__["CashEntryComponent"],
                    _Pages_Operator_cash_entry_item_list_cash_entry_item_list_component__WEBPACK_IMPORTED_MODULE_24__["CashEntryItemListComponent"],
                    _Pages_Operator_cash_entry_add_item_cash_entry_add_item_component__WEBPACK_IMPORTED_MODULE_25__["CashEntryAddItemComponent"],
                    _Pages_Common_PopUps_add_new_client_add_new_client_component__WEBPACK_IMPORTED_MODULE_27__["AddNewClientComponent"],
                    _Pages_Common_PopUps_add_new_service_type_add_new_service_type_component__WEBPACK_IMPORTED_MODULE_28__["AddNewServiceTypeComponent"],
                    _Pages_Common_PopUps_cash_entry_edit_item_cash_entry_edit_item_component__WEBPACK_IMPORTED_MODULE_29__["CashEntryEditItemComponent"],
                    _Pages_Common_loading_spinner_loading_spinner_component__WEBPACK_IMPORTED_MODULE_30__["LoadingSpinnerComponent"],
                    _helpers_currency_formatter_pipe__WEBPACK_IMPORTED_MODULE_31__["CurrencyFormatterPipe"],
                    _helpers_alert_alert_component__WEBPACK_IMPORTED_MODULE_32__["AlertComponent"],
                    _Pages_Common_PopUps_add_new_transaction_type_add_new_transaction_type_component__WEBPACK_IMPORTED_MODULE_33__["AddNewTransactionTypeComponent"],
                    _Pages_Reports_general_report_general_report_component__WEBPACK_IMPORTED_MODULE_34__["GeneralReportComponent"],
                    _Pages_Reports_debit_report_debit_report_component__WEBPACK_IMPORTED_MODULE_35__["DebitReportComponent"],
                    _Pages_Admin__WEBPACK_IMPORTED_MODULE_36__["EditComputerOperatorComponent"],
                    _Pages_Admin__WEBPACK_IMPORTED_MODULE_36__["EditTransactionTypeComponent"],
                    _Pages_Admin__WEBPACK_IMPORTED_MODULE_36__["EditClientComponent"],
                    _Pages_Admin__WEBPACK_IMPORTED_MODULE_36__["EditServiceTypeComponent"],
                    _Pages_Admin_Create_create_computer_operator_create_computer_operator_component__WEBPACK_IMPORTED_MODULE_37__["CreateComputerOperatorComponent"],
                    _Pages_Admin_Create_create_client_create_client_component__WEBPACK_IMPORTED_MODULE_38__["CreateClientComponent"],
                    _Pages_Admin_Create_create_service_type_create_service_type_component__WEBPACK_IMPORTED_MODULE_39__["CreateServiceTypeComponent"],
                    _Pages_Admin_Create_create_transaction_type_create_transaction_type_component__WEBPACK_IMPORTED_MODULE_40__["CreateTransactionTypeComponent"]
                ],
                imports: [
                    _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_26__["BrowserAnimationsModule"],
                    _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                    _app_routing_module__WEBPACK_IMPORTED_MODULE_3__["AppRoutingModule"],
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"],
                    _angular_common_http__WEBPACK_IMPORTED_MODULE_23__["HttpClientModule"],
                    _angular_material_dialog__WEBPACK_IMPORTED_MODULE_7__["MatDialogModule"],
                    _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_8__["MatAutocompleteModule"],
                    _angular_common__WEBPACK_IMPORTED_MODULE_12__["CommonModule"],
                    _angular_material_icon__WEBPACK_IMPORTED_MODULE_11__["MatIconModule"],
                    _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_13__["MatProgressSpinnerModule"],
                    _angular_material_button__WEBPACK_IMPORTED_MODULE_14__["MatButtonModule"],
                    _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_15__["MatButtonToggleModule"],
                    _angular_material_table__WEBPACK_IMPORTED_MODULE_16__["MatTableModule"],
                    _angular_material_paginator__WEBPACK_IMPORTED_MODULE_17__["MatPaginatorModule"],
                    _angular_material_input__WEBPACK_IMPORTED_MODULE_9__["MatInputModule"],
                    _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_10__["MatCheckboxModule"],
                    _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_19__["MatDatepickerModule"],
                    _angular_material_core__WEBPACK_IMPORTED_MODULE_18__["MatNativeDateModule"],
                    _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_20__["NgbModule"],
                    _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_22__["PortalModule"],
                    _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_21__["OverlayModule"]
                ],
                providers: [_angular_common__WEBPACK_IMPORTED_MODULE_12__["DatePipe"], _angular_common__WEBPACK_IMPORTED_MODULE_12__["CurrencyPipe"], _helpers_currency_formatter_pipe__WEBPACK_IMPORTED_MODULE_31__["CurrencyFormatterPipe"]],
                bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]]
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false,
    apiUrl: 'https://localhost:5001',
    lastFetchedBefore: 900000,
    OldBalanceTransactionType: "OLD BALANCE RECEIVED"
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["platformBrowser"]().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Development\Satti\FinanceTracker\src\main.ts */"./src/main.ts");


/***/ }),

/***/ 1:
/*!********************!*\
  !*** fs (ignored) ***!
  \********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 2:
/*!************************!*\
  !*** crypto (ignored) ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 3:
/*!************************!*\
  !*** stream (ignored) ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map